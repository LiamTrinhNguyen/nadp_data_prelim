"""
NADP Prelim Data Pipeline
~~~~~~~~~~~~~~~~~~~~~~~~~
Laboratory data review pipeline for NADP/NTN.
"""


# 1. Lift classes from your modules to the package level
from .SQL_connection import SQLConnection, SQLConnectionSettings
from .NTN_info import NTNInfo, NTNInfoSettings
from .NTN_report import PipelineSettings, NTNReviewPipeline
from .Precip_autocorrect import Autocorrect_Settings, PrecipAutocorrect
from .analysis_precip_qaqc_polartable import PrecipQAQCPolar_Settings, PrecipQAQCPolar
from .analysis_precip_qaqc_pandastable import PrecipQAQCPandas_Settings, PrecipQAQCPandas

# 2. Define __all__ to control what is exported
__all__ = [
    "SQLConnection",
    "SQLConnectionSettings",
    "NTNInfo",
    "NTNInfoSettings",
    "PipelineSettings",
    "NTNReviewPipeline",
    "Autocorrect_Settings",
    "PrecipAutocorrect",
    "PrecipQAQCPolar_Settings",
    "PrecipQAQCPolar",
    "PrecipQAQCPandas_Settings",
    "PrecipQAQCPandas",

]

# 3. Metadata for version tracking and auditing
__author__ = "Liam TrinhNguyen/ WSLH data scientist"
__version__ = "0.3.0"