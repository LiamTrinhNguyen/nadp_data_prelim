__author__ = 'Liam TrinhNguyen'
__email__ = 'LiamTrinhNguyen@gmail.com or TrinhNguyen@wisc.edu'
__version__ = 'preLim v0.3.0'

import os, sys, psutil, logging, numpy as np, pandas as pd, itertools
from pathlib import Path
from logging.handlers import RotatingFileHandler
from datetime import datetime
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import FilePath, DirectoryPath
import pandas as pd
pd.set_option('display.max_columns', None)
pd.set_option('display.max_colwidth', None)

class PrecipQAQCPandas_Settings(BaseSettings):
    output_dir: DirectoryPath     
    model_config = SettingsConfigDict(env_file=".env", env_prefix="WSLH_", extra="ignore")


class PrecipQAQCPandas:
    def __init__(self, sampleID_start_log, sampleID_end_log,settings: PrecipQAQCPandas_Settings):
        self.settings = settings
        self.output_root = self.settings.output_dir.resolve()
        
        self._log_dir = self.output_root / "logs"
        self._data_dir = self.output_root / "processed_data"
        self.sampleID_start_log = sampleID_start_log
        self.sampleID_end_log = sampleID_end_log
        
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = self._setup_logger()
        self.logger.info(f"PrecipQAQCPandas Settings Initialized.")
    
    def _setup_logger(self) -> logging.Logger:

        logger_name = f"WSLH_NTN.{self.__class__.__name__}"
        logger = logging.getLogger(logger_name)

        # Avoid adding handlers multiple times
        if logger.hasHandlers():
            return logger

        logger.propagate = False
        logger.setLevel(logging.INFO)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_path = Path(self._log_dir) / f"pipeline_{self.sampleID_start_log}_{self.sampleID_end_log}_{timestamp}.log"

        formatter = logging.Formatter(
            '%(asctime)s - [%(name)s] - %(levelname)s: %(message)s'
        )

        # === SINGLE FILE, NO SIZE LIMIT ===
        fh = logging.FileHandler(log_path, mode='a', encoding='utf-8', delay=False)
        fh.setFormatter(formatter)
        logger.addHandler(fh)

        # Console output
        ch = logging.StreamHandler()
        ch.setFormatter(formatter)
        logger.addHandler(ch)


        return logger

    def analyze_precip_qaqc_pandas(self, df: pd.DataFrame, case_id: str, tipping1, tipping2, tipping3 ):
        """
        Full Precipitation QA/QC Analysis Function (Pandas Version)
        """
        print("=== Starting Precipitation QA/QC Analysis ===\n")

        # Preprocessing
        df = df.copy()
        df['LocalReportDateTime'] = pd.to_datetime(df['LocalReportDateTime'], format='%m/%d/%y %H:%M', errors='coerce') # chnaging the dateime SQL to current LocalReportDateTime column name
        df = df.sort_values('LocalReportDateTime').reset_index(drop=True)

        print(f"Loaded {len(df)} rows")

        # User Input
        if case_id is None:
            case_id = input("Enter the Case ID number for reference/tracking: ").strip()

        if tipping1 is None or tipping2 is None or tipping3 is None:
            print("\nEnter ending tipping collector sample total (inches) for each:")
            tipping1 = float(input("Tipping 1 (altPrecip): ") or 0)
            tipping2 = float(input("Tipping 2 (reportPrecip): ") or 0)
            tipping3 = float(input("Tipping 3 (reportPCP): ") or 0)

        tip_volume = 0.01

        # Daily Summary
        df['date'] = df['datetime'].dt.date
        daily = df.groupby('date').agg({
            'altPrecip': 'sum',
            'reportPrecip': 'sum',
            'reportPCP': 'sum',
            'exp1': lambda x: (x > 50).sum(),
            'coll1cycles': 'sum',
            'exp2': lambda x: (x > 50).sum(),
            'coll2cycles': 'sum',
            'Exp3': lambda x: (x > 50).sum(),
            'coll3cycles': 'sum'
        }).reset_index()

        total_row = pd.DataFrame({
            'date': ['All days sum'],
            'altPrecip': [daily['altPrecip'].sum()],
            'reportPrecip': [daily['reportPrecip'].sum()],
            'reportPCP': [daily['reportPCP'].sum()],
            'exp1': [daily['exp1'].sum()],
            'coll1cycles': [daily['coll1cycles'].sum()],
            'exp2': [daily['exp2'].sum()],
            'coll2cycles': [daily['coll2cycles'].sum()],
            'Exp3': [daily['Exp3'].sum()],
            'coll3cycles': [daily['coll3cycles'].sum()]
        })

        daily = pd.concat([daily, total_row], ignore_index=True)

        print("\nDaily Summary (Oldest -> Newest):")
        print(daily)

        # Metrics
        total_alt = df['altPrecip'].sum()
        total_rp = df['reportPrecip'].sum()
        total_pcp = df['reportPCP'].sum()
        delta_res = df['ActDepth'].iloc[-1] - df['ActDepth'].iloc[0]

        def get_metrics(self, precip_col, exp_col, coll_col, tipping_total):
            overlap_mask = (df[precip_col] > 0.007) & (df[exp_col] > 10)
            filtered = df[overlap_mask]
            
            overlap_c = len(filtered)
            overlap_p = filtered[precip_col].sum()
            overlap_tips = filtered[coll_col].sum()
            overlap_catch = overlap_tips * tip_volume

            egauge = total_alt if precip_col == "altPrecip" else total_rp if precip_col == "reportPrecip" else total_pcp

            c_vol = 0.0
            if egauge > 0.01:
                abs_error = abs(delta_res - egauge)
                c_vol = 1 - (abs_error / egauge)
                c_vol = max(0.0, min(1.0, c_vol))

            c_sync = 0.0
            if egauge > 0.01:
                c_sync = overlap_p / egauge

            c_mech = 0.0
            if delta_res > 0.01:
                c_mech = min(100.0, (overlap_catch / delta_res) * 100)

            total_conf = (c_vol * c_sync) * 100

            blind_ef = (tipping_total / egauge * 100) if egauge > 0.01 else 0.0
            conf_ef = (tipping_total / overlap_p * 100) if overlap_p > 0.01 else 0.0

            def get_apr_flag(ef):
                if overlap_p == 0 and egauge == 0:
                    return "DRY_INTERVAL"
                if ef < 0:
                    return "SENSOR_ANOMALY"
                if ef == 0:
                    return "TOTAL_BLOCKAGE"
                if 0.01 <= ef <= 94.99:
                    return "UNDERCATCH"
                if 95.0 <= ef <= 105.0:
                    return "VALID"
                if ef > 105.0:
                    return "OVERCATCH"
                return "BULK_SAMPLE"

            analysis_blind_ef = f"{get_apr_flag(blind_ef)}"
            analysis_conf_ef = f"{get_apr_flag(conf_ef)}"

            other_flag = "BULK_SAMPLE - Lid open but eGauge volume = 0" if overlap_p == 0 and egauge > 0 else "No special flag"

            if c_mech < 0.0:
                analysis_c_mech = "Impossible State; RESERVOIR_ANOMALY"
            elif abs(c_mech) < 0.001:
                analysis_c_mech = "Dead State; MECH_BLOCKAGE"
            elif 0.0 < c_mech < 95.0:
                analysis_c_mech = "Degraded State; MECH_UNDERCATCH"
            elif 95.0 <= c_mech <= 105.0:
                analysis_c_mech = "Optimal State; VALID"
            else:
                analysis_c_mech = "Exaggerated State; MECH_OVERCATCH"

            issue = "C_vol drops below 0.90 -> baseline telemetry highly suspect, flag for manual review" if c_vol < 0.90 else \
                    "Near-zero C_sync with high C_vol -> clock-drift or timezone misalignment suspected" if c_sync < 0.05 and c_vol > 0.80 else \
                    "Hardware and logger synchronization suspect, check agreement"

            comparable = "YES" if overlap_c >= 5 else "NO - Different precipitation events."
            efficiency = f"{conf_ef:.1f}%" if overlap_p > 0.01 else "NOT CALCULABLE"

            return (overlap_c, round(float(overlap_p or 0), 3), issue, comparable, efficiency, 
                    round(c_vol,3), round(c_sync,3), round(c_mech,1), round(total_conf,1), 
                    analysis_blind_ef, analysis_conf_ef, other_flag, analysis_c_mech)

        print(f"\n=== FUNCTIONALITY ASSESSMENT and EFFICIENCY CALCULATION (Case ID: {case_id}) ===")

        # Tipping 1
        ov1_c, ov1_p, iss1, comp1, eff1, c_vol1, c_sync1, c_mech1, total_conf1, blind1, conf1, other1, cmech1 = get_metrics(self, "altPrecip", "exp1", "coll1cycles", tipping1)
        print("\n--- Tipping 1 ---")
        t1 = pd.DataFrame({
            "Metric": [
                "eGauge total", "Collector catch (tipping)", "ActDepth delta (reservoir)",
                "Overlap intervals | precip", "Number of overlapping intervals",
                "C_vol (%)", "C_sync (%)", "C_mech (%)", "analysis_C_mech", "Total Confidence (%)",
                "Blind total Efficiency", "analysis_blind_EF", "Confidence Efficiency", "analysis_conf_EF",
                "other_flag", "Issues / Notes", "Comparable"
            ],
            "altPrecip_tipping1": [f"{total_alt:.3f}", f"{tipping1:.3f}", f"{delta_res:.3f}", f"{ov1_c}|{ov1_p:.2f}", f"{ov1_c}", 
                                f"{c_vol1}", f"{c_sync1}", f"{c_mech1}", cmech1, f"{total_conf1}", 
                                f"{(tipping1 / total_alt * 100):.1f}%", blind1, eff1, conf1, other1, iss1, comp1],
            "reportPrecip_tipping1": [f"{total_rp:.3f}", f"{tipping1:.3f}", f"{delta_res:.3f}", f"{ov1_c}|{ov1_p:.2f}", f"{ov1_c}", 
                                    f"{c_vol1}", f"{c_sync1}", f"{c_mech1}", cmech1, f"{total_conf1}", 
                                    f"{(tipping1 / total_rp * 100):.1f}%", blind1, eff1, conf1, other1, iss1, comp1],
            "reportPCP_tipping1": [f"{total_pcp:.3f}", f"{tipping1:.3f}", f"{delta_res:.3f}", f"{ov1_c}|{ov1_p:.2f}", f"{ov1_c}", 
                                f"{c_vol1}", f"{c_sync1}", f"{c_mech1}", cmech1, f"{total_conf1}", 
                                f"{(tipping1 / total_pcp * 100):.1f}%", blind1, eff1, conf1, other1, iss1, comp1]
        })
        print(t1.to_string(index=False))

        # Tipping 2
        ov2_c, ov2_p, iss2, comp2, eff2, c_vol2, c_sync2, c_mech2, total_conf2, blind2, conf2, other2, cmech2 = get_metrics(self, "reportPrecip", "exp2", "coll2cycles", tipping2)
        print("\n--- Tipping 2 ---")
        t2 = pd.DataFrame({
            "Metric": [
                "eGauge total", "Collector catch (tipping)", "ActDepth delta (reservoir)",
                "Overlap intervals | precip", "Number of overlapping intervals",
                "C_vol (%)", "C_sync (%)", "C_mech (%)", "analysis_C_mech", "Total Confidence (%)",
                "Blind total Efficiency", "analysis_blind_EF", "Confidence Efficiency", "analysis_conf_EF",
                "other_flag", "Issues / Notes", "Comparable"
            ],
            "altPrecip_tipping2": [f"{total_alt:.3f}", f"{tipping2:.3f}", f"{delta_res:.3f}", f"{ov2_c}|{ov2_p:.2f}", f"{ov2_c}", 
                                f"{c_vol2}", f"{c_sync2}", f"{c_mech2}", cmech2, f"{total_conf2}", 
                                f"{(tipping2 / total_alt * 100):.1f}%", blind2, eff2, conf2, other2, iss2, comp2],
            "reportPrecip_tipping2": [f"{total_rp:.3f}", f"{tipping2:.3f}", f"{delta_res:.3f}", f"{ov2_c}|{ov2_p:.2f}", f"{ov2_c}", 
                                    f"{c_vol2}", f"{c_sync2}", f"{c_mech2}", cmech2, f"{total_conf2}", 
                                    f"{(tipping2 / total_rp * 100):.1f}%", blind2, eff2, conf2, other2, iss2, comp2],
            "reportPCP_tipping2": [f"{total_pcp:.3f}", f"{tipping2:.3f}", f"{delta_res:.3f}", f"{ov2_c}|{ov2_p:.2f}", f"{ov2_c}", 
                                f"{c_vol2}", f"{c_sync2}", f"{c_mech2}", cmech2, f"{total_conf2}", 
                                f"{(tipping2 / total_pcp * 100):.1f}%", blind2, eff2, conf2, other2, iss2, comp2]
        })
        print(t2.to_string(index=False))

        # Tipping 3
        ov3_c, ov3_p, iss3, comp3, eff3, c_vol3, c_sync3, c_mech3, total_conf3, blind3, conf3, other3, cmech3 = get_metrics(self, "reportPCP", "Exp3", "coll3cycles", tipping3)
        print("\n--- Tipping 3 ---")
        t3 = pd.DataFrame({
            "Metric": [
                "eGauge total", "Collector catch (tipping)", "ActDepth delta (reservoir)",
                "Overlap intervals | precip", "Number of overlapping intervals",
                "C_vol (%)", "C_sync (%)", "C_mech (%)", "analysis_C_mech", "Total Confidence (%)",
                "Blind total Efficiency", "analysis_blind_EF", "Confidence Efficiency", "analysis_conf_EF",
                "other_flag", "Issues / Notes", "Comparable"
            ],
            "altPrecip_tipping3": [f"{total_alt:.3f}", f"{tipping3:.3f}", f"{delta_res:.3f}", f"{ov3_c}|{ov3_p:.2f}", f"{ov3_c}", 
                                f"{c_vol3}", f"{c_sync3}", f"{c_mech3}", cmech3, f"{total_conf3}", 
                                f"{(tipping3 / total_alt * 100):.1f}%", blind3, eff3, conf3, other3, iss3, comp3],
            "reportPrecip_tipping3": [f"{total_rp:.3f}", f"{tipping3:.3f}", f"{delta_res:.3f}", f"{ov3_c}|{ov3_p:.2f}", f"{ov3_c}", 
                                    f"{c_vol3}", f"{c_sync3}", f"{c_mech3}", cmech3, f"{total_conf3}", 
                                    f"{(tipping3 / total_rp * 100):.1f}%", blind3, eff3, conf3, other3, iss3, comp3],
            "reportPCP_tipping3": [f"{total_pcp:.3f}", f"{tipping3:.3f}", f"{delta_res:.3f}", f"{ov3_c}|{ov3_p:.2f}", f"{ov3_c}", 
                                f"{c_vol3}", f"{c_sync3}", f"{c_mech3}", cmech3, f"{total_conf3}", 
                                f"{(tipping3 / total_pcp * 100):.1f}%", blind3, eff3, conf3, other3, iss3, comp3]
        })
        print(t3.to_string(index=False))

        print("\nAnalysis completed successfully!")
        return daily


# # ====================== USAGE ======================
# if __name__ == "__main__":
#     df = pd.read_csv('/Users/liamtn/desktop/t2601139.csv')
#     analyze_precip_qaqc(df)