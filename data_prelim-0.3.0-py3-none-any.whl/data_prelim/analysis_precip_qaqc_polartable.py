__author__ = 'Liam TrinhNguyen'
__email__ = 'LiamTrinhNguyen@gmail.com or TrinhNguyen@wisc.edu'
__version__ = 'preLim v0.3.0'

import os, sys, psutil, logging, numpy as np, pandas as pd, itertools
from pathlib import Path
from logging.handlers import RotatingFileHandler
from datetime import datetime
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import FilePath, DirectoryPath
import polars as pl

# ====================== FULL DISPLAY ======================
pl.Config.set_tbl_rows(-1)
pl.Config.set_tbl_cols(-1)
pl.Config.set_tbl_width_chars(200)

class PrecipQAQCPolar_Settings(BaseSettings):
    output_dir: DirectoryPath     
    model_config = SettingsConfigDict(env_file=".env", env_prefix="WSLH_", extra="ignore")


class PrecipQAQCPolar:
    def __init__(self, sampleID_start_log, sampleID_end_log, settings: PrecipQAQCPolar_Settings):
        self.settings = settings
        self.output_root = self.settings.output_dir.resolve()
        
        self._log_dir = self.output_root / "logs"
        self._data_dir = self.output_root / "processed_data"
        self.sampleID_start_log = sampleID_start_log
        self.sampleID_end_log = sampleID_end_log
        
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = self._setup_logger()
        self.logger.info(f"PrecipQAQCPolar Settings Initialized.")
    
    def _setup_logger(self) -> logging.Logger:

        logger_name = f"WSLH_NTN.{self.__class__.__name__}"
        logger = logging.getLogger(logger_name)

        # Avoid adding handlers multiple times
        if logger.hasHandlers():
            return logger

        logger.propagate = False
        logger.setLevel(logging.INFO)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_path = Path(self._log_dir) / f"pipeline_{self.sampleID_start_log}_{self.sampleID_end_log}_{timestamp}.log"

        formatter = logging.Formatter(
            '%(asctime)s - [%(name)s] - %(levelname)s: %(message)s'
        )

        # === SINGLE FILE, NO SIZE LIMIT ===
        fh = logging.FileHandler(log_path, mode='a', encoding='utf-8', delay=False)
        fh.setFormatter(formatter)
        logger.addHandler(fh)

        # Console output
        ch = logging.StreamHandler()
        ch.setFormatter(formatter)
        logger.addHandler(ch)


        return logger






    def analyze_precip_qaqc_polar(self, df: pl.DataFrame, case_id: str = None, tipping1=None, tipping2=None, tipping3=None):
        """
        Full Precipitation QA/QC Analysis Function - Revamped with Safe Efficiency
        """
        self.logger.info("=== Starting Precipitation QA/QC Analysis ===\n")

        # ====================== PREPROCESSING ======================
        if isinstance(df, pd.DataFrame):
            df = pl.from_pandas(df)

       # Safe datetime conversion
        if df["LocalReportDateTime"].dtype == pl.Datetime:
            self.logger.info("LocalReportDateTime is already datetime type. Skipping string parsing.")
        else:
            df = df.with_columns(
                pl.col("LocalReportDateTime")
                .cast(pl.String)
                .str.to_datetime(format="%m/%d/%y %H:%M", strict=False)
            )

        df = df.sort("LocalReportDateTime")

        df = df.with_columns([
            pl.col(col).cast(pl.Float64, strict=False)
            for col in ['ActDepth', 'altPrecip', 'reportPrecip', 'reportPCP',
                        'exp1', 'coll1cycles', 'exp2', 'coll2cycles', 'exp3', 'coll3cycles']
        ])

        self.logger.info(f"Loaded {df.height} rows")

        # ====================== USER INPUT ======================
        self.logger.info("\n=== ANALYSIS SETUP ===")

        if case_id is None:
            case_id = input("Enter the Case ID number for reference/tracking: ").strip()

        if tipping1 is None or tipping2 is None or tipping3 is None:
            self.logger.info("\nEnter ending tipping collector sample total (inches) for each:")

            def get_safe_float(prompt: str) -> float:
                user_in = input(prompt).strip()
                if not user_in:
                    return 0.0
                try:
                    return float(user_in)
                except ValueError:
                    self.logger.info("  Invalid number entered. Defaulting to 0.0")
                    return 0.0

            tipping1 = get_safe_float("Tipping 1 sampleDepth NTN: ")
            tipping2 = get_safe_float("Tipping 2 sampleDepth MDN: ")
            tipping3 = get_safe_float("Tipping 3 sampleDepth CO-located:")

        tip_volume = 0.01

        # ====================== DAILY SUMMARY ======================
        daily = (
            df.with_columns(pl.col("LocalReportDateTime").dt.date().cast(pl.Utf8).alias("date"))
            .group_by("date")
            .agg([
                pl.col("altPrecip").sum().alias("altPrecip"),
                pl.col("reportPrecip").sum().alias("reportPrecip"),
                pl.col("reportPCP").sum().alias("reportPCP"),
                (pl.col("exp1") > 50).sum().cast(pl.Int64).alias("exp1_active"),
                pl.col("coll1cycles").sum().cast(pl.Float64).alias("coll1cycles"),
                (pl.col("exp2") > 50).sum().cast(pl.Int64).alias("exp2_active"),
                pl.col("coll2cycles").sum().cast(pl.Float64).alias("coll2cycles"),
                (pl.col("exp3") > 50).sum().cast(pl.Int64).alias("exp3_active"),
                pl.col("coll3cycles").sum().cast(pl.Float64).alias("coll3cycles")
            ])
            .sort("date")
        )

        total_row = pl.DataFrame({
            "date": ["All days sum"],
            "altPrecip": [float(daily["altPrecip"].sum())],
            "reportPrecip": [float(daily["reportPrecip"].sum())],
            "reportPCP": [float(daily["reportPCP"].sum())],
            "exp1_active": [int(daily["exp1_active"].sum())],
            "coll1cycles": [float(daily["coll1cycles"].sum())],
            "exp2_active": [int(daily["exp2_active"].sum())],
            "coll2cycles": [float(daily["coll2cycles"].sum())],
            "exp3_active": [int(daily["exp3_active"].sum())],
            "coll3cycles": [float(daily["coll3cycles"].sum())]
        })

        daily = pl.concat([daily, total_row], how="vertical")

        self.logger.info("\nDaily Summary (Oldest -> Newest):")
        self.logger.info(daily)

        # ====================== TOTALS ======================
        total_alt = float(df["altPrecip"].sum() or 0)
        total_rp = float(df["reportPrecip"].sum() or 0)
        total_pcp = float(df["reportPCP"].sum() or 0)

        # Safe delta_res
        act_first = df["ActDepth"].first()
        act_last = df["ActDepth"].last()
        if act_first is None or act_last is None:
            delta_res = None
            self.logger.warning("ActDepth is empty or contains only null values. delta_res set to None")
        else:
            delta_res = float(act_last - act_first)

        # ====================== METRICS FUNCTION ======================
        def get_metrics(precip_col: str, exp_col: str, coll_col: str, tipping_total: float):
            overlap_mask = (pl.col(precip_col) > 0.007) & (pl.col(exp_col) > 10)
            filtered = df.filter(overlap_mask)
            
            overlap_c = filtered.height
            overlap_p = float(filtered[precip_col].sum() or 0)
            overlap_tips = float(filtered[coll_col].sum() or 0)
            overlap_catch = overlap_tips * tip_volume

            if precip_col == "altPrecip":
                egauge = total_alt
            elif precip_col == "reportPrecip":
                egauge = total_rp
            else:
                egauge = total_pcp

            # C_vol (0-1 scale)
            c_vol = None
            if delta_res is not None and egauge > 0.01:
                abs_error = abs(delta_res - egauge)
                c_vol = 1 - (abs_error / egauge)
                c_vol = max(0.0, min(1.0, c_vol))

            # C_sync (0-1 scale)
            c_sync = 0.0
            if egauge > 0.01:
                c_sync = overlap_p / egauge

            # C_mech (%)
            c_mech = None
            if delta_res is not None and delta_res > 0.01:
                c_mech = (overlap_catch / delta_res) * 100

            # Total Confidence (%)
            total_conf = None
            if c_vol is not None and c_sync is not None:
                total_conf = (c_vol * c_sync) * 100

            # Safe Blind Efficiency
            blind_ef = 0.0
            if egauge > 0:
                blind_ef = (tipping_total / egauge) * 100

            # Safe Confidence Efficiency
            conf_ef = 0.0
            if overlap_p > 0:
                conf_ef = (tipping_total / overlap_p) * 100

            def get_apr_flag(ef, gauge_total, tip_total):
                if gauge_total == 0 and tip_total == 0:
                    return "DRY_INTERVAL"
                if ef is None:
                    return "NO_DATA"
                if ef < 0:
                    return "SENSOR_ANOMALY"
                if ef == 0 and gauge_total > 0:
                    return "TOTAL_BLOCKAGE"
                if 0.01 <= ef <= 94.99:
                    return "UNDERCATCH"
                if 95.0 <= ef <= 105.0:
                    return "VALID"
                if ef > 105.0:
                    return "OVERCATCH"
                if gauge_total == 0 and tip_total > 0:
                    return "PHANTOM_TIPS"
                return "BULK_SAMPLE"

            analysis_blind_ef = f"{get_apr_flag(blind_ef, egauge, tipping_total)}"
            analysis_conf_ef = f"{get_apr_flag(conf_ef, overlap_p, tipping_total)}"

            other_flag = "BULK_SAMPLE - Lid open but eGauge volume = 0" if overlap_p == 0 and egauge > 0 else "No special flag"

            if c_mech is None:
                analysis_c_mech = "NO_DATA"
            elif c_mech < 0.0:
                analysis_c_mech = "Impossible State; RESERVOIR_ANOMALY"
            elif abs(c_mech) < 0.001:
                analysis_c_mech = "Dead State; MECH_BLOCKAGE"
            elif 0.0 < c_mech < 95.0:
                analysis_c_mech = "Degraded State; MECH_UNDERCATCH"
            elif 95.0 <= c_mech <= 105.0:
                analysis_c_mech = "Optimal State; VALID"
            else:
                analysis_c_mech = "Exaggerated State; MECH_OVERCATCH"

            issue = "C_vol below 0.90 -> baseline telemetry highly suspect, flag for manual review" if c_vol is not None and c_vol < 0.90 else \
                    "Near-zero C_sync with high C_vol -> clock-drift or timezone misalignment suspected" if c_sync < 0.05 and c_vol is not None and c_vol > 0.80 else \
                    "Hardware and logger synchronization suspect, check agreement"

            comparable = "YES" if overlap_c >= 5 else "NO - Different precipitation events."
            efficiency = f"{conf_ef:.1f}%" if overlap_p > 0.01 else "NOT CALCULABLE"

            return (overlap_c, round(float(overlap_p or 0), 3), issue, comparable, efficiency, 
                    c_vol, round(c_sync,3) if c_sync is not None else None, 
                    round(c_mech,1) if c_mech is not None else None, 
                    round(total_conf,1) if total_conf is not None else None, 
                    analysis_blind_ef, analysis_conf_ef, other_flag, analysis_c_mech, blind_ef)

        self.logger.info(f"\n=== FUNCTIONALITY ASSESSMENT and EFFICIENCY CALCULATION (Case ID: {case_id}) ===")

            # ====================== TIPPING 1 ======================
        self.logger.info("\n--- Tipping 1 (using exp1/coll1cycles) ---")
        (ov_alt_t1, p_alt_t1, iss_alt_t1, comp_alt_t1, eff_alt_t1, cv_alt_t1, cs_alt_t1, 
        cm_alt_t1, tc_alt_t1, blind_alt_t1, conf_alt_t1, other_alt_t1, cmech_alt_t1, 
        blind_ef_alt_t1) = get_metrics("altPrecip", "exp1", "coll1cycles", tipping1)

        (ov_rp_t1, p_rp_t1, iss_rp_t1, comp_rp_t1, eff_rp_t1, cv_rp_t1, cs_rp_t1, 
        cm_rp_t1, tc_rp_t1, blind_rp_t1, conf_rp_t1, other_rp_t1, cmech_rp_t1, 
        blind_ef_rp_t1) = get_metrics("reportPrecip", "exp1", "coll1cycles", tipping1)

        (ov_pcp_t1, p_pcp_t1, iss_pcp_t1, comp_pcp_t1, eff_pcp_t1, cv_pcp_t1, cs_pcp_t1, 
        cm_pcp_t1, tc_pcp_t1, blind_pcp_t1, conf_pcp_t1, other_pcp_t1, cmech_pcp_t1, 
        blind_ef_pcp_t1) = get_metrics("reportPCP", "exp1", "coll1cycles", tipping1)

        t1 = pl.DataFrame({
            "Metric": [
                "eGauge total", "Collector catch (tipping)", "ActDepth delta (reservoir)",
                "Overlap intervals | precip", "Number of overlapping intervals",
                "C_vol (%)", "C_sync (%)", "C_mech (%)", "analysis_C_mech", "Total Confidence (%)",
                "Blind total Efficiency", "analysis_blind_EF", "Confidence Efficiency", "analysis_conf_EF",
                "other_flag", "Issues / Notes", "Comparable"
            ],
            "altPrecip_tipping1": [f"{total_alt:.3f}", f"{tipping1:.3f}", str(delta_res) if delta_res is not None else "N/A", 
                                f"{ov_alt_t1}|{p_alt_t1:.2f}", str(ov_alt_t1),
                                str(cv_alt_t1) if cv_alt_t1 is not None else "N/A", str(cs_alt_t1), 
                                str(cm_alt_t1) if cm_alt_t1 is not None else "N/A", str(cmech_alt_t1), 
                                str(tc_alt_t1) if tc_alt_t1 is not None else "N/A",
                                f"{blind_ef_alt_t1:.1f}%", blind_alt_t1, str(eff_alt_t1), str(conf_alt_t1), 
                                str(other_alt_t1), str(iss_alt_t1), str(comp_alt_t1)],
            "reportPrecip_tipping1": [f"{total_rp:.3f}", f"{tipping1:.3f}", str(delta_res) if delta_res is not None else "N/A", 
                                    f"{ov_rp_t1}|{p_rp_t1:.2f}", str(ov_rp_t1),
                                    str(cv_rp_t1) if cv_rp_t1 is not None else "N/A", str(cs_rp_t1), 
                                    str(cm_rp_t1) if cm_rp_t1 is not None else "N/A", str(cmech_rp_t1), 
                                    str(tc_rp_t1) if tc_rp_t1 is not None else "N/A",
                                    f"{blind_ef_rp_t1:.1f}%", blind_rp_t1, str(eff_rp_t1), str(conf_rp_t1), 
                                    str(other_rp_t1), str(iss_rp_t1), str(comp_rp_t1)],
            "reportPCP_tipping1": [f"{total_pcp:.3f}", f"{tipping1:.3f}", str(delta_res) if delta_res is not None else "N/A", 
                                f"{ov_pcp_t1}|{p_pcp_t1:.2f}", str(ov_pcp_t1),
                                str(cv_pcp_t1) if cv_pcp_t1 is not None else "N/A", str(cs_pcp_t1), 
                                str(cm_pcp_t1) if cm_pcp_t1 is not None else "N/A", str(cmech_pcp_t1), 
                                str(tc_pcp_t1) if tc_pcp_t1 is not None else "N/A",
                                f"{blind_ef_pcp_t1:.1f}%", blind_pcp_t1, str(eff_pcp_t1), str(conf_pcp_t1), 
                                str(other_pcp_t1), str(iss_pcp_t1), str(comp_pcp_t1)]
        })
        self.logger.info(t1)

        # ====================== TIPPING 2 ======================
        self.logger.info("\n--- Tipping 2 (using exp2/coll2cycles) ---")
        (ov_alt_t2, p_alt_t2, iss_alt_t2, comp_alt_t2, eff_alt_t2, cv_alt_t2, cs_alt_t2, 
        cm_alt_t2, tc_alt_t2, blind_alt_t2, conf_alt_t2, other_alt_t2, cmech_alt_t2, 
        blind_ef_alt_t2) = get_metrics("altPrecip", "exp2", "coll2cycles", tipping2)

        (ov_rp_t2, p_rp_t2, iss_rp_t2, comp_rp_t2, eff_rp_t2, cv_rp_t2, cs_rp_t2, 
        cm_rp_t2, tc_rp_t2, blind_rp_t2, conf_rp_t2, other_rp_t2, cmech_rp_t2, 
        blind_ef_rp_t2) = get_metrics("reportPrecip", "exp2", "coll2cycles", tipping2)

        (ov_pcp_t2, p_pcp_t2, iss_pcp_t2, comp_pcp_t2, eff_pcp_t2, cv_pcp_t2, cs_pcp_t2, 
        cm_pcp_t2, tc_pcp_t2, blind_pcp_t2, conf_pcp_t2, other_pcp_t2, cmech_pcp_t2, 
        blind_ef_pcp_t2) = get_metrics("reportPCP", "exp2", "coll2cycles", tipping2)

        t2 = pl.DataFrame({
            "Metric": [
                "eGauge total", "Collector catch (tipping)", "ActDepth delta (reservoir)",
                "Overlap intervals | precip", "Number of overlapping intervals",
                "C_vol (%)", "C_sync (%)", "C_mech (%)", "analysis_C_mech", "Total Confidence (%)",
                "Blind total Efficiency", "analysis_blind_EF", "Confidence Efficiency", "analysis_conf_EF",
                "other_flag", "Issues / Notes", "Comparable"
            ],
            "altPrecip_tipping2": [f"{total_alt:.3f}", f"{tipping2:.3f}", str(delta_res) if delta_res is not None else "N/A", 
                                f"{ov_alt_t2}|{p_alt_t2:.2f}", str(ov_alt_t2),
                                str(cv_alt_t2) if cv_alt_t2 is not None else "N/A", str(cs_alt_t2), 
                                str(cm_alt_t2) if cm_alt_t2 is not None else "N/A", str(cmech_alt_t2), 
                                str(tc_alt_t2) if tc_alt_t2 is not None else "N/A",
                                f"{blind_ef_alt_t2:.1f}%", blind_alt_t2, str(eff_alt_t2), str(conf_alt_t2), 
                                str(other_alt_t2), str(iss_alt_t2), str(comp_alt_t2)],
            "reportPrecip_tipping2": [f"{total_rp:.3f}", f"{tipping2:.3f}", str(delta_res) if delta_res is not None else "N/A", 
                                    f"{ov_rp_t2}|{p_rp_t2:.2f}", str(ov_rp_t2),
                                    str(cv_rp_t2) if cv_rp_t2 is not None else "N/A", str(cs_rp_t2), 
                                    str(cm_rp_t2) if cm_rp_t2 is not None else "N/A", str(cmech_rp_t2), 
                                    str(tc_rp_t2) if tc_rp_t2 is not None else "N/A",
                                    f"{blind_ef_rp_t2:.1f}%", blind_rp_t2, str(eff_rp_t2), str(conf_rp_t2), 
                                    str(other_rp_t2), str(iss_rp_t2), str(comp_rp_t2)],
            "reportPCP_tipping2": [f"{total_pcp:.3f}", f"{tipping2:.3f}", str(delta_res) if delta_res is not None else "N/A", 
                                f"{ov_pcp_t2}|{p_pcp_t2:.2f}", str(ov_pcp_t2),
                                str(cv_pcp_t2) if cv_pcp_t2 is not None else "N/A", str(cs_pcp_t2), 
                                str(cm_pcp_t2) if cm_pcp_t2 is not None else "N/A", str(cmech_pcp_t2), 
                                str(tc_pcp_t2) if tc_pcp_t2 is not None else "N/A",
                                f"{blind_ef_pcp_t2:.1f}%", blind_pcp_t2, str(eff_pcp_t2), str(conf_pcp_t2), 
                                str(other_pcp_t2), str(iss_pcp_t2), str(comp_pcp_t2)]
        })
        self.logger.info(t2)

        # ====================== TIPPING 3 ======================
        self.logger.info("\n--- Tipping 3 (using exp3/coll3cycles) ---")
        (ov_alt_t3, p_alt_t3, iss_alt_t3, comp_alt_t3, eff_alt_t3, cv_alt_t3, cs_alt_t3, 
        cm_alt_t3, tc_alt_t3, blind_alt_t3, conf_alt_t3, other_alt_t3, cmech_alt_t3, 
        blind_ef_alt_t3) = get_metrics("altPrecip", "exp3", "coll3cycles", tipping3)

        (ov_rp_t3, p_rp_t3, iss_rp_t3, comp_rp_t3, eff_rp_t3, cv_rp_t3, cs_rp_t3, 
        cm_rp_t3, tc_rp_t3, blind_rp_t3, conf_rp_t3, other_rp_t3, cmech_rp_t3, 
        blind_ef_rp_t3) = get_metrics("reportPrecip", "exp3", "coll3cycles", tipping3)

        (ov_pcp_t3, p_pcp_t3, iss_pcp_t3, comp_pcp_t3, eff_pcp_t3, cv_pcp_t3, cs_pcp_t3, 
        cm_pcp_t3, tc_pcp_t3, blind_pcp_t3, conf_pcp_t3, other_pcp_t3, cmech_pcp_t3, 
        blind_ef_pcp_t3) = get_metrics("reportPCP", "exp3", "coll3cycles", tipping3)

        t3 = pl.DataFrame({
            "Metric": [
                "eGauge total", "Collector catch (tipping)", "ActDepth delta (reservoir)",
                "Overlap intervals | precip", "Number of overlapping intervals",
                "C_vol (%)", "C_sync (%)", "C_mech (%)", "analysis_C_mech", "Total Confidence (%)",
                "Blind total Efficiency", "analysis_blind_EF", "Confidence Efficiency", "analysis_conf_EF",
                "other_flag", "Issues / Notes", "Comparable"
            ],
            "altPrecip_tipping3": [f"{total_alt:.3f}", f"{tipping3:.3f}", str(delta_res) if delta_res is not None else "N/A", 
                                f"{ov_alt_t3}|{p_alt_t3:.2f}", str(ov_alt_t3),
                                str(cv_alt_t3) if cv_alt_t3 is not None else "N/A", str(cs_alt_t3), 
                                str(cm_alt_t3) if cm_alt_t3 is not None else "N/A", str(cmech_alt_t3), 
                                str(tc_alt_t3) if tc_alt_t3 is not None else "N/A",
                                f"{blind_ef_alt_t3:.1f}%", blind_alt_t3, str(eff_alt_t3), str(conf_alt_t3), 
                                str(other_alt_t3), str(iss_alt_t3), str(comp_alt_t3)],
            "reportPrecip_tipping3": [f"{total_rp:.3f}", f"{tipping3:.3f}", str(delta_res) if delta_res is not None else "N/A", 
                                    f"{ov_rp_t3}|{p_rp_t3:.2f}", str(ov_rp_t3),
                                    str(cv_rp_t3) if cv_rp_t3 is not None else "N/A", str(cs_rp_t3), 
                                    str(cm_rp_t3) if cm_rp_t3 is not None else "N/A", str(cmech_rp_t3), 
                                    str(tc_rp_t3) if tc_rp_t3 is not None else "N/A",
                                    f"{blind_ef_rp_t3:.1f}%", blind_rp_t3, str(eff_rp_t3), str(conf_rp_t3), 
                                    str(other_rp_t3), str(iss_rp_t3), str(comp_rp_t3)],
            "reportPCP_tipping3": [f"{total_pcp:.3f}", f"{tipping3:.3f}", str(delta_res) if delta_res is not None else "N/A", 
                                f"{ov_pcp_t3}|{p_pcp_t3:.2f}", str(ov_pcp_t3),
                                str(cv_pcp_t3) if cv_pcp_t3 is not None else "N/A", str(cs_pcp_t3), 
                                str(cm_pcp_t3) if cm_pcp_t3 is not None else "N/A", str(cmech_pcp_t3), 
                                str(tc_pcp_t3) if tc_pcp_t3 is not None else "N/A",
                                f"{blind_ef_pcp_t3:.1f}%", blind_pcp_t3, str(eff_pcp_t3), str(conf_pcp_t3), 
                                str(other_pcp_t3), str(iss_pcp_t3), str(comp_pcp_t3)]
        })
        self.logger.info(t3)
        self.logger.info("\nAnalysis completed successfully!")

        return ov_alt_t1, p_alt_t1, iss_alt_t1, comp_alt_t1, blind_ef_alt_t1, cv_alt_t1, cs_alt_t1, cm_alt_t1, tc_alt_t1, blind_alt_t1, conf_alt_t1, other_alt_t1, cmech_alt_t1, ov_rp_t1, p_rp_t1, iss_rp_t1, comp_rp_t1, blind_ef_rp_t1, cv_rp_t1, cs_rp_t1, cm_rp_t1, tc_rp_t1, blind_rp_t1, conf_rp_t1, other_rp_t1, cmech_rp_t1, ov_pcp_t1, p_pcp_t1, iss_pcp_t1, comp_pcp_t1, blind_ef_pcp_t1, cv_pcp_t1, cs_pcp_t1, cm_pcp_t1, tc_pcp_t1, blind_pcp_t1, conf_pcp_t1, other_pcp_t1, cmech_pcp_t1


    # # ====================== USAGE EXAMPLE ======================
    # if __name__ == "__main__":
    #     # Load your data
    #     df = pl.read_csv('/Users/liamtn/desktop/t2601139.csv')
    #     result = analyze_precip_qaqc_polar(df)