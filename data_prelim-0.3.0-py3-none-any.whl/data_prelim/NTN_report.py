__author__ = 'Liam TrinhNguyen'
__email__ =  'LiamTrinhNguyen@gmail.com or TrinhNguyen@wisc.edu'
__version__ = 'preLim v0.3.0'

import os, sys, psutil, logging, numpy as np, pandas as pd
from pathlib import Path
from logging.handlers import RotatingFileHandler
from datetime import datetime
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import FilePath, DirectoryPath

from .NTN_info import NTNInfoSettings, NTNInfo

class PipelineSettings(BaseSettings):
    output_dir: DirectoryPath 
    threshold: float = 0.05
    threshold_extreme: float = 0.30
    model_config = SettingsConfigDict(env_file=".env", env_prefix="WSLH_", extra="ignore")

class NTNReviewPipeline:
    def __init__(self, sampleID_start_log, sampleID_end_log, settings: PipelineSettings, output_subfolder: str = None):
        self.settings = settings
        self.output_root = self.settings.output_dir.resolve()
        self.sampleID_start_log = sampleID_start_log
        self.sampleID_end_log = sampleID_end_log

        self._log_dir = self.output_root / "logs"
        self._data_dir = self.output_root / "processed_data"
        
        if output_subfolder:
            self._data_dir = self._data_dir / output_subfolder
        else:
            self._data_dir = self._data_dir / f"{sampleID_start_log}_{sampleID_end_log}"
        
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = self._setup_logger()
        self.logger.info(f"Pipeline Report Initialized.")

    def __perform_vectorized_math(self, pre_mask: pd.DataFrame):
        """
        Flagging rows where totp != ppt 
        and where the variance between [PPT, totp] and sampleDepth > 5%.
        """
 
        ppt = pre_mask['PPT'].values.astype('float64').round(5)  
        totp = pre_mask['totp'].values.astype('float64').round(5)
        sample_depth = pre_mask['sampleDepth'].values.astype('float64').round(5)
        not_equal_mask = (np.abs(totp - ppt) / np.where(ppt == 0, np.inf, ppt)) >= self.settings.threshold
        safe_depth = np.where(sample_depth == 0, np.inf, sample_depth)
        
        diff_ppt = np.abs(ppt - sample_depth) / safe_depth
        diff_totp = np.abs(totp - sample_depth) / safe_depth
        variance_mask = (diff_ppt > self.settings.threshold) | (diff_totp > self.settings.threshold)
        
        variance_mask_1 = (diff_ppt > self.settings.threshold_extreme) | (diff_totp > self.settings.threshold_extreme)


        return  (variance_mask & (ppt != totp) & (ppt < sample_depth) & (sample_depth >= 0.09) & (ppt >= 0.09)) | (variance_mask_1 & (ppt == totp) & (ppt < sample_depth) & (sample_depth >= 0.09) & (ppt >= 0.09))
    
    def __perform_vectorized_math_goodSample(self, pre_mask: pd.DataFrame):
        """
        Rows where totp == ppt 
        and where the variance between [PPT, totp] and sampleDepth <= 5%.
        """
 
        ppt = pre_mask['PPT'].values.astype('float64').round(5)  
        totp = pre_mask['totp'].values.astype('float64').round(5)
        sample_depth = pre_mask['sampleDepth'].values.astype('float64').round(5)
        equal_mask = (totp == ppt)
        safe_depth = np.where(sample_depth == 0, np.inf, sample_depth)
        
        diff_ppt = np.abs(ppt - sample_depth) / safe_depth
        diff_totp = np.abs(totp - sample_depth) / safe_depth
        variance_mask = (diff_ppt <= self.settings.threshold) & (diff_totp <= self.settings.threshold)
        
        return  variance_mask & equal_mask

    def _setup_logger(self) -> logging.Logger:

        logger_name = f"WSLH_NTN.{self.__class__.__name__}"
        logger = logging.getLogger(logger_name)

        # Avoid adding handlers multiple times
        if logger.hasHandlers():
            return logger

        logger.propagate = False
        logger.setLevel(logging.INFO)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_path = Path(self._log_dir) / f"pipeline_{self.sampleID_start_log}_{self.sampleID_end_log}_{timestamp}.log"

        formatter = logging.Formatter(
            '%(asctime)s - [%(name)s] - %(levelname)s: %(message)s'
        )

        # === SINGLE FILE, NO SIZE LIMIT ===
        fh = logging.FileHandler(log_path, mode='a', encoding='utf-8', delay=False)
        fh.setFormatter(formatter)
        logger.addHandler(fh)

        # Console output
        ch = logging.StreamHandler()
        ch.setFormatter(formatter)
        logger.addHandler(ch)


        return logger
            

    @staticmethod
    def _prepare_for_excel(df: pd.DataFrame) -> pd.DataFrame:
        temp_df = df.copy()
        dt_cols = temp_df.select_dtypes(include=['datetime64[ns, UTC]', 'datetimetz']).columns
        for col in dt_cols:
            temp_df[col] = temp_df[col].dt.tz_localize(None)
        return temp_df

    def _get_reference_df(self) -> pd.DataFrame:
        not_a = ["Correction","Update E-gauge","Unusable E-gauge/ Missing Flagged", "E-gauge data good", "E-gauge data not complete/ Missing Flagged", "E-gauge data not complete/ Still usable","Incorrect data of precipReviewed samples"]
        no_ppt = ["Reload E-gauge/ Unusable/ Missing Flag","Correction","Update E-gauge","Reload E-gauge co-located site","Reload/ E-gauge data good", "Cannot reload E-gauge/ Missing Flagged", "E-gauge data not complete/ Missing Flagged", "E-gauge data complete/ usable","Incorrect data of precipReviewed samples"]
        TroubleFlag = ["Correction","Update E-gauge","Reload/ E-gauge data good", "Cannot reload E-gauge/ Missing Flagged", "E-gauge data not complete/ Missing Flagged", "E-gauge data complete/ usable","Incorrect data of precipReviewed samples"]
        REC_Late = ["REC late","Reload/ E-gauge data good","Update Code","Correction","Update E-gauge","Sample was extended due to Federal Government Shutdown", "Long sampling period", "Very long sampling period - COVID","Incorrect data of precipReviewed samples"]
        DFDK = ["Invalid DF/DK","DF/DK sample","Update Code","Correction","Update E-gauge","Update SP with Q code","Incorrect data of precipReviewed samples"]
        Possible_Reload = ["Correction","Update E-gauge","Reload/ E-gauge data good", "Cannot reload E-gauge/ Missing Flagged", "E-gauge data not complete/ Missing Flagged", "E-gauge data not complete/ Still usable", "Reload E-gauge/ Unusable/ Missing Flag", "Indeterminate E-gauge/ Missing Flagged"] 
        W_Zero_PPT_TOTP = ["Invalid W/WD/WI sample","Invalid DF/DK","Correction","Update E-gauge","E-gauge data good", "E-gauge data not complete/ Missing Flagged","Cannot use E-gauge data/ Missing Flagged", "Reload/ E-gauge data good", "Unusable E-gauge due to noise/ Missing Flagged"]
        D_NonZero_PPT_TOTP = ["Invalid D sample","Invalid DF/DK","Correction","Update E-gauge","E-gauge data good", "Cannot use E-gauge data/ Missing Flagged","Reload/ E-gauge data good","Unusable E-gauge due to noise/ Missing Flagged"]
        PPT_TOTP_sampleDepth_inconsistent = ["Correction","Update E-gauge","Reload/ E-gauge data good", "Cannot use E-gauge data/ Missing Flagged","Indeterminate E-gauge/ Missing Flagged","E-gauge data not complete/ Missing Flagged","E-gauge data not complete/ Still usable"]
        Bad_Record_precent = ["Correction","Reload/ E-gauge data good","Update E-gauge","Unusable E-gauge/ Missing Flagged", "E-gauge data good", "E-gauge data not complete/ Missing Flagged","Unusable E-gauge due to noise/ Missing Flagged"]
        excess_totp = ["Correction","Update E-gauge","E-gauge data good", "Cannot use E-gauge data/ Missing Flagged","Incorrect data of precipReviewed samples"]
        systematic_error = ["Cannot use E-gauge data/ Missing Flagged", "Systematic error/ Missing Flagged","E-gauge data good", "Correction","Update E-gauge"]     

        # Map column names to their respective lists
        data_dict = {
            'tab_MissingPPT': no_ppt,
            'tab_Possible_Reload': Possible_Reload,
            'tab_W_Zero_PPT_TOTP': W_Zero_PPT_TOTP,
            'tab_D_NonZero_PPT_TOTP': D_NonZero_PPT_TOTP,
            'tab_TroubleFlag': TroubleFlag,
            'tab_PPT_TOTP_sampleDepth_inconsistent': PPT_TOTP_sampleDepth_inconsistent,
            'tab_Not_a_has_ppt': not_a,
            'tab_REC_Late': REC_Late,
            'tab_DFDK': DFDK,
            'tab_Bad_Record_precent': Bad_Record_precent,
            'tab_excess_totp': excess_totp,
            'tab_systematic_error': systematic_error

        }
        
        # Convert lists to Series; pandas automatically aligns and pads with NaN
        df = pd.DataFrame({k: pd.Series(v) for k, v in data_dict.items()})
        
        # Optional: Replace NaN with None if your downstream logic strictly expects Python None types
        df = df.where(pd.notnull(df), None)
        
        return df

    @property
    def current_mem_usage(self) -> str:
        return f"{psutil.Process(os.getpid()).memory_info().rss / 1024**2:.1f}MB"

    def load_and_optimize(self, df: pd.DataFrame) -> pd.DataFrame:
        
        floats = df.select_dtypes(include=['float64']).columns
        df[floats] = df[floats].astype('float32')
        return df

    def sync_human_labels(self, excel_path: Path):
        """
        Ingests human edits from Excel and updates the Parquet Feature Store.
        Essential for ML Ground Truth.
        """
        self.logger.info(f"Syncing Human Labels from: {excel_path.name}")
        parquet_path = self._data_dir / "review_master.parquet"
        
        if not parquet_path.exists():
            self.logger.error("Sync failed: review_master.parquet does not exist.")
            return

        # Load human reviewed data (Not_a_has_ppt is the primary edit target)
        reviewed_df = pd.read_excel(excel_path, sheet_name="Not_a_has_ppt")
        master_df = pd.read_parquet(parquet_path)

        # Merge update using SITE and sampleStart as the composite key
        master_df.set_index(['SITE', 'sampleStart'], inplace=True)
        reviewed_df.set_index(['SITE', 'sampleStart'], inplace=True)
        
        # Update only the Action column
        master_df.update(reviewed_df[['Action']])
        
        master_df.reset_index().to_parquet(parquet_path, index=False)
        self.logger.info("Parquet Master updated with human labels.")

    def process_review(self, df: pd.DataFrame, sampleID_start, sampleID_end):
        try:
            
            self.logger.info(f"---- [PHASE 5]: finalizing report to review  ({sampleID_start} to {sampleID_end})")

            #convert data types and create new columns for review logic:
            min_labno = df['LABNO'].min()
            max_labno = df['LABNO'].max()
            df['percent_record'] = pd.to_numeric(df['percent_record'], errors='coerce')
            df['noisy_ratio_raw_pct_record'] = (
                                                df['noisy_ratio_raw_pct_record']
                                                .fillna(np.nan)                    # ensure real NaNs
                                                .astype(str)                       # convert to string
                                                .str.replace('%', '', regex=True)  # remove percentage sign
                                                .str.replace(r'[^\d.-]', '', regex=True)  # remove any non-numeric characters
                                                .str.strip()
                                                .replace('', np.nan)               # empty strings -> NaN
                                                .pipe(pd.to_numeric, errors='coerce')
                                            )
            df['sampleStart'] = pd.to_datetime(df['sampleStart'], utc=True)
            df['sampleEnd'] = pd.to_datetime(df['sampleEnd'], utc=True)
            df['RECDATE'] = pd.to_datetime(df['RECDATE'], utc=True)
            df['totp'] = df['totp'].astype('float64').round(5)
            df['PPT'] = df['PPT'].astype('float64').round(5)
            df['sampVol'] = df['sampVol'].astype('float64').round(5)
            df['sampleDepth'] = df['sampleDepth'].astype('float64').round(5)
            df['Start_End_diff'] = df['Start_End_diff'].astype('float64').round(5)
            df['SampleEnd_RECDATE'] = df['SampleEnd_RECDATE'].astype('float64').round(5)
            df['percent_record'] = df['percent_record'].astype('float64').round(5)
            df['noisy_ratio_raw_pct_record'] = df['noisy_ratio_raw_pct_record'].astype('float64').round(5)
            df['delta_reservoir'] = pd.to_numeric(df['delta_reservoir'], errors='coerce').round(5)
            df['sum_altPrecip'] = pd.to_numeric(df['sum_altPrecip'], errors='coerce').round(5)
            df['sum_altPrecip2'] = pd.to_numeric(df['sum_altPrecip2'], errors='coerce').round(5)
            df['sum_reportPrecip'] = pd.to_numeric(df['sum_reportPrecip'], errors='coerce').round(5)
            df['reportPCP'] = pd.to_numeric(df['reportPCP'], errors='coerce').round(5)
            df['delta_reservoir']=pd.to_numeric(df['delta_reservoir'], errors='coerce').round(5)
            def format_error_code(code, width: int = 5):
                    """
                    Robust formatter for error_code:
                    - If the value is numeric -> pad with leading zeros to given width
                    - If it contains letters (like 'F') or is non-numeric -> keep as-is
                    """
                    if pd.isna(code) or code is None:
                        return None                    # Keep as None / NaN
                    
                    code_str = str(code).strip()
                    # Try to convert to number safely
                    if pd.notna(pd.to_numeric(code_str, errors='coerce')):
                        try:
                            num = int(float(code_str))
                            return f"{num:0{width}d}"      # Dynamic width padding
                        except:
                            return code_str
                    else:
                        # Contains letters (e.g. 'F', '2F301', etc.)
                        return code_str
            df['error_code_NTN'] = df['error_code_NTN'].apply(lambda x: format_error_code(x, width=15))
            df['error_code_MDN'] = df['error_code_MDN'].apply(lambda x: format_error_code(x, width=15))
            df['error_code_CO'] = df['error_code_CO'].apply(lambda x: format_error_code(x, width=15))
            df['error_code'] = df['error_code'].apply(lambda x: format_error_code(x, width=7))
            df['error_code_median'] = df['error_code_median'].apply(lambda x: format_error_code(x, width=3))
            df['FOBS'] = df['FOBS'].apply(lambda x: format_error_code(x, width=3))




            
            
           
         
                        
            # df = add_auto_label(df)
            columns_to_drop = ['sum_altPrecip','sum_altPrecip2','sum_reportPrecip', 'relative_loss','relative_gain']
            columns_order_df= ['REVCOMM','LABNO','SITE','sampleStart','sampleEnd','Start_End_diff','RECDATE','SampleEnd_RECDATE','ScreenStat','LABC','sampVol','sampleDepth','totp'	,'PPT','corrected_PCP',
                               'reportPCP',	'SP','sl','QR','notes'	,'TroubleFlag','percent_record','percent_good_of_actual','noisy_ratio_raw_pct_record','FOBS',
                               'error_code_NTN'	,'error_code_MDN','error_code_CO','error_code','error_code_median','delta_reservoir']
            

            # sample has all good condition, no further review needed, can be accepted directly:
            pre_mask1 = df[df['PPT'].notna()].copy()
            is_good_math = self.__perform_vectorized_math_goodSample(pre_mask1)
            # 1. Define the columns you want to compare
            cols = ['delta_reservoir', 'sampleDepth', 'sum_reportPrecip']

            # 2. Get the max and min for each row across just those columns
            row_max = pre_mask1[cols].max(axis=1)
            row_min = pre_mask1[cols].min(axis=1)

            # 3. Create your boolean mask (Difference is <= 5% of the largest value)
            valid_mask = (row_max - row_min) <= (0.05 * row_max)
            all_collectors_bad = (
                df['error_code_NTN'].str.contains(r'^9[F]000000[F]000000', regex=True, na=False) &
                df['error_code_MDN'].str.contains(r'^9[F]000000[F]000000', regex=True, na=False) &
                df['error_code_CO'].str.contains(r'^9[F]000000[F]000000',  regex=True, na=False)
            )
            NTN_collectors_bad =(
                                    df['error_code_NTN'].str.contains(r'^[0-9][F]000000[F]000000', regex=True, na=False) &
                                    ((df['sampleDepth'] > 0.07) | (df['PPT'] > 0.07))
                                )
         

            # ====================== eGAUGE CRITICAL ======================
            err_first3 = df['error_code'].astype(str).str[:3].fillna('')

            egauge_critical = (
                (err_first3.str[0] == 'F') | 
                (err_first3.str[1] == 'F') | 
                (err_first3.str[2] == 'F')
            )
            # You can then apply this mask back to your dataframe
            # df_filtered = pre_mask1[valid_mask]
            df_good_sample = pre_mask1[
                (is_good_math) & 
                (pre_mask1['percent_record'] > 85) & 
                (pre_mask1['percent_good_of_actual'] > 90) &
                (pre_mask1['noisy_ratio_raw_pct_record'] < 10) & 
                (pre_mask1['FOBS'].isin([100, 101,102,111,112,121,120,122]) == False) &
                (valid_mask) &
                (~all_collectors_bad) &
                (~NTN_collectors_bad) &
                (~egauge_critical)
                # this condition is to capture samples where ppt and totp are consistent with each other and sampleDepth,
                #  but the delta reservoir is very close to sampleDepth, indicating a good sample with minor noise that may 
                #  have caused small variance in ppt/totp vs sampleDepth but overall good data quality. This allows us to flag these
                #    samples as good without further review, while still capturing potential reloads or egauge errors in other categories.
                ].copy()

            
           
            df_good_sample = df_good_sample.drop(columns=columns_to_drop, errors='ignore')
            df_good_sample = df_good_sample [columns_order_df + [col for col in df_good_sample.columns if col not in columns_order_df]]
            df_good_sample['review_category'] = 'Good_Sample'


            # missing PPT data: A1
            null_PPT = df[df['PPT'].isna()].copy()
            null_PPT = null_PPT.drop(columns=columns_to_drop, errors='ignore')
            null_PPT = null_PPT[columns_order_df + [col for col in null_PPT.columns if col not in columns_order_df]]
            null_PPT['review_category'] = 'Missing_PPT_Data'
            null_PPT.insert(0, 'Action', '')
            null_PPT.loc[null_PPT['SITE'].str.match(r'^(\d{2})([a-zA-Z]{2})$'), 'Action'] = 'Reload E-gauge co-located site'



            # sample with ppt data for review with ppt = totp = sampleDepth and percent_record > 97% and high noise as sample need deeper review: A2
            ppt_not_none = df['PPT'].notna()
            low_coverage = df['percent_record'] <= 85
            low_accuracy = df['percent_good_of_actual'] <= 85
            high_noise = df['noisy_ratio_raw_pct_record'] >= 45
            Bad_Record_precent = df[
                (ppt_not_none & (low_coverage | high_noise )) |
                (ppt_not_none & low_accuracy )|
                ((ppt_not_none &  high_noise ))
            ].copy()
            Bad_Record_precent = Bad_Record_precent.drop(columns=columns_to_drop, errors='ignore')
            Bad_Record_precent = Bad_Record_precent[columns_order_df + [col for col in Bad_Record_precent.columns if col not in columns_order_df]]
            Bad_Record_precent['review_category'] = 'Bad_Record_precent'
            Bad_Record_precent = Bad_Record_precent.sort_values(by=['noisy_ratio_raw_pct_record','percent_record', 'percent_good_of_actual'], ascending=[False,False, False])
            Bad_Record_precent.insert(0, 'Action', '')


            # --- df_W_Zero_ppt_totp --- A3
            excluded_indices_df_W_Zero_ppt_totp = (
                                null_PPT.index.tolist() + 
                                Bad_Record_precent.index.tolist()
                                )
            df_w = df[(~df['PPT'].isna()) & (df['LABC'].isin(['W', 'WI', 'WD'])) & (~df.index.isin(excluded_indices_df_W_Zero_ppt_totp))].copy() 
            df_W_Zero_ppt_totp = df_w[df_w['totp'] == 0.0].copy()
            df_W_Zero_ppt_totp = df_W_Zero_ppt_totp.drop(columns=columns_to_drop + ['ntn_bad', 'mdn_bad', 'co_bad'], errors='ignore')
            df_W_Zero_ppt_totp = df_W_Zero_ppt_totp[columns_order_df + [col for col in df_W_Zero_ppt_totp.columns if col not in columns_order_df]]
            df_W_Zero_ppt_totp = df_W_Zero_ppt_totp.sort_values(by=['noisy_ratio_raw_pct_record','percent_record', 'percent_good_of_actual'], ascending=[False,True, True])
            df_W_Zero_ppt_totp['review_category'] = 'W_Zero_PPT_TOTP'
            df_W_Zero_ppt_totp.insert(0, 'Action', '')

            # --- df_D_nonZero_ppt_totp --- A4
            excluded_indices_df_D_nonZero_ppt_totp = (
                                null_PPT.index.tolist() + 
                                Bad_Record_precent.index.tolist()
                                )
            df_d = df[(~df['PPT'].isna()) & (df['LABC'].isin(['D'])) & (~df.index.isin(excluded_indices_df_D_nonZero_ppt_totp))].copy()
            df_D_nonZero_ppt_totp = df_d[ 
                                        (df_d['PPT'] > 0.0) | (df_d['totp'] > 0.0) 
                                        ].copy()
            df_D_nonZero_ppt_totp = df_D_nonZero_ppt_totp.drop(columns=columns_to_drop + ['ntn_bad', 'mdn_bad', 'co_bad'], errors='ignore')
            df_D_nonZero_ppt_totp = df_D_nonZero_ppt_totp[columns_order_df + [col for col in df_D_nonZero_ppt_totp.columns if col not in columns_order_df]]
            df_D_nonZero_ppt_totp = df_D_nonZero_ppt_totp.sort_values(by=['noisy_ratio_raw_pct_record','percent_record', 'percent_good_of_actual'], ascending=[False,True, True])
            df_D_nonZero_ppt_totp['review_category'] = 'D_NonZero_PPT_TOTP'
            df_D_nonZero_ppt_totp.insert(0, 'Action', '')


            # Excess totp: totp > 6 micrometers which is highly unlikely and may indicate data issues or outliers that require review. A5
            df_excess_totp = df[(~df['totp'].isna()) & (df['totp'] > 6)].copy()
            df_excess_totp = df_excess_totp.drop(columns=columns_to_drop + ['ntn_bad', 'mdn_bad', 'co_bad'], errors='ignore')
            df_excess_totp = df_excess_totp[columns_order_df + [col for col in df_excess_totp.columns if col not in columns_order_df]]
            df_excess_totp['review_category'] = 'Excess_totp'
            df_excess_totp.insert(0, 'Action', '')


            # DFDK samples: LABC of D, DF, or DK with ppt data that may have specific known issues or require targeted review based on historical patterns or domain knowledge. A6
            df_DFDK = df[(df['LABC'] == 'DF') | (df['LABC'] == 'DK')].copy()           
            df_DFDK = df_DFDK.drop(columns=columns_to_drop + ['ntn_bad', 'mdn_bad', 'co_bad'], errors='ignore')
            df_DFDK = df_DFDK[columns_order_df + [col for col in df_DFDK.columns if col not in columns_order_df]] 
            df_DFDK['review_category'] = 'DFDK_sample'
            df_DFDK.insert(0, 'Action', '')
            df_DFDK.loc[df_DFDK['SP'] != 'Q', 'Action'] = 'Update SP with Q code'

             #`--- df_trouble_flag ---` A7
            excluded_indices_df_trouble_flag = (
                                null_PPT.index.tolist() + 
                                Bad_Record_precent.index.tolist()+
                                df_W_Zero_ppt_totp.index.tolist() + 
                                df_D_nonZero_ppt_totp.index.tolist() + 
                                df_excess_totp.index.tolist()+
                                df_DFDK.index.tolist()
                                )
            df_trouble_flag = df[(df['TroubleFlag'] == True) & (~df.index.isin(excluded_indices_df_trouble_flag))].copy()
            df_trouble_flag = df_trouble_flag.drop(columns=columns_to_drop + ['ntn_bad', 'mdn_bad', 'co_bad'], errors='ignore')
            df_trouble_flag = df_trouble_flag[columns_order_df + [col for col in df_trouble_flag.columns if col not in columns_order_df]]
            df_trouble_flag['review_category'] = 'Trouble_Flagged'
            df_trouble_flag.insert(0, 'Action', '')
            df_trouble_flag.loc[(df_trouble_flag['SP'] != 'X') | (df_trouble_flag['TroubleFlag'] != False), 'Action'] = ''


            
           
  
        

            

            


            
            

           

            #`--- df_PPT_TOTP_sampleDepth_inconsistent ---`
            excluded_indices_PPT_TOTP_sampleDepth_inconsistent = (
                null_PPT.index.tolist() +
                Bad_Record_precent.index.tolist() +
                df_W_Zero_ppt_totp.index.tolist() + 
                df_D_nonZero_ppt_totp.index.tolist() + 
                df_trouble_flag.index.tolist()+
                df_good_sample.index.tolist() 
            )
            mask = self.__perform_vectorized_math(pre_mask1)
            mask_ppt_totp_diff = (
                ((df['totp'] >= 0.07) | (df['PPT'] >= 0.07)) &  (df['totp'] < df['PPT']) & 
                (abs(df['PPT'] - df['totp']) / 
                ((abs(df['totp']) + abs(df['PPT'])) / 2).replace(0, np.nan) >= 0.15)
            )

            mask_ppt_depth_diff = (
                ((df['sampleDepth'] >= 0.07) | (df['PPT'] >= 0.07)) & (df['sampleDepth'] > df['PPT'] ) &
                (abs(df['PPT'] - df['sampleDepth']) / 
                ((abs(df['sampleDepth']) + abs(df['sampleDepth'])) / 2).replace(0, np.nan) >= 0.50)
            )
            PPT_TOTP_sampleDepth_inconsistent = df[
                                                    (mask_ppt_totp_diff | mask_ppt_depth_diff) & 
                                                    (~df.index.isin(excluded_indices_PPT_TOTP_sampleDepth_inconsistent))
                                                ].copy()
            PPT_TOTP_sampleDepth_inconsistent = PPT_TOTP_sampleDepth_inconsistent.drop(columns=columns_to_drop + ['ntn_bad', 'mdn_bad', 'co_bad'], errors='ignore')
            PPT_TOTP_sampleDepth_inconsistent = PPT_TOTP_sampleDepth_inconsistent[columns_order_df + [col for col in PPT_TOTP_sampleDepth_inconsistent.columns if col not in columns_order_df]]
            PPT_TOTP_sampleDepth_inconsistent = PPT_TOTP_sampleDepth_inconsistent.sort_values(by=['percent_record', 'percent_good_of_actual'], ascending=[False, False])
            PPT_TOTP_sampleDepth_inconsistent['review_category'] = 'PPT_TOTP_sampleDepth_inconsistent'
            PPT_TOTP_sampleDepth_inconsistent.insert(0, 'Action', '')


            # Not a:
            excluded_indices = (
                                null_PPT.index.tolist() +
                                Bad_Record_precent.index.tolist() +
                                df_W_Zero_ppt_totp.index.tolist() + 
                                df_D_nonZero_ppt_totp.index.tolist() + 
                                df_trouble_flag.index.tolist()+
                                df_good_sample.index.tolist()+
                                PPT_TOTP_sampleDepth_inconsistent.index.tolist()
                                )
            pre_mask2= pre_mask1[(pre_mask1['PPT'] != pre_mask1['totp']) &
                                (pre_mask1['PPT']>=0) & (pre_mask1['totp']>=0) &
                                ((np.abs(pre_mask1['PPT'] - pre_mask1['sampleDepth']) / np.where(pre_mask1['PPT'] == 0, np.inf, pre_mask1['PPT']) > self.settings.threshold) |
                                (np.abs(pre_mask1['totp'] - pre_mask1['sampleDepth']) / np.where(pre_mask1['totp'] == 0, np.inf, pre_mask1['totp']) > self.settings.threshold))
                                ].copy()
            
            df_not_a_has_ppt = pre_mask2[(pre_mask2['precipUsable'] != 'A') & 
                                         (~pre_mask2.index.isin(excluded_indices)) ].copy()
            df_not_a_has_ppt = df_not_a_has_ppt.drop(columns=columns_to_drop + ['ntn_bad', 'mdn_bad', 'co_bad'], errors='ignore')
            df_not_a_has_ppt = df_not_a_has_ppt[columns_order_df + [col for col in df_not_a_has_ppt.columns if col not in columns_order_df]] 
            df_not_a_has_ppt['review_category'] = 'Manual_Review_Required'
            df_not_a_has_ppt.insert(0, 'Action', '')


            

            # Start_End_diff greater than 8 days: Samples where the difference between sampleEnd and sampleStart is greater than 8 days, which may indicate potential issues with the sampling process, data entry errors, or unusual circumstances that warrant further investigation.
            df_StartEnd_Flag = df[df['PPT'].notna() & (df['Start_End_diff'] >= 8) & (~df['LABC'].isin(['D', 'T']))].copy()
            df_StartEnd_Flag = df_StartEnd_Flag.drop(columns=columns_to_drop + ['ntn_bad', 'mdn_bad', 'co_bad'], errors='ignore')
            df_StartEnd_Flag = df_StartEnd_Flag[columns_order_df + [col for col in df_StartEnd_Flag.columns if col not in columns_order_df]] 
            df_StartEnd_Flag = df_StartEnd_Flag.sort_values('Start_End_diff', ascending=False)
            df_StartEnd_Flag['review_category'] = 'Start_End_diff_Greater_8'
            df_StartEnd_Flag.insert(0, 'Action', '')
            df_StartEnd_Flag.loc[(df_StartEnd_Flag['QR'] != 'C') | (~df_StartEnd_Flag['notes'].str.contains('[e]', regex=True, na=False)), 'Action'] = 'incorrect QR/ No e in notes'
            
            
            # ENDREC_Late: Samples where the SampleEnd_RECDATE is 16 or more days after the sampleEnd date, which may indicate delays in processing, data entry errors, or other issues that require review. This flag is applied only to samples with ppt data and excludes certain LABC codes (D, DF, DK) that may have different review criteria or known issues.
            df_ENDREC_FLAG = df[df['PPT'].notna() & (df['SampleEnd_RECDATE'] >= 16) & (~df['LABC'].isin(['D', 'DF', 'DK', 'T']))].copy()
            df_ENDREC_FLAG = df_ENDREC_FLAG.drop(columns=columns_to_drop + ['ntn_bad', 'mdn_bad', 'co_bad'], errors='ignore')
            df_ENDREC_FLAG = df_ENDREC_FLAG[columns_order_df + [col for col in df_ENDREC_FLAG.columns if col not in columns_order_df]] 
            df_ENDREC_FLAG = df_ENDREC_FLAG.sort_values('SampleEnd_RECDATE', ascending=False)
            df_ENDREC_FLAG.insert(0, 'Action', '')
            df_ENDREC_FLAG.loc[(df_ENDREC_FLAG['SampleEnd_RECDATE'] <= 60) & (~df_ENDREC_FLAG['notes'].str.contains('[h]', regex=True, na=False)), 'Action'] = ' No h in notes'
            df_ENDREC_FLAG.loc[(df_ENDREC_FLAG['SampleEnd_RECDATE'] > 60) & (~df_ENDREC_FLAG['notes'].str.contains('[f]', regex=True, na=False)), 'Action'] = ' No f in notes'
               # combine notes of other condition:
            conditions_ENDREC = [
                df_ENDREC_FLAG['notes'].str.contains('[bceflnpuv]', regex=True, na=False), 
                df_ENDREC_FLAG['notes'].str.contains('[adhimqz]', regex=True, na=False)    
            ]
            expected_qrs = ['C', 'B']
            df_ENDREC_FLAG['Expected_QR'] = np.select(conditions_ENDREC, expected_qrs, default=None)
            is_incorrect = (df_ENDREC_FLAG['Expected_QR'].notna()) & (df_ENDREC_FLAG['QR'] != df_ENDREC_FLAG['Expected_QR'])
            df_ENDREC_FLAG.loc[is_incorrect, 'Action'] += 'Incorrect QR'
            df_ENDREC_FLAG = df_ENDREC_FLAG.drop(columns=['Expected_QR'])
       

            # Hold ScreenStat: Samples that have a ScreenStat of "Hold" but do not meet any of the other specific review criteria, indicating that they may require manual review to determine the appropriate action or categorization. This category serves as a catch-all for samples that are flagged for holding but do not fall into the more defined categories based on the other flags and criteria.
            excluded_indices_hold = (
                                null_PPT.index.tolist() +
                                Bad_Record_precent.index.tolist() +
                                df_W_Zero_ppt_totp.index.tolist() + 
                                df_D_nonZero_ppt_totp.index.tolist() + 
                                df_trouble_flag.index.tolist()+
                                PPT_TOTP_sampleDepth_inconsistent.index.tolist()+
                                df_StartEnd_Flag.index.tolist()+
                                df_ENDREC_FLAG.index.tolist()+
                                df_DFDK.index.tolist()+
                                df_excess_totp.index.tolist()+
                                df_not_a_has_ppt.index.tolist()
                                )
            df_hold = df[~df.index.isin(excluded_indices_hold) & (df['ScreenStat'] == 'Hold')].copy()
            df_hold['review_category'] = 'Hold_ScreenStat'
            df_hold.insert(0, 'Action', '')
            df_hold = df_hold.drop(columns=columns_to_drop + ['ntn_bad', 'mdn_bad', 'co_bad'], errors='ignore')
            df_hold = df_hold[columns_order_df + [col for col in df_hold.columns if col not in columns_order_df]] 



            
            

            df_accepted = df[~df.index.isin(
                                null_PPT.index.tolist() +
                                Bad_Record_precent.index.tolist() +
                                df_W_Zero_ppt_totp.index.tolist() + 
                                df_D_nonZero_ppt_totp.index.tolist() + 
                                df_trouble_flag.index.tolist()+
                                PPT_TOTP_sampleDepth_inconsistent.index.tolist()+
                                df_StartEnd_Flag.index.tolist()+
                                df_ENDREC_FLAG.index.tolist()+
                                df_DFDK.index.tolist()+
                                df_excess_totp.index.tolist()+
                                df_not_a_has_ppt.index.tolist()
            )].copy()
            df_accepted = df_accepted.drop(columns=columns_to_drop + ['ntn_bad', 'mdn_bad', 'co_bad'], errors='ignore')
            df_accepted = df_accepted[columns_order_df + [col for col in df_accepted.columns if col not in columns_order_df]] 
            
            df_accepted['review_category'] = 'Accepted'
            df_accepted.insert(0, 'Action', '')
             # combine notes of other condition:
            conditions_ACCEPTED = [
                df_accepted['notes'].str.contains('[bceflnpuv]', regex=True, na=False), 
                df_accepted['notes'].str.contains('[adhimqz]', regex=True, na=False)    
            ]
            expected_qrs = ['C', 'B']
            df_accepted['Expected_QR'] = np.select(conditions_ACCEPTED, expected_qrs, default=None)
            is_incorrect = (df_accepted['Expected_QR'].notna()) & (df_accepted['QR'] != df_accepted['Expected_QR'])
            df_accepted.loc[is_incorrect, 'Action'] += 'Incorrect QR'
            df_accepted = df_accepted.drop(columns=['Expected_QR'])


            excluded_indices_df_non_inany = (
                                null_PPT.index.tolist() +
                                Bad_Record_precent.index.tolist() +
                                df_W_Zero_ppt_totp.index.tolist() + 
                                df_D_nonZero_ppt_totp.index.tolist() + 
                                df_trouble_flag.index.tolist()+
                                PPT_TOTP_sampleDepth_inconsistent.index.tolist()+
                                df_StartEnd_Flag.index.tolist()+
                                df_ENDREC_FLAG.index.tolist()+
                                df_DFDK.index.tolist()+
                                df_excess_totp.index.tolist()+
                                df_not_a_has_ppt.index.tolist()+
                                df_accepted.index.to_list()+
                                df_hold.index.to_list()
                                )



            df_non_inany= df[~df.index.isin(excluded_indices_df_non_inany) ].copy()

            

            


           

            # 1. PERSISTENCE: Save Parquet (Draft)
            output_dir = Path(self._data_dir)
            output_dir.mkdir(parents=True, exist_ok=True)

            master_df = pd.concat([null_PPT, df_not_a_has_ppt, df_trouble_flag, df_DFDK, df_StartEnd_Flag, df_ENDREC_FLAG], axis=0, ignore_index=True)
            parquet_out = output_dir / "review_master.parquet"
            master_df.to_parquet(parquet_out, index=False, engine='pyarrow')

            # 3. PERSISTENCE: Save Excel (Interactive Human View)
            self.logger.info(f"---- [REPORT NAME]: Review_{min_labno}_{max_labno}.xlsx in output directory: {output_dir}")

            excel_out = output_dir / f"Review_{min_labno}_{max_labno}.xlsx"
            ref_df = self._get_reference_df()
            
            df_original = df.copy()
            df_original = df_original.drop(columns=columns_to_drop + ['ntn_bad', 'mdn_bad', 'co_bad'], errors='ignore')
            df_original = df_original[columns_order_df + [col for col in df_original.columns if col not in columns_order_df]] 
            # Using xlsxwriter to support data validation
            with pd.ExcelWriter(excel_out, engine='xlsxwriter') as writer:
                # Write Reference Sheet
                ref_df.to_excel(writer, sheet_name="Reference_Notes", index=False)
                
                # Write Data Sheets
                self._prepare_for_excel(df_original).to_excel(writer, sheet_name="Original_Data", index=False)
                self._prepare_for_excel(df_good_sample).to_excel(writer, sheet_name="good_sample", index=False)
                self._prepare_for_excel(df_accepted).to_excel(writer, sheet_name="Accepted", index=False)

                self._prepare_for_excel(null_PPT).to_excel(writer, sheet_name="Missing_ppt", index=False) #A1
                self._prepare_for_excel(Bad_Record_precent).to_excel(writer, sheet_name="Bad_Record_percent", index=False) #A2
                self._prepare_for_excel(df_W_Zero_ppt_totp).to_excel(writer, sheet_name="W_Zero_PPT_TOTP", index=False)
                self._prepare_for_excel(df_D_nonZero_ppt_totp).to_excel(writer, sheet_name="D_NonZero_PPT_TOTP", index=False)
                self._prepare_for_excel(df_excess_totp).to_excel(writer, sheet_name="Excess_totp", index=False)
                self._prepare_for_excel(df_DFDK).to_excel(writer, sheet_name="DFDK_samples", index=False)
                self._prepare_for_excel(df_trouble_flag).to_excel(writer, sheet_name="Trouble_Flagged", index=False)



                self._prepare_for_excel(PPT_TOTP_sampleDepth_inconsistent).to_excel(writer, sheet_name="PPT_TOTP_Depth_inconsistent", index=False) #3
                
                
                
                
                self._prepare_for_excel(df_not_a_has_ppt).to_excel(writer, sheet_name="Not_a_has_ppt", index=False)
                self._prepare_for_excel(df_StartEnd_Flag).to_excel(writer, sheet_name="Start_End_diff_Greater_8", index=False)
                self._prepare_for_excel(df_ENDREC_FLAG).to_excel(writer, sheet_name="ENDREC_Late", index=False)
                
                self._prepare_for_excel(df_hold).to_excel(writer, sheet_name="Hold_ScreenStat", index=False)
                self._prepare_for_excel(df_non_inany).to_excel(writer, sheet_name="non_inany", index=False)

                # --- WORKBOOK & FORMAT SETUP ---
                workbook = writer.book
                fmt_center = workbook.add_format({'align': 'center', 'valign': 'vcenter'})
                fmt_red_bold_center = workbook.add_format({
                                                            'align': 'center', 
                                                            'valign': 'vcenter',
                                                            'bold': True,
                                                            'font_color': "#DB0404" # Red text
                                                        })

                for sheet_name, worksheet in writer.sheets.items():
                    # 1. Freeze the first row
                    worksheet.freeze_panes(1, 0)
                    
                    # 2. Center all columns
                    worksheet.set_column('A:Z', None, fmt_center)

              
                    
                    # 3. Auto-fit column widths
                    try:
                        worksheet.autofit()
                    except:
                        # Fallback if your XlsxWriter version doesn't support autofit()
                        worksheet.set_column('A:Z', 20)

                
                # Define the colors
                fmt_orange = workbook.add_format({'bg_color': '#FFC000', 'font_color': '#000000'}) # Orange for empty
                fmt_green = workbook.add_format({'bg_color': '#C6EFCE', 'font_color': '#006100'})  # Green for selected
                fmt_darkgreen = workbook.add_format({'bg_color': '#006100', 'font_color': '#FFFFFF', 'bold': True})  # Dark green for selected

                options_no_ppt = ["Reload E-gauge/ Unusable/ Missing Flag","Correction"," Reload E-gauge co-located site","Update E-gauge","Reload/ E-gauge data good", "Cannot reload E-gauge/ Missing Flagged", "E-gauge data not complete/ Missing Flagged", "E-gauge data complete/ usable"]
                options_Bad_Record_precent= ["Reload/ E-gauge data good","Unusable E-gauge due to noise/ Missing Flagged","Correction","Update E-gauge","Unusable E-gauge/ Missing Flagged", "E-gauge data good", "E-gauge data not complete/ Missing Flagged"]
                options_df_W_Zero_ppt_totp = ["Invalid W/WD/WI sample","Invalid DF/DK","Unusable E-gauge due to noise/ Missing Flagged","Correction","Update E-gauge","E-gauge data good", "E-gauge data not complete/ Missing Flagged","Cannot use E-gauge data/ Missing Flagged", "Reload/ E-gauge data good"]
                options_df_D_nonZero_ppt_totp = ["Invalid D sample","Invalid DF/DK","Invalid D sample","Unusable E-gauge due to noise/ Missing Flagged","Correction","Update E-gauge","E-gauge data good", "Cannot use E-gauge data/ Missing Flagged","Reload/ E-gauge data good",""]
                options_excess_totp = ["Correction","Update E-gauge","E-gauge data good", "Cannot use E-gauge data/ Missing Flagged"]
                options_DFDK = ["Invalid DF/DK","DF/DK sample","Correction","Update E-gauge","Update SP with Q code"]
                options_trouble = ["Incorrect data of precipReviewed samples","Correction","Update E-gauge","Reload/ E-gauge data good", "Cannot reload E-gauge/ Missing Flagged", "E-gauge data not complete/ Missing Flagged", "E-gauge data complete/ usable"]
                
                
                
                options_Late = ["REC late","Reload/ E-gauge data good","Correction","Update E-gauge","Sample was extended due to Federal Government Shutdown", "Long sampling period", "Very long sampling period - COVID"]
                options_reload = ["Indeterminate E-gauge/ Missing Flagged","Correction","Update E-gauge","Reload/ E-gauge data good", "Cannot reload E-gauge/ Missing Flagged", "E-gauge data not complete/ Missing Flagged", "E-gauge data not complete/ Still usable", "Reload E-gauge/ Unusable/ Missing Flag "] 
                options_not_a = ["Correction","Update E-gauge","Unusable E-gauge/ Missing Flagged", "E-gauge data good", "E-gauge data not complete/ Missing Flagged", "E-gauge data not complete/ Still usable"]

                options_PPT_TOTP_sampleDepth_inconsistent = ["Correction","Update E-gauge","Reload/ E-gauge data good", "Cannot use E-gauge data/ Missing Flagged","Indeterminate E-gauge/ Missing Flagged","E-gauge data not complete/ Missing Flagged","E-gauge data not complete/ Still usable"]
              
                # --- APPLY DROPDOWNS & CONDITIONAL COLORING ---
                #reference dataframe
               # 1. Flatten all columns and clean the data
                # We remove spaces and dashes here to match the 'Bulletproof' logic
                unique_ref_list = (
                                        ref_df.stack()
                                        .astype(str)
                                        .str.replace(" ", "", regex=False)   # Remove spaces
                                        .str.replace("-", "", regex=False)   # Remove dashes
                                        .str.replace("/", "", regex=False)   # Remove slashes
                                        .str.strip()
                                        .replace(['nan', 'None', 'NAN'], pd.NA)
                                        .dropna()
                                        .unique()
                                    )

                # 2. Write to the Reference sheet
                final_ref_df = pd.DataFrame(unique_ref_list, columns=['Master_Reference'])
                final_ref_df.to_excel(writer, sheet_name="Reference_Notes", index=False)

                # 3. Define the Excel range for the formula
                ref_rows = len(final_ref_df)
                ref_range = f'Reference_Notes!$A$2:$A${ref_rows + 1}'

                bulletproof_criteria = (
                                        f'=AND(OR($J2="Reviewed", $J2="Published"), '
                                        f'SUMPRODUCT(--ISNUMBER(SEARCH("|" & {ref_range} & "|", '
                                        f'SUBSTITUTE(SUBSTITUTE(SUBSTITUTE("|" & SUBSTITUTE(SUBSTITUTE(SUBSTITUTE($B2, ";", "|"), ",", "|"), ".", "|") & "|", " ", ""), "-", ""), "/", "")))) > 0)'
                                        )



                # 1. Not_a_has_ppt
                ws_not_a = writer.sheets['Not_a_has_ppt']
                last_row_ws_not_a, last_col_ws_not_a = len(df_not_a_has_ppt), len(df_not_a_has_ppt.columns) - 1
                ws_not_a.data_validation(1, 0, last_row_ws_not_a, 0, {'validate': 'list', 'source': options_not_a})
                ws_not_a.conditional_format(1, 0, last_row_ws_not_a, last_col_ws_not_a, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_not_a.conditional_format(1, 0, last_row_ws_not_a, last_col_ws_not_a, {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green})
                ws_not_a.conditional_format(1, 0, last_row_ws_not_a, last_col_ws_not_a, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                

                # 2. Missing_ppt
                ws_miss = writer.sheets['Missing_ppt']
                last_row_ws_miss, last_col_ws_miss = len(null_PPT), len(null_PPT.columns) - 1
                ws_miss.data_validation(1, 0, last_row_ws_miss, 0, {'validate': 'list', 'source': options_no_ppt})
    
      


                #dark green rule where reviewed  +  other comment in B column:
                ws_miss.conditional_format(1, 0, last_row_ws_miss, last_col_ws_miss, {
                    'type': 'formula',
                    'criteria': bulletproof_criteria,   
                    'format': fmt_darkgreen
                })

                # The Green Rule
                ws_miss.conditional_format(1, 0, last_row_ws_miss, last_col_ws_miss, {
                    'type': 'formula',
                    'criteria': f'AND($A2<>"", $A2<>"Reload E-gauge co-located site")',
                    'format': fmt_green
                })

                # The Orange Rule (Keep this below the green one or set 'stop_if_true')
                ws_miss.conditional_format(1, 0, last_row_ws_miss, last_col_ws_miss, {
                    'type': 'formula', 
                    'criteria': '=$A2=""', 
                    'format': fmt_orange
                })
                

               

                # 4. Bad_Record_precent
                ws_bad = writer.sheets['Bad_Record_percent']
                last_row_ws_bad, last_col_ws_bad = len(Bad_Record_precent), len(Bad_Record_precent.columns) - 1
                ws_bad.data_validation(1, 0, last_row_ws_bad, 0, {'validate': 'list', 'source': options_Bad_Record_precent})
                ws_bad.conditional_format(1, 0, last_row_ws_bad, last_col_ws_bad, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_bad.conditional_format(1, 0, last_row_ws_bad, last_col_ws_bad, {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green})
                ws_bad.conditional_format(1, 0, last_row_ws_bad, last_col_ws_bad, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                

                # 5. W_Zero_PPT_TOTP
                ws_wz = writer.sheets['W_Zero_PPT_TOTP']
                last_row_ws_wz, last_col_ws_wz = len(df_W_Zero_ppt_totp), len(df_W_Zero_ppt_totp.columns) - 1
                ws_wz.data_validation(1, 0, last_row_ws_wz, 0, {'validate': 'list', 'source': options_df_W_Zero_ppt_totp})
                ws_wz.conditional_format(1, 0, last_row_ws_wz, last_col_ws_wz, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})

                ws_wz.conditional_format(1, 0, last_row_ws_wz, last_col_ws_wz, {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green})
                ws_wz.conditional_format(1, 0, last_row_ws_wz, last_col_ws_wz, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                

                # 6. D_NonZero_PPT_TOTP
                ws_dnz = writer.sheets['D_NonZero_PPT_TOTP']
                last_row_ws_dnz, last_col_ws_dnz = len(df_D_nonZero_ppt_totp), len(df_D_nonZero_ppt_totp.columns) - 1
                ws_dnz.data_validation(1, 0, last_row_ws_dnz, 0, {'validate': 'list', 'source': options_df_D_nonZero_ppt_totp})
                ws_dnz.conditional_format(1, 0, last_row_ws_dnz, last_col_ws_dnz, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_dnz.conditional_format(1, 0, last_row_ws_dnz, last_col_ws_dnz, {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green})
                ws_dnz.conditional_format(1, 0, last_row_ws_dnz, last_col_ws_dnz, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                

                # 7. Trouble_Flagged
                ws_trb = writer.sheets['Trouble_Flagged']
                last_row_ws_trb, last_col_ws_trb = len(df_trouble_flag), len(df_trouble_flag.columns) - 1
                ws_trb.data_validation(1, 0, last_row_ws_trb, 0, {'validate': 'list', 'source': options_trouble})
                ws_trb.conditional_format(1, 0, last_row_ws_trb, last_col_ws_trb, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_trb.conditional_format(1, 0, last_row_ws_trb, last_col_ws_trb, {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green})
                ws_trb.conditional_format(1, 0, last_row_ws_trb, last_col_ws_trb, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                

                # 8. ENDREC_Late
                ws_late = writer.sheets['ENDREC_Late']
                last_row_ws_late, last_col_ws_late = len(df_ENDREC_FLAG), len(df_ENDREC_FLAG.columns) - 1
                ws_late.data_validation(1, 0, last_row_ws_late, 0, {'validate': 'list', 'source': options_Late})
                ws_late.conditional_format(1, 0, last_row_ws_late, last_col_ws_late, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_late.conditional_format(1, 0, last_row_ws_late, last_col_ws_late, {'type': 'formula', 'criteria': '=AND($A2<>"", $A2<>" No h in notes", $A2<>" No f in notes")', 'format': fmt_green})
                ws_late.conditional_format(1, 0, last_row_ws_late, last_col_ws_late, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                ws_late.conditional_format(1, 0, last_row_ws_late, last_col_ws_late, {'type': 'formula', 'criteria':  '=OR($A2=" No h in notes", $A2=" No f in notes")', 'format': fmt_orange})
                

                # 9. Start_End_diff_Greater_8
                ws_se = writer.sheets['Start_End_diff_Greater_8']
                last_row_ws_se, last_col_ws_se = len(df_StartEnd_Flag), len(df_StartEnd_Flag.columns) - 1
                ws_se.data_validation(1, 0, last_row_ws_se, 0, {'validate': 'list', 'source': options_Late})
                ws_se.conditional_format(1, 0, last_row_ws_se, last_col_ws_se, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_se.conditional_format(1, 0, last_row_ws_se, last_col_ws_se, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                ws_se.conditional_format(1, 0, last_row_ws_se, last_col_ws_se, {'type': 'formula', 'criteria': '=$A2="incorrect QR/ No e in notes"', 'format': fmt_orange})

                # 10. DFDK_samples
                ws_dfdk = writer.sheets['DFDK_samples']
                last_row_ws_dfdk, last_col_ws_dfdk = len(df_DFDK), len(df_DFDK.columns) - 1
                ws_dfdk.data_validation(1, 0, last_row_ws_dfdk, 0, {'validate': 'list', 'source': options_DFDK})
                ws_dfdk.conditional_format(1, 0, last_row_ws_dfdk, last_col_ws_dfdk, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_dfdk.conditional_format(1, 0, last_row_ws_dfdk, last_col_ws_dfdk, {'type': 'formula', 'criteria': '=AND($A2<>"", $A2<>"Update SP with Q code")', 'format': fmt_green})
                ws_dfdk.conditional_format(1, 0, last_row_ws_dfdk, last_col_ws_dfdk, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                ws_dfdk.conditional_format(1, 0, last_row_ws_dfdk, last_col_ws_dfdk, {'type': 'formula', 'criteria': '=$A2="Update SP with Q code"', 'format': fmt_orange})
                

                # 11. PPT_TOTP_Depth_inconsistent
                ws_inc = writer.sheets['PPT_TOTP_Depth_inconsistent']
                last_row_ws_inc, last_col_ws_inc = len(PPT_TOTP_sampleDepth_inconsistent), len(PPT_TOTP_sampleDepth_inconsistent.columns) - 1
                ws_inc.data_validation(1, 0, last_row_ws_inc, 0, {'validate': 'list', 'source': options_PPT_TOTP_sampleDepth_inconsistent})
                ws_inc.conditional_format(1, 0, last_row_ws_inc, last_col_ws_inc, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_inc.conditional_format(1, 0, last_row_ws_inc, last_col_ws_inc, {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green})
                ws_inc.conditional_format(1, 0, last_row_ws_inc, last_col_ws_inc, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                

                # 12. Excess_totp
                ws_exc = writer.sheets['Excess_totp']
                last_row_ws_exc, last_col_ws_exc = len(df_excess_totp), len(df_excess_totp.columns) - 1
                ws_exc.data_validation(1, 0, last_row_ws_exc, 0, {'validate': 'list', 'source': options_excess_totp})
                ws_exc.conditional_format(1, 0, last_row_ws_exc, last_col_ws_exc, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_exc.conditional_format(1, 0, last_row_ws_exc, last_col_ws_exc, {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green})
                ws_exc.conditional_format(1, 0, last_row_ws_exc, last_col_ws_exc, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})

                # 13. systematic error (the condition is changing , also make strong indicator in specific column)
                bulletproof_criteria_Systematic_Error = (
                                        f'=AND(OR($N2="Reviewed", $N2="Published"), '
                                        f'SUMPRODUCT(--ISNUMBER(SEARCH("|" & {ref_range} & "|", '
                                        f'SUBSTITUTE(SUBSTITUTE(SUBSTITUTE("|" & SUBSTITUTE(SUBSTITUTE(SUBSTITUTE($B2, ";", "|"), ",", "|"), ".", "|") & "|", " ", ""), "-", ""), "/", "")))) > 0)'
                                        )
                # --- SPECIAL RED-COLUMN OVERRIDE FORMATS ---
                # Base format for the column (when no conditional formatting is active)
                fmt_red_bold_center = workbook.add_format({
                    'align': 'center', 'valign': 'vcenter', 'bold': True, 'font_color': '#FF0000'
                })

                # Conditional formats tailored for the red column (Keeps BG color + forces Red/Bold text)
                fmt_orange_red_text = workbook.add_format({
                    'bg_color': '#FFC000', 'font_color': '#FF0000', 'bold': True, 'align': 'center', 'valign': 'vcenter'
                })
                fmt_green_red_text = workbook.add_format({
                    'bg_color': '#C6EFCE', 'font_color': '#FF0000', 'bold': True, 'align': 'center', 'valign': 'vcenter'
                })
                # Note: For dark green background, red text can be unreadable, so we keep bold white text, 
                # but you can change 'font_color' to '#FF0000' below if you strictly want red text on dark green.
                fmt_darkgreen_red_text = workbook.add_format({
                    'bg_color': '#006100', 'font_color': "#F5A906", 'bold': True, 'align': 'center', 'valign': 'vcenter'
                })


                # ws_egauge = writer.sheets['Systematic_Error']
                # target_col = df_systematic_error.columns.get_loc(('SITE')) 

                # last_row_ws_egauge, last_col_ws_egauge = len(df_systematic_error), len(df_systematic_error.columns) - 1
                # ws_egauge.data_validation(1, 0, last_row_ws_egauge, 0, {'validate': 'list', 'source': options_systematic_error})
                # if target_col > 0:
                #     ws_egauge.conditional_format(1, 0, last_row_ws_egauge, target_col - 1, 
                #         {'type': 'formula', 'criteria': bulletproof_criteria_Systematic_Error, 'format': fmt_darkgreen})
                #     ws_egauge.conditional_format(1, 0, last_row_ws_egauge, target_col - 1, 
                #         {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green})
                #     ws_egauge.conditional_format(1, 0, last_row_ws_egauge, target_col - 1, 
                #         {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})

                # # Apply rules strictly to your SPECIAL RED COLUMN (using the combined formats)
                # ws_egauge.conditional_format(1, target_col, last_row_ws_egauge, target_col, 
                #     {'type': 'formula', 'criteria': bulletproof_criteria_Systematic_Error, 'format': fmt_darkgreen_red_text})
                # ws_egauge.conditional_format(1, target_col, last_row_ws_egauge, target_col, 
                #     {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green_red_text})
                # ws_egauge.conditional_format(1, target_col, last_row_ws_egauge, target_col, 
                #     {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange_red_text})

                # # Apply rules to columns AFTER your special red column
                # if target_col < last_col_ws_egauge:
                #     ws_egauge.conditional_format(1, target_col + 1, last_row_ws_egauge, last_col_ws_egauge, 
                #         {'type': 'formula', 'criteria': bulletproof_criteria_Systematic_Error, 'format': fmt_darkgreen})
                #     ws_egauge.conditional_format(1, target_col + 1, last_row_ws_egauge, last_col_ws_egauge, 
                #         {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green})
                #     ws_egauge.conditional_format(1, target_col + 1, last_row_ws_egauge, last_col_ws_egauge, 
                #         {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                    

            
        except Exception as e:
            self.logger.error(f"Error during processing: {e}")
            raise

def run():
    try:
        pipeline = NTNReviewPipeline(PipelineSettings())
        
        # --- STAGE 1: Process and Export ---
        data = pipeline.load_and_optimize()
        pipeline.process_review(data)
        
        # --- STAGE 2: Sync (Manual Trigger) ---
        # After the lab tech saves the Excel file, uncomment the line below to update Parquet:
        # pipeline.sync_human_labels(pipeline._data_dir / "Review_Report.xlsx")
        
    except Exception as e:
        print(f"CRITICAL ERROR: {e}")
        sys.exit(1)
