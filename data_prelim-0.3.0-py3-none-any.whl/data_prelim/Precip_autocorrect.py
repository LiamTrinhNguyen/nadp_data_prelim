__author__ = 'Liam TrinhNguyen'
__email__ = 'LiamTrinhNguyen@gmail.com or TrinhNguyen@wisc.edu'
__version__ = 'preLim v0.3.0'

import os, sys, psutil, logging, numpy as np, pandas as pd, itertools
from pathlib import Path
from logging.handlers import RotatingFileHandler
from datetime import datetime
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import FilePath, DirectoryPath

# set pandas options for full display
pd.set_option('display.max_columns', None)
pd.set_option('display.max_colwidth', None)


class Autocorrect_Settings(BaseSettings):
    output_dir: DirectoryPath     
    model_config = SettingsConfigDict(env_file=".env", env_prefix="WSLH_", extra="ignore")


class PrecipAutocorrect:
    def __init__(self, sampleID_start_log, sampleID_end_log,settings: Autocorrect_Settings):
        self.settings = settings
        self.output_root = self.settings.output_dir.resolve()
        
        self._log_dir = self.output_root / "logs"
        self._data_dir = self.output_root / "processed_data"
        self.sampleID_start_log = sampleID_start_log
        self.sampleID_end_log = sampleID_end_log
        
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = self._setup_logger()
        self.logger.info(f"Autocorrect Settings Initialized.")
    
    def _setup_logger(self) -> logging.Logger:

        logger_name = f"WSLH_NTN.{self.__class__.__name__}"
        logger = logging.getLogger(logger_name)

        # Avoid adding handlers multiple times
        if logger.hasHandlers():
            return logger

        logger.propagate = False
        logger.setLevel(logging.INFO)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_path = Path(self._log_dir) / f"pipeline_{self.sampleID_start_log}_{self.sampleID_end_log}_{timestamp}.log"

        formatter = logging.Formatter(
            '%(asctime)s - [%(name)s] - %(levelname)s: %(message)s'
        )

        # === SINGLE FILE, NO SIZE LIMIT ===
        fh = logging.FileHandler(log_path, mode='a', encoding='utf-8', delay=False)
        fh.setFormatter(formatter)
        logger.addHandler(fh)

        # Console output
        ch = logging.StreamHandler()
        ch.setFormatter(formatter)
        logger.addHandler(ch)


        return logger

    # ========================== CORE FUNCTIONS ==========================
    def detect_false_precip(self, df: pd.DataFrame,
                            siteID,
                            time_col: str = 'LocalReportDateTime',
                            bucket_col: str = 'ActDepth',
                            precip_col: str = 'reportPCP',
                            temp_col: str = 'ActTemp',
                            threshold: float = 0.007) -> pd.DataFrame: # False Precip flag ‘f’ (load cell drops ≥ 0.007 inches while reporting rain)
        if 'siteID' in df.columns:
            site_id = str(df['siteID'].iloc[0])
        else:
            site_id = "UNKNOWN"
        df = df.copy()
        df[time_col] = pd.to_datetime(df[time_col])
        df = df.sort_values(time_col).reset_index(drop=True)
        df['delta_bucket'] = df[bucket_col].diff()
        df['delta_temp'] = df[temp_col].diff()
        false_mask = (df['delta_bucket'] <= -threshold) & (df[precip_col] > 0)
        df['false_precip_flag'] = False
        df.loc[false_mask, 'false_precip_flag'] = True
        n_false = false_mask.sum()

        self.logger.info(f"Site {siteID}: Detected {n_false:,} false precip records (SOP flag 'f')")

        # === Log details of the false records ===
        false_periods = []
        max_false_hours = 0.0
        if n_false > 0:
            df['false_group'] = (df['false_precip_flag'].astype(int).diff().ne(0)).cumsum()
            for _, group in df[df['false_precip_flag']].groupby('false_group'):
                hours = len(group) * 0.25   # 15 min = 0.25 hour
                if hours > max_false_hours:
                    max_false_hours = hours
                start = group[time_col].min().strftime('%Y-%m-%d %H:%M')
                end   = group[time_col].max().strftime('%Y-%m-%d %H:%M')
                if hours >= 0.5:
                    false_periods.append(f"{start} to {end} ({hours:.2f} hrs)")

        df['false_periods'] = " | ".join(false_periods) if false_periods else ""

        # ====================== CLEAN ONE-LINER LOGGING OF FALSE RECORDS ======================
        if n_false > 0:
            if false_periods:
                # 1. Format the string outside the f-string
                formatted_periods = '\n|'.join(false_periods)

                # 2. Pass the pre-formatted variable into the logger
                self.logger.info(f"Site {siteID}: False precip time periods: {formatted_periods}")

            self.logger.info(f"Site {siteID}: Longest continuous false precip period: {max_false_hours:.2f} hours")
            
        return df


    def detect_noisy_load_cell(self, df: pd.DataFrame,
                               siteID,
                               time_col: str = 'LocalReportDateTime',
                               bucket_col: str = 'ActDepth',
                               window_hours: int = 6,
                               min_flips: int = 12) -> pd.DataFrame:
        """Detect noisy load cell (SOP flag 'n') and report specific time periods."""
        if 'siteID' in df.columns:
            site_id = str(df['siteID'].iloc[0])
        else:
            site_id = "UNKNOWN"

        df = df.copy()
        df[time_col] = pd.to_datetime(df[time_col])
        df = df.sort_values(time_col).reset_index(drop=True)
        
        df['delta'] = df[bucket_col].diff()
        df['sign_change'] = (df['delta'].shift(1) * df['delta'] < 0) & (df['delta'] != 0)
        
        df = df.set_index(time_col)
        rolling_flips = df['sign_change'].rolling(
            window=pd.Timedelta(hours=window_hours),
            min_periods=1
        ).sum()
        df['noisy_flag'] = rolling_flips >= min_flips
        df = df.reset_index()

        n_noisy = df['noisy_flag'].sum()
        self.logger.info(f"Site {siteID}: Detected {n_noisy:,} records affected by noisy load cell (SOP flag 'n')")

        # ====================== ENHANCED: Continuous noisy periods ======================
        noisy_periods = []
        max_noisy_hours = 0.0

        if n_noisy > 0:
            df['noisy_group'] = (df['noisy_flag'].astype(int).diff().ne(0)).cumsum()
            for _, group in df[df['noisy_flag']].groupby('noisy_group'):
                hours = len(group) * 0.25   # 15 min = 0.25 hour
                if hours > max_noisy_hours:
                    max_noisy_hours = hours
                start = group[time_col].min().strftime('%Y-%m-%d %H:%M')
                end   = group[time_col].max().strftime('%Y-%m-%d %H:%M')
                if hours >= 0.5:
                    noisy_periods.append(f"{start} to {end} ({hours:.2f} hrs)")

        df['noisy_periods'] = " | ".join(noisy_periods) if noisy_periods else ""

        # ====================== CLEAN ONE-LINER LOGGING OF NOISY RECORDS ======================
        if n_noisy > 0:
            # self.logger.info(
            #     f"Site {siteID} - Noisy records ({n_noisy}):\n"
            #     f"{df[df['noisy_flag']][[time_col, bucket_col, 'delta']].round(4).to_string(index=True)}"
            # )
            if noisy_periods:
                formatted_noisy_periods = '\n|'.join(noisy_periods)
                self.logger.info(f"Site {siteID}: Noisy time periods: {formatted_noisy_periods}")
            self.logger.info(f"Site {siteID}: Longest continuous noisy period: {max_noisy_hours:.2f} hours")

        return df

    # ====================== HELPER METHOD ======================
    def _ensure_column(self, df: pd.DataFrame, col_name: str, default_value) -> pd.DataFrame:
        """Reuse column if it exists, otherwise create it with default value."""
        if col_name not in df.columns:
            df[col_name] = default_value
        else:
            df[col_name] = default_value  # update existing column
        return df

    def add_error_code_median(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Adds 'error_code_median' column based on % of records that deviate 
        from the median (using IQR outlier method) for key columns.
        
        Special rule: Uses the same bracket system (0-9) as other error functions.
        
        Final format (3-digit integer):
            • Char 1 (Hundreds): minVolt deviation from median
            • Char 2 (Tens):     ActTemp deviation from median
            • Char 3 (Units):    ActDepth deviation from median
        
        Higher digits = more records deviating significantly from the median 
        (i.e., higher instability / outliers in that sensor).
        """
        df = df.copy()
        
        # Helper function to calculate % of values deviating from median
        def get_deviation_pct(series: pd.Series, threshold: float = 1.5) -> float:
            """
            Returns percentage of values that are outliers based on IQR method.
            
            Parameters:
                series: pandas Series
                threshold: Multiplier for IQR (1.5 is standard, higher = more tolerant)
            """
            if series.dropna().empty:
                return 0.0
            
            # Drop NaNs for calculations
            clean = series.dropna()
            
            if len(clean) < 3:  # Too few values for meaningful IQR
                return 0.0
            
            Q1 = clean.quantile(0.25)
            Q3 = clean.quantile(0.75)
            IQR = Q3 - Q1
            
            lower_bound = Q1 - threshold * IQR
            upper_bound = Q3 + threshold * IQR
            
            # Count outliers
            outliers = (series < lower_bound) | (series > upper_bound)
            outlier_count = outliers.sum()
            
            total_rows = len(series)
            return (outlier_count / total_rows) * 100

        # ====================== 1. minVolt ======================
        pct_minvolt = get_deviation_pct(df['minVolt'])
        err_minvolt = self.get_bracket(pct_minvolt)
        
        # ====================== 2. ActTemp ======================  
        pct_temp = get_deviation_pct(df['ActTemp'])
        err_temp = self.get_bracket(pct_temp)
        

        
        # ====================== 3. ActDepthRA ======================
        pct_depth = get_deviation_pct(df['ActDepth'])
        err_depth = self.get_bracket(pct_depth)
        
        # ====================== Build final error_code_median ======================
        error_code_value = (
            err_minvolt * 100 +
            err_temp    * 10  +
            err_depth * 1    
 
        )
        
        df['error_code_median'] = pd.Series(error_code_value, index=df.index).astype(int)

        
        return df


    def add_error_code(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Adds 'error_code' column based on GLOBAL % of bad records per column.
        Special rule: If minVolt or ActTemp is constant (all values same), use 'F' for that digit.
        
        Final format (7 characters):
            • Char 1: minVolt (0-9 or F)
            • Char 2: ActTemp (0-9 or F)
            • Char 3: ActDepth (0-9)
            • Char 4: opdCounts Status ('A' = Active, 'F' = Failed/No activity)
            • Char 5-7: Percentage of records where opdCounts > 0 (padded 3 digits)
        """
        df = df.copy()
        total_rows = len(df)
        
        # ====================== 1. minVolt ======================
        if df['minVolt'].nunique() == 1:
            err_minvolt = 'F'
        else:
            bad_minvolt = (df['minVolt'] < 10) | (df['minVolt'] > 28)
            pct_minvolt = (bad_minvolt.sum() / total_rows) * 100
            err_minvolt = self.get_bracket(pct_minvolt)
        
        # ====================== 2. ActTemp ======================
        if df['ActTemp'].nunique() == 1:
            err_temp = 'F'
        else:
            bad_temp = (
                (df['ActTemp'] < -40) |
                (df['ActTemp'] > 60) |
                (df['ActTemp'] > 42) |
                (df['ActTemp'].diff().abs() > 20)
            )
            pct_temp = (bad_temp.sum() / total_rows) * 100
            err_temp = self.get_bracket(pct_temp)
        
        # ====================== 3. ActDepth ======================
        bad_depth = df['ActDepth'].isnull()
        pct_depth = (bad_depth.sum() / total_rows) * 100
        err_depth = self.get_bracket(pct_depth)
        
        # ====================== 4. opdCounts ANALYSIS ======================
        if 'opdCounts' in df.columns:
            opd = df['opdCounts']
            opd_positive_count = (opd > 0).sum()
            
            # Status: A = has activity, F = no activity
            opd_status = 'A' if opd_positive_count > 0 else 'F'
            
            # Percentage of records where opdCounts > 0 (0-100, padded to 3 digits)
            if total_rows > 0:
                opd_pct = (opd_positive_count / total_rows) * 100
                opd_count_str = f"{int(round(opd_pct)):03d}"
            else:
                opd_count_str = "000"
        else:
            opd_status = 'F'
            opd_count_str = "000"
        
        # ====================== Build final 7-character error_code ======================
        error_code_value = (
            str(err_minvolt) +
            str(err_temp) +
            str(err_depth) +
            opd_status +
            opd_count_str
        )
        
        df['error_code'] = pd.Series(error_code_value, index=df.index)
        
        return df

   


    def add_error_code_NTN(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Adds 'error_code_NTN' column (15-character code) for Collector 1 (NTN).
        """
        return self._add_error_code_collector(df, prefix="NTN", 
                                            volt_col='coll1Volt', 
                                            exp_col='exp1', 
                                            cycles_col='coll1cycles')


    def add_error_code_MDN(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Adds 'error_code_MDN' column (15-character code) for Collector 2 (MDN).
        """
        return self._add_error_code_collector(df, prefix="MDN", 
                                            volt_col='coll2Volt', 
                                            exp_col='exp2', 
                                            cycles_col='coll2cycles')


    def add_error_code_CO(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Adds 'error_code_CO' column (15-character code) for Collector 3 (CO).
        """
        return self._add_error_code_collector(df, prefix="CO", 
                                            volt_col='coll3Volt', 
                                            exp_col='exp3', 
                                            cycles_col='coll3cycles')


    # ====================== PRIVATE HELPER ======================
    def _add_error_code_collector(self, df: pd.DataFrame, 
                                prefix: str, 
                                volt_col: str, 
                                exp_col: str, 
                                cycles_col: str) -> pd.DataFrame:
        """
        Generic helper to create 15-character error code for any collector.
        """
        df = df.copy()
        total_rows = len(df)
        
        # ====================== 1. VOLTAGE ======================
        bad_voltage = pd.Series([False] * total_rows, index=df.index)
        if volt_col in df.columns:
            bad_voltage = (df[volt_col] == 0) | (df[volt_col] < 8)
        
        pct_bad_volt = (bad_voltage.sum() / total_rows) * 100
        volt_digit = self.get_bracket(pct_bad_volt)

        # ====================== 2. WET & DRY EXPOSURE ======================
        wet_status = 'F'
        wet_segments = 0
        wet_hours = 0.0
        
        dry_status = 'F'
        dry_segments = 0
        dry_hours = 0.0

        if all(col in df.columns for col in [exp_col, 'reportPrecip', 'ActDepth', cycles_col]):
            temp = df[[exp_col, 'reportPrecip', 'ActDepth', cycles_col]].fillna(0).copy()
            
            # ------------------- Dry Exposure -------------------
            temp['dry_candidate'] = (temp[exp_col] == 0) & (temp[cycles_col] == 0)
            temp['group'] = (temp['dry_candidate'] != temp['dry_candidate'].shift()).cumsum()
            
            dry_groups = temp[temp['dry_candidate']].groupby('group').agg(
                length=('exp1' if exp_col == 'exp1' else exp_col, 'size'),
                non_zero_pcp=('reportPrecip', lambda x: (x > 0).sum()),
                max_cont_pcp=('reportPrecip', lambda x: (x > 0).rolling(4, min_periods=1).sum().max()),
                depth_change=('ActDepth', lambda x: x.iloc[-1] - x.iloc[0] if len(x) > 1 else 0),
                coll_max=(cycles_col, 'max')
            )
            
            valid_dry = dry_groups[
                (dry_groups['length'] >= 8) &
                (dry_groups['non_zero_pcp'] <= dry_groups['length'] * 0.25) &
                (dry_groups['max_cont_pcp'] <= 3) &
                (dry_groups['depth_change'] < -0.01) &
                (dry_groups['coll_max'] >= 0)
            ]
            
            dry_segments = len(valid_dry)
            if dry_segments > 0:
                dry_status = 'A'
                dry_hours = valid_dry['length'].sum() * 0.25

            # ------------------- Wet Exposure -------------------
            temp['wet_candidate'] = (temp[exp_col] > 10) & (temp[cycles_col] > 0)
            temp['wet_group'] = (temp['wet_candidate'] != temp['wet_candidate'].shift()).cumsum()
            
            wet_groups = temp[temp['wet_candidate']].groupby('wet_group').agg(
                length=('exp1' if exp_col == 'exp1' else exp_col, 'size'),
                pcp_mean=('reportPrecip', 'mean')
            )
            
            valid_wet = wet_groups[
                (wet_groups['length'] >= 1) &
                (wet_groups['pcp_mean'] > 0.0001)
            ]
            
            wet_segments = len(valid_wet)
            if wet_segments > 0:
                wet_status = 'A'
                wet_hours = valid_wet['length'].sum() * 0.25

        # ====================== Build 15-Character error_code_XXX ======================
        wet_str = f"{wet_status}{wet_segments:03d}{int(round(wet_hours)):03d}"
        dry_str = f"{dry_status}{dry_segments:03d}{int(round(dry_hours)):03d}"
        
        df[f'error_code_{prefix}'] = f"{volt_digit}{wet_str}{dry_str}"
        
        return df


    def get_bracket(self, percentage: float) -> str:
        """Convert percentage of bad records into 0-4 bracket"""
        if percentage == 0:
            return 0
        elif percentage <= 10:
            return 1
        elif percentage <= 20:
            return 2
        elif percentage <= 30:
            return 3
        elif percentage <= 40:
            return 4
        elif percentage <= 50:
            return 5
        elif percentage <= 60:
            return 6
        elif percentage <= 70:
            return 7
        elif percentage <= 80:
            return 8
        elif percentage <= 90:
            return 9
        else:
            return 9
    def correct_precipitation(self, df: pd.DataFrame,
                            action: str = 'keep',
                            time_col: str = 'LocalReportDateTime',
                            precip_col: str = 'reportPCP',
                            alt_col: str = 'altPrecip',
                            alt2_col: str = 'altPrecip2',
                            final_col: str = 'corrected_PCP',
                            mask: pd.Series | None = None) -> pd.DataFrame:
        df = df.copy()
        df[time_col] = pd.to_datetime(df[time_col])
        df = df.sort_values(time_col).reset_index(drop=True)

        if mask is None:
            mask = pd.Series(True, index=df.index)
        else:
            mask = mask.reindex(df.index, fill_value=False)

        changed = mask.sum()
        working_precip = df[precip_col].copy()


        if action == 'zero':
            working_precip.loc[mask] = 0.0

        elif action == 'alt':
            if alt_col in df.columns:
                working_precip.loc[mask] = df.loc[mask, alt_col]
        elif action == 'alt2':
            if alt2_col in df.columns:
                working_precip.loc[mask] = df.loc[mask, alt2_col].fillna(0)
        elif action == 'none':
            working_precip.loc[mask] = np.nan

        df[final_col] = working_precip.fillna(0)

        self.logger.info(f" Applied '{action}' correction to {changed:,} records (SOP 4.2.11 / 4.3)")
        return df


    def print_correction_report(self, original_df: pd.DataFrame,
                                corrected_df: pd.DataFrame):
        if 'siteID' in original_df.columns:
            site_id = str(original_df['siteID'].iloc[0])
        else:
            site_id = "UNKNOWN"

        self.logger.info(f" NADP SOP 304 PRECIPITATION CORRECTION FINAL REPORT - {site_id}")

        total_records = len(corrected_df)
        orig_sum = original_df['reportPCP'].sum()
        final_sum = corrected_df['corrected_PCP'].sum()

        dry_hours = corrected_df.get('dry_exposure_hours', pd.Series([0.0])).iloc[0]
        undefined_flag = corrected_df.get('undefined_dry_flag', pd.Series([False])).iloc[0]
        undefined_periods = corrected_df.get('undefined_periods', pd.Series([""])).iloc[0]

        self.logger.info(f"(1) OVERVIEW")
        self.logger.info(f"   Total 15-minute records processed : {total_records:,}")
        self.logger.info(f"   Original Raw Precipitation        : {orig_sum:.3f} inches")
        self.logger.info(f"   Final Corrected Precipitation     : {final_sum:.3f} inches")
        self.logger.info(f"   Net change                        : {final_sum - orig_sum:+.3f} inches")
        self.logger.info(f"   Dry collector exposure (no precip): {dry_hours:.2f} hours")

        false_count = corrected_df.get('false_precip_flag', pd.Series([False]*len(corrected_df))).sum()
        noisy_count = corrected_df.get('noisy_flag', pd.Series([False]*len(corrected_df))).sum()
        self.logger.info(f" False Precip (flag 'f')        : {false_count:,} records")
        self.logger.info(f" Noisy Load Cell (flag 'n')     : {noisy_count:,} records")
        if undefined_flag:
            self.logger.info(" WARNING: UNDEFINED CONDITION DETECTED : >6 hours dry exposure -> entire file marked 'none'")
            if undefined_periods:
                self.logger.info(f" Time periods: {undefined_periods}")

        self.logger.info(f"(2) MACHINE SCREENING FLAGS DETECTED")
        self.logger.info(f"   False Precip (flag 'f')   : {false_count:,} records")
        self.logger.info(f"   Noisy Load Cell (flag 'n') : {noisy_count:,} records")

        self.logger.info(f"(3) CORRECTIONS APPLIED")
        zero_count = ((corrected_df['corrected_PCP'] == 0) & (original_df['reportPCP'] > 0)).sum()
        nan_count = corrected_df['corrected_PCP'].isna().sum()
        keep = ((corrected_df['corrected_PCP'] == original_df['reportPCP']) & (original_df['reportPCP'].notna())).sum()
        alt_count = 0
        if 'altPrecip' in corrected_df.columns and corrected_df['altPrecip'].notna().any():
            alt_count = ((corrected_df['reportPCP'] != corrected_df['altPrecip']) &
                         (corrected_df['reportPCP'] == original_df['reportPCP'])).sum()
        
        alt2_count = 0
        if 'altPrecip2' in corrected_df.columns and corrected_df['altPrecip2'].notna().any():
            alt2_count = ((corrected_df['reportPCP'] != corrected_df['altPrecip2']) &
                        (corrected_df['reportPCP'] == original_df['reportPCP'])).sum()
        

        self.logger.info(f"   * 'none'  -> marked missing/unusable : {nan_count:,} records")
        self.logger.info(f"   * 'zero'  -> set to zero precipitation : {zero_count:,} records")
        self.logger.info(f"   * 'altPrecip'  -> used altPrecip (OTT|ETI)     : {alt_count:,} records")
        self.logger.info(f"   * 'altPrecip2'  -> used altPrecip2 (ETI)    : {alt2_count:,} records")
        self.logger.info(f"   * keep    -> left as RawPrecip        : {keep:,} records")

        self.logger.info(f"(4) FINAL STATUS")
        self.logger.info(f"   Column 'corrected_PCP' contains the corrected values.")
        self.logger.info(f"   Columns 'reportPCP' and 'reportPrecip' are reference values only.")


    def run_autocorrect(self, df_in, siteID, labno, local_start, local_end, start_dt, end_dt,
                       expected_records, actual_records, valid_records, valid_records_reportPCP) -> pd.DataFrame:
        """
        New parameter: pct_record (float between 0 and 1) = percentage of actual records relative to expected records
        
        """

        pct_record = (actual_records / expected_records) if actual_records > 0 else 0.0
        pct_good = (valid_records / actual_records) if actual_records > 0 else 0.0
        pct_good_reportPCP = (valid_records_reportPCP / actual_records) if actual_records > 0 else 0.0
        start_dt_UTC = pd.to_datetime(df_in['LocalReportDateTime'].min(), utc=True)
        end_dt_UTC = pd.to_datetime(df_in['LocalReportDateTime'].max(), utc=True)
     
        self.logger.info("="*60)
        self.logger.info(f" Processing siteID: {siteID}, LABNO: {labno} | "
                        f"Expected: {expected_records} | Actual: {actual_records} | valid_records_reportPCP:{valid_records_reportPCP} |valid reportPrecip: {valid_records} ")
        self.logger.info(f" pct_record: {pct_record:.1%} | pct_good_reportPCP: {pct_good_reportPCP:.1%} |pct_good: {pct_good:.1%} ")
        self.logger.info(f"Start local: {local_start} | End local: {local_end}")
        self.logger.info(f"Start UTC: {start_dt} | End UTC: {end_dt}")
        self.logger.info(f"Start UTC match 15min from actual record from database: {start_dt_UTC} | End UTC match 15min from actual record in database: {end_dt_UTC}")
        if pct_record == 1.0:
            self.logger.info(" 100% of expected records present. Proceeding with autocorrection | equipment functionality.")
        if pct_record != 1.0:
            self.logger.info("The equipment may not be functioning correctly.")

        # === 1. Handle input type ===
        if isinstance(df_in, (str, os.PathLike)):
            self.logger.info(f" Loading data from file: {df_in}")
            df_original = pd.read_csv(df_in, parse_dates=['LocalReportDateTime'])
        elif isinstance(df_in, pd.DataFrame):
            self.logger.info(" Using provided DataFrame directly")
            df_original = df_in.copy()
        else:
            raise TypeError(f"df_in must be a file path or pandas DataFrame, got {type(df_in)}")

  
        if pct_record <= 0.85:
            self.logger.warning(f" WARNING {siteID}: pct_record ({pct_record:.1%}) <= 85% ; skipping correction.")
            cols = [
                "LocalReportDateTime", "siteID", "reportPCP", "reportPrecip", 
                "corrected_PCP", "coll1cycles", "exp1", "ActDepth", 
                "ActDepthRA", "altPrecip", "altPrecip2", "minVolt", 
                "ActTemp", "opdCounts", "CumReportPCP", "CumReportPrecip", 
                "Cumcoll1cycles", "Cumexp1", "delta_bucket", "false_precip_flag", 
                "delta", "sign_change", "noisy_flag", "total_exposure_cum", 
                "exp_increment_sec", "exp_increment_hours", "is_dry_open", 
                "dry_group", "dry_exposure_hours", "undefined_dry_flag", 
                "undefined_periods", "max_continuous_dry_hours"
            ]

            # Initialize the empty DataFrame
            df = pd.DataFrame(columns=cols)
            return df
        if pct_good <= 0.85:
            self.logger.warning(f" WARNING {siteID}: pct_good ({pct_good:.1%}) <= 90% ; skipping correction.")
            cols = [
                "LocalReportDateTime", "siteID", "reportPCP",  "reportPrecip", 
                "corrected_PCP", "coll1cycles", "exp1", "ActDepth", 
                "ActDepthRA", "altPrecip", "altPrecip2", "minVolt", 
                "ActTemp", "opdCounts", "CumReportPCP", "CumReportPrecip", 
                "Cumcoll1cycles", "Cumexp1", "delta_bucket", "false_precip_flag", 
                "delta", "sign_change", "noisy_flag", "total_exposure_cum", 
                "exp_increment_sec", "exp_increment_hours", "is_dry_open", 
                "dry_group", "dry_exposure_hours", "undefined_dry_flag", 
                "undefined_periods", "max_continuous_dry_hours"
            ]

            # Initialize the empty DataFrame
            df = pd.DataFrame(columns=cols)
            return df

        # Check consecutive nulls in reportPCP
        df_temp = df_original.copy()
        null_series = df_temp['reportPCP'].isna()
        max_consec_null = (null_series.astype(int)
                           .groupby((null_series != null_series.shift()).cumsum())
                           .sum().max())
       
        if max_consec_null > 4:
            self.logger.warning(f" WARNING {siteID}: Found {max_consec_null} consecutive nulls in reportPCP "
                              f"(max allowed = 4) ; skipping correction.")
            cols = [
                "LocalReportDateTime", "siteID", "reportPCP", "reportPrecip", 
                "corrected_PCP", "coll1cycles", "exp1", "ActDepth", 
                "ActDepthRA", "altPrecip", "altPrecip2", "minVolt", 
                "ActTemp", "opdCounts", "CumReportPCP", "CumReportPrecip", 
                "Cumcoll1cycles", "Cumexp1", "delta_bucket", "false_precip_flag", 
                "delta", "sign_change", "noisy_flag", "total_exposure_cum", 
                "exp_increment_sec", "exp_increment_hours", "is_dry_open", 
                "dry_group", "dry_exposure_hours", "undefined_dry_flag", 
                "undefined_periods", "max_continuous_dry_hours"
            ]

            # Initialize the empty DataFrame
            df = pd.DataFrame(columns=cols)
            return df

        self.logger.info(f" Passed {siteID}: pct_record = {pct_record:.1%}, max consecutive nulls = {max_consec_null} ; proceeding")

        df = df_original.copy()

        # === 4. Ensure reportPrecip exists (reference only) ===
        if 'reportPrecip' not in df.columns:
            df['reportPrecip'] = df['reportPCP'].fillna(0)
        else:
            df['reportPrecip'] = df_original['reportPrecip'].copy()

        # === 5. Fill missing timestamps if actual < expected ===
        # (your commented gap-filling code can stay here - not changed)

        # === 6. Check 15-minute interval consistency ===
        df = df.sort_values('LocalReportDateTime').reset_index(drop=True)
        time_diff = df['LocalReportDateTime'].diff().dt.total_seconds() / 60
        irregular_mask = (time_diff != 15) & time_diff.notna()
        irregular_count = irregular_mask.sum()
        if irregular_count > 0:
            irregular_indices = irregular_mask[irregular_mask].index
            irregular_df = pd.DataFrame({
                'row_index': irregular_indices,
                'prev_time': df.loc[irregular_indices-1, 'LocalReportDateTime'].values,
                'curr_time': df.loc[irregular_indices, 'LocalReportDateTime'].values,
                'diff_minutes': time_diff[irregular_indices].round(2),
                'diff_seconds': (time_diff[irregular_indices] * 60).round(1)
            })
            
            self.logger.warning(
                f"WARNING {siteID}: Found {irregular_count} irregular 15-min intervals"
            )
            self.logger.warning(f"\n{irregular_df.to_string(index=False)}")

        # === 7. Run detection for noise and false precip ===
        df = self.detect_false_precip(df, siteID)
        df = self.detect_noisy_load_cell(df, siteID)
         

    

        # === 8. Apply corrections with NOISE SEVERITY LOGIC ===
        false_count = df['false_precip_flag'].sum()
        noisy_count = df['noisy_flag'].sum()
        total_records = len(df)
        noisy_ratio = noisy_count / total_records if total_records > 0 else 0.0

        self.logger.info(f"Site {siteID}: Noisy ratio = {noisy_ratio:.1%} "
                         f"({noisy_count:,}/{total_records:,} records)")

        # Smart Alt column selection (AltPrecip2 preferred) # key case sensitivity check for altPrecip2 vs AltPrecip2
        use_alt2 = False

        for col_name in ['altPrecip2', 'AltPrecip2']:
            if col_name in df.columns:
                s = df[col_name]
                
                if s.notna().any() and (s != 0).any():
                    use_alt2 = True
                    break
                else:
                    self.logger.info(
                        f"Warning: {col_name} available but all zeros or NaN -> skipping targeted corrections"
                    )
                    use_alt2 = False
            break 

        if noisy_ratio >= 0.50:
            # SUPER NOISE (>= 50%)
            self.logger.info(f" WARNING {siteID}: SUPER NOISE DETECTED ({noisy_ratio:.2%}) -> marking entire file as 'none'")
            df = self.correct_precipitation(df, action='none')
        elif false_count > 0 or noisy_ratio > 0.20:
            # MILD NOISE or false precip present
            self.logger.info(f" Warning {siteID}: Mild noise / false precip detected -> targeted corrections")
            df = self.correct_precipitation(df, action='zero', mask=df['false_precip_flag'])
            if use_alt2:
                self.logger.info(f" ETI NOAH available -> using altPrecip2 for correction records")
                df = self.correct_precipitation(df, action='alt2', mask=df['noisy_flag'])
            elif 'altPrecip' in df.columns or 'AltPrecip' in df.columns:
                self.logger.info(f" Only altPrecip available -> using altPrecip for correction records")
                df = self.correct_precipitation(df, action='alt', mask=df['noisy_flag'])
        else:
            # CLEAN (<= 20%)
            self.logger.info(f" Passed {siteID}: Clean data ({noisy_ratio:.2%} noisy) -> using best Alt column")
            df = self.correct_precipitation(df, action='zero', mask=df['false_precip_flag'])
            if use_alt2:
                self.logger.info(f" ETI NOAH available -> using altPrecip2 for correction records")
                df = self.correct_precipitation(df, action='alt2')
            elif 'altPrecip' in df.columns or 'AltPrecip' in df.columns:
                self.logger.info(f" Only altPrecip available -> using altPrecip for correction records")
                df = self.correct_precipitation(df, action='alt')
            else:
                self.logger.info(f" No AltPrecip/AltPrecip2 found -> keeping raw data")


        df=self.add_error_code(df)
        df= self.add_error_code_median(df)
        df=self.add_error_code_NTN(df)
        df=self.add_error_code_MDN(df)
        df=self.add_error_code_CO(df)

        

        # === 9. Force exact column order ===
        desired_order = ['LocalReportDateTime', 'siteID', 'reportPCP',  'corrected_PCP','reportPrecip',]
        remaining_cols = [col for col in df.columns if col not in desired_order]
        df = df[desired_order + remaining_cols]

        # === 10. Final report ===
        self.print_correction_report(df_original, df)

        return df