
__author__ = 'Liam TrinhNguyen'
__email__ =  'LiamTrinhNguyen@gmail.com or TrinhNguyen@wisc.edu'
__version__ = 'preLim v0.1.5'


import re
from pathlib import Path
from dotenv import load_dotenv

# Absolute imports from your installed package
from data_prelim import (
    SQLConnection, 
    SQLConnectionSettings, 
    NTNInfo, 
    NTNInfoSettings,
    PipelineSettings,
    NTNReviewPipeline,
    Autocorrect_Settings,
    PrecipAutocorrect

)

def get_valid_sample_ids() -> tuple[str, str]:
    """Prompts for, sanitizes, and validates start and end sample IDs."""
    # Matches a single letter followed by exactly 7 digits
    pattern = re.compile(r"^[A-Z]\d{7}$") 
    
    while True:
        # .strip() removes hidden spaces, .upper() fixes lowercase typos (e.g., t2510007)
        start_id = input("Enter the starting sample ID (e.g., T2510007): ").strip().upper()
        end_id = input("Enter the ending sample ID (e.g., T2510808): ").strip().upper()

        if not start_id or not end_id:
            print("Error: Inputs cannot be empty. Please try again.\n")
            continue
            
        if not pattern.match(start_id) or not pattern.match(end_id):
            print("Error: Invalid format. IDs must be a letter followed by 7 digits (e.g., T2510007).\n")
            continue

        if start_id > end_id:
            print(f"Error: Start ID ({start_id}) cannot be greater than End ID ({end_id}).\n")
            continue
            
        return start_id, end_id

def main():
    """Main execution entry point for the NADP Prelim pipeline."""
    # 1. Load the environment at runtime
    load_dotenv() 

    # 2. Initialize Settings (automatically reads from .env)
    sql_settings = SQLConnectionSettings()  
    ntn_settings = NTNInfoSettings()        
    autocorrect_settings = Autocorrect_Settings()

    # 3. Instantiate and Inject Dependenciespython
    db_client = SQLConnection(settings=sql_settings)
    autocorrect = PrecipAutocorrect(autocorrect_settings)

    pipeline = NTNInfo(settings=ntn_settings, db_client=db_client, autocorrect=autocorrect)
    reportpipeline = NTNReviewPipeline(PipelineSettings())
 

    # 4. Capture and Validate Input
    sampleID_start, sampleID_end = get_valid_sample_ids()

    print(f"\nStarting pipeline run for samples: {sampleID_start} to {sampleID_end}")

    # 5. Execute Pipeline Phases
    pipeline.gap_overlap_sample_check(sampleID_start, sampleID_end)
    pipeline.review_stat_ntn1(sampleID_start, sampleID_end)
    pipeline.chem_stattus_check(sampleID_start, sampleID_end) # phase 1 - passed test
    pipeline.reloadTOTP_ntn1(sampleID_start, sampleID_end)    # phase 2 - passed test 
    data = pipeline.combine_and_review(sampleID_start, sampleID_end) # phase 3,4 - passed test
        
    # 6. Process and Export ---
    report = reportpipeline.load_and_optimize(data)
    reportpipeline.process_review(report, sampleID_start, sampleID_end)
    
    # 7. Sync (Manual Trigger) ---
    # After the lab tech saves the Excel file, uncomment the line below to update Parquet:
    # reportpipeline.sync_human_labels(reportpipeline._data_dir / "Review_Report.xlsx")
    
    print("Pipeline execution completed successfully.")

# Standard Python execution guard
if __name__ == "__main__":
    main()