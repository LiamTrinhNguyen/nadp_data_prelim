
__author__ = 'Liam TrinhNguyen'
__email__ =  'LiamTrinhNguyen@gmail.com or TrinhNguyen@wisc.edu'
__version__ = 'preLim v0.1.0'



import pyodbc , struct, os, sys, gc, psutil, logging, re
import numpy as np
import datetime as dt
from tqdm.auto import tqdm
import pandas as pd
from typing import Optional
from sqlalchemy import create_engine, engine



# set pandas options for full display
pd.set_option('display.max_columns', None)
pd.set_option('display.max_colwidth', None)
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

def handle_datetimeoffset(dto_value):
    ''' Convert a SQL Server datetimeoffset value to a Python datetime object. '''
    tup = struct.unpack("<6hI2h", dto_value)  # e.g., (2017, 3, 16, 10, 35, 18, 0, -6, 0)   
    tweaked = [tup[i] // 1000 if i == 6 else tup[i] for i in range(len(tup))] 
    return dt.datetime.fromisoformat("{:04d}-{:02d}-{:02d} {:02d}:{:02d}:{:02d}.{:06d} {:+03d}{:02d}".format(*tweaked)).astimezone(dt.timezone.utc).replace(tzinfo=None) 

    
def connect_to_db_engine():
    try:
        driver = 'ODBC Driver 17 for SQL Server'
        server = 'slhnadpdb'
        
        connection_string = f'DRIVER={{{driver}}};SERVER={server};Trusted_Connection=yes;'
        connection_url = engine.URL.create(
            "mssql+pyodbc",
            query={"odbc_connect": connection_string}
        )
        
        db_engine = create_engine(connection_url)
        return db_engine
    
    except Exception as e:
        print("Error creating engine: ", e)
        return None
    
def get_info_from_db(conn, query):
    try:
        cursor = conn.cursor()
        conn.add_output_converter(-155, handle_datetimeoffset)
        cursor.execute(query)
        rows = cursor.fetchall()
        return rows
    except Exception as e:
        print("Error executing query: ", e)
        return []
    
def ntn_db_byLabnoID(conn, start_labno='T2508221', end_labno='T2509230'):
    # all columns needed from NTN for next procedures

    c = [
        "REVCOMM",
        "SITE","LABNO","sampleStart", "sampleEnd","LABC","RECDATE",
        "sampVol",
        "ScreenStat",
        "totp", "SP",
        "sl","QR","notes",'TroubleFlag',
        ]

    NTN_QUERY = f"""
    select {','.join(c)}
    from ntn.dbo.NTN1
    where LABNO between '{start_labno}' and '{end_labno}'
        order by SampleEnd ASC;
    """
    df = pd.read_sql(NTN_QUERY, conn)

    end_labno_min = df['sampleEnd'].min()
    end_labno_max = df['sampleEnd'].max()
    

    df_ntn_db = df.copy()
    return df_ntn_db, end_labno_min, end_labno_max

def ntn_db_bydate(conn, siteID,day,addday):
    # all columns needed from NTN for next procedures

    c = ["SITE","LABNO","sampleStart", "sampleEnd","LABC"]

    NTN_QUERY = f"""
    declare @day Date = '{day}'
    select {','.join(c)}
    from ntn.dbo.NTN1
    where SampleEnd between DATEADD(day, -{addday}, @day) and DATEADD(day, {addday}, @day)
        and SITE = '{siteID}'
    order by SampleStart DESC
    """
    df = pd.read_sql(NTN_QUERY, conn)

    df = df.rename(columns={'SampleStart': 'sampleStart', 'SampleEnd': 'sampleEnd'})
    df_ntn_db = df.copy()
    return df_ntn_db


def pptuploadfiles_db(conn,rangestartDate, rangeendDate, siteID):
    c = ["SiteID","prevDate","startDate","endDate","reviewNotes",'precipUsable','processid']
    PPT_UPLOADFILES_QUERY = f"""
    select {','.join(c)}
    from nadpppt.dbo.pptuploadfiles
    where startDate between  '{rangestartDate}' and '{rangeendDate}'
    and siteID = '{siteID}'
    order by startDate ASC
    """

    df = pd.read_sql(PPT_UPLOADFILES_QUERY, conn)
    df['startDate']= pd.to_datetime(df['startDate'])
    df['endDate']= pd.to_datetime(df['endDate'])
    df_pptuploadfiles_db = df.copy()
    return df_pptuploadfiles_db



def egauge_db(conn, siteID, rangestartDate, rangeendDate):
    
    EGAUGE_QUERY = f"""
    DECLARE @StartLocal VARCHAR(30) = '{rangestartDate}';
    DECLARE @EndLocal VARCHAR(30) = '{rangeendDate}';

    -- 1. Extract the offset dynamically for the grouping
    DECLARE @Offset VARCHAR(10) = RIGHT(@StartLocal, 6); 

    SELECT 
        -- Convert UTC column to the input's local offset for the "Date Break"
        CAST(SWITCHOFFSET(CAST(datetime AS DATETIMEOFFSET), @Offset) AS DATE) AS LocalReportDate,
        siteID, 
        --SUM(reportPrecip) AS totalPrecipForRange
        reportPrecip
    FROM nadpPPT.dbo.pptJoint3
    WHERE siteID = '{siteID}'
    -- 2. Convert input strings to UTC for a high-performance index lookup
    AND datetime >= CAST(SWITCHOFFSET(CAST(@StartLocal AS DATETIMEOFFSET), '+00:00') AS DATETIME2)
    AND datetime <= CAST(SWITCHOFFSET(CAST(@EndLocal AS DATETIMEOFFSET), '+00:00') AS DATETIME2)
    """

    df = pd.read_sql(EGAUGE_QUERY, conn)
    df_egauge_db = df.copy()
    return df_egauge_db
def chem_db(conn, sampleID_start, sampleID_end):
    c = ['labno', 'SITE',
    'samplestart',
    'sampleend', 'screenstat',
    'labc', 'lph', 'lcond', 'so4', 'no3', 'cl', 'br', 'nh4', 'po4', 'ca', 'mg', 'na', 'k']
    CHEM_QUERY = f"""
    select {','.join(c)} 
    from ntn.dbo.ntn1
    where labno between '{sampleID_start}' and '{sampleID_end}' 
    order by labno asc
    """

    df = pd.read_sql(CHEM_QUERY, conn)
    df_chem_db = df.copy()
    return df_chem_db
def combine_unique(series):

    values = [str(v).strip() for v in series.dropna().unique() if str(v).strip() != '']
    return ', '.join(values) if values else 'M'


def pandasDataframe_to_csv ( pandasDataframe: pd.DataFrame, pathOfSaveFile: str ,nameFileSaveAs: str) -> Optional[pd.DataFrame]:
        """
        save the pandas dataframe to csv file 
        :param pandasDataframe (pandas.dataframe): input data need to process
        :param pathOfSaveFile (str): path of the output file
        :param nameFileSaveAs (str): name of file save to the given path

        :return instance_to_save (csv): success to save or str, error message for not success 

        """
        instance_to_save = pandasDataframe
        if not isinstance(instance_to_save, pd.DataFrame):
            print("Error: The input is not a pandas DataFrame, cannot process further.")
            sys.exit(1)
        if not os.path.isdir(pathOfSaveFile):
                    os.makedirs(pathOfSaveFile)
                    out_file_csv_path = os.path.join(pathOfSaveFile, nameFileSaveAs)
                    instance_to_save.to_csv(out_file_csv_path, index=False)
        else:
            out_file_csv_path = os.path.join(pathOfSaveFile, nameFileSaveAs)
            instance_to_save.to_csv(out_file_csv_path, index=False)

        return instance_to_save

def review_stat_ntn1(sampleID_start, sampleID_end):

    conn = connect_to_db_engine()
    if not conn:
        raise ConnectionError("Database connection failed.")

    df_ntn_db, end_labno_min, end_labno_max = ntn_db_byLabnoID(conn, sampleID_start, sampleID_end)
    
    validation_errors = []

    for siteID, df_eachSIte in tqdm(df_ntn_db.groupby('SITE'), desc=f'---- [PHASE 0]: checking screen status ({sampleID_start} to {sampleID_end})', ascii='-#'):
        if df_eachSIte['ScreenStat'].isnull().any():
            validation_errors.append(f"SiteID {siteID}: Missing ScreenStat values.")
        elif (df_eachSIte['ScreenStat'] == 'Entry').any():
            validation_errors.append(f"SiteID {siteID}: Failed due to 'Entry' status.")

    # If we found any bad data, stop the pipeline by raising ONE exception with all details.
    if validation_errors:
        error_report = "Validation failed. Please correct the following before proceeding:\n" + "\n".join(validation_errors)
        raise ValueError(error_report)

    print("Passed: All Screen Status (ScreenStat) available to review.")
    return df_ntn_db, end_labno_min, end_labno_max

def chem_stattus_check(sampleID_start, sampleID_end):
    conn= connect_to_db_engine()
    if not conn:
        raise ConnectionError("Database connection failed.")

    # Load the data
    df_chem_db = chem_db(conn, sampleID_start, sampleID_end)
    
    chem_cols = ['lph', 'lcond', 'so4', 'no3', 'cl', 'br', 'nh4', 'po4', 'ca', 'mg', 'na', 'k']
    
    # Vectorized check: Find rows where ANY of the chemistry columns are null
    mask = df_chem_db[chem_cols].isnull().any(axis=1)
    df_missing_data = df_chem_db[mask]

    # If the mask caught anything, we process the errors
    if not df_missing_data.empty:
        error_records = []
        
        # We only iterate over the rows that we ALREADY know have missing data
        for row in df_missing_data.itertuples():
            # Identify exactly which columns are missing for this specific row
            missing_cols = [col for col in chem_cols if pd.isna(getattr(row, col))]
            
            error_records.append({
                'LABNO': row.LABNO,
                'SiteID': row.SITE,
                'SampleStart': pd.to_datetime(row.sampleStart).tz_localize(None),
                'SampleEnd': pd.to_datetime(row.sampleEnd).tz_localize(None),
                'Missing_chem': ", ".join(missing_cols)
            })
            
        # Build the error DataFrame once at the end (fast)
        df_missing_chem = pd.DataFrame(error_records)
        
        # Log the dataframe so the user can see the tabular output
        print(f"\n{df_missing_chem.to_string()}\n")
        
        # Raise a single exception to stop the pipeline gracefully
        raise ValueError("Chemistry analysis for the given dataset is incomplete. Please correct the missing values listed above.")

    print("Passed: All chemistry status checks passed, ready for next review steps!")
    return df_chem_db
def reloadTOTP_ntn1(sampleID_start, sampleID_end):

    conn = connect_to_db_engine()
    if not conn:
        raise ConnectionError("Database connection failed.")

    df_ntn_db, end_labno_min, end_labno_max = ntn_db_byLabnoID(conn, sampleID_start, sampleID_end)

    # [PHASE 2]: Vectorized check for missing 'totp' values across the entire dataset instantly
    missing_totp_mask = df_ntn_db['totp'].isnull()
    all_reloadTOTP_ntn1 = df_ntn_db[missing_totp_mask]

    if not all_reloadTOTP_ntn1.empty:
        # Isolate the relevant columns for the error report
        error_report_df = all_reloadTOTP_ntn1[['SITE', 'LABNO', 'sampleStart', 'sampleEnd', 'totp']]
        
        # Print the tabular data for the user to inspect
        print(f"\n{error_report_df.to_string()}\n")
        
        # Raise an exception to halt the pipeline gracefully
        raise ValueError("Missing TOTP (Total Precipitation) values found. Please check and correct before proceeding.")

    print("Passed: All total precip (TOTP) available to review.")
    return df_ntn_db, end_labno_min, end_labno_max

def gap_overlap_sample_check(sampleID_start, sampleID_end):

    conn = connect_to_db_engine()
    if not conn:
        raise ConnectionError("Database connection failed.")

    df_ntn_db, end_min, end_max = ntn_db_byLabnoID(conn, sampleID_start, sampleID_end)
    df_ntn_db = df_ntn_db[df_ntn_db['LABC'] != 'DK'].copy()

    # 1. Vectorized Year Mode Checks
    df_ntn_db['sampleStart'] = pd.to_datetime(df_ntn_db['sampleStart'], utc=True)
    df_ntn_db['sampleEnd'] = pd.to_datetime(df_ntn_db['sampleEnd'], utc=True)
    
    top_year_start = df_ntn_db['sampleStart'].dt.year.mode()[0]
    top_year_end = df_ntn_db['sampleEnd'].dt.year.mode()[0]
    
    out_of_year_mask = (df_ntn_db['sampleStart'].dt.year != top_year_start) | (df_ntn_db['sampleEnd'].dt.year != top_year_end)
    if out_of_year_mask.any():
        print("WARNING: Records found outside the expected mode year.")
        print(df_ntn_db[out_of_year_mask][['SITE', 'LABNO', 'sampleStart', 'sampleEnd']])

    # 2. Fetch Extra Context Data efficiently
    # NOTE: Ideally, you should write a single SQL query to fetch ALL extra dates for ALL sites at once.
    # For now, we collect the data frames in a list and concat exactly ONE time.
    extra_dfs = [df_ntn_db] 
    sorted_sites = df_ntn_db['SITE'].unique()
    
    for siteID in tqdm(sorted_sites, desc='Fetching extra data for gap/overlap checks', ascii='-#'):
        site_data = df_ntn_db[df_ntn_db['SITE'] == siteID]
        day_before = site_data['sampleStart'].min()
        day_after = site_data['sampleEnd'].max()
        
        # Fetch 90 days right away to avoid double-querying logic
        df_extra_before = ntn_db_bydate(conn, siteID, day_before, 90)
        df_extra_after = ntn_db_bydate(conn, siteID, day_after, 90)
        
        extra_dfs.extend([df_extra_before, df_extra_after])

    # Build the master dataframe once
    df_master = pd.concat(extra_dfs, ignore_index=True)
    df_master = df_master[df_master['LABC'] != 'DK']
    df_master['sampleStart'] = pd.to_datetime(df_master['sampleStart'], utc=True)
    df_master['sampleEnd'] = pd.to_datetime(df_master['sampleEnd'], utc=True)
    df_master = df_master.drop_duplicates(subset=['LABNO']).sort_values(by=['SITE', 'sampleStart'])

    # 3. VECTORIZED GAP, OVERLAP, AND ERROR CALCULATIONS (No Loops!)
    
    # Compare current row's start with previous row's end for the SAME site
    df_master['prev_end'] = df_master.groupby('SITE')['sampleEnd'].shift(1)
    
    # Calculate time difference in minutes
    df_master['gap_before_mins'] = (df_master['sampleStart'] - df_master['prev_end']).dt.total_seconds() / 60

    # Apply Masks
    invalid_dates_mask = df_master['sampleStart'] > df_master['sampleEnd']
    duplicates_mask = df_master.duplicated(subset=['SITE', 'sampleStart', 'sampleEnd'], keep=False)
    late_mask = (~df_master['LABNO'].between(sampleID_start, sampleID_end)) & \
                (df_master['sampleStart'] >= df_ntn_db['sampleStart'].min()) & \
                (df_master['sampleEnd'] <= df_ntn_db['sampleEnd'].max())
    
    # Gap is > 60 mins. Overlap is < 0 mins.
    gap_mask = df_master['gap_before_mins'] > 60
    overlap_mask = df_master['gap_before_mins'] < 0

    # Isolate the original target LABNOs to avoid reporting on the "extra" 90-day padding data
    target_labnos = df_ntn_db['LABNO'].unique()
    
    # 4. Report Generation
    errors_found = False
    output_dir = r'\\SLHNADPFILE\nadpTeam\NADP_TDEP_Modeling_Project\NTN_DATA_DOC_AND_SCRIPT\NTN_review_2026\testing_ouput_NTN2026'

    if invalid_dates_mask.any():
        print("\nCRITICAL: Invalid samples found (Start Date > End Date)")
        print(df_master[invalid_dates_mask & df_master['LABNO'].isin(target_labnos)])
        errors_found = True

    if duplicates_mask.any():
        print("\nCRITICAL: Duplicated samples found!")
        print(df_master[duplicates_mask & df_master['LABNO'].isin(target_labnos)])
        errors_found = True

    if late_mask.any():
        print(f"\nLate samples found (Outside LABNO range {sampleID_start}-{sampleID_end} but inside date range)")
        print(df_master[late_mask])

    if gap_mask.any():
        gaps_df = df_master[gap_mask & df_master['LABNO'].isin(target_labnos)].copy()
        if not gaps_df.empty:
            print(f"\nGaps (> 1 hour) found. Exporting to all_gaps.csv")
            gaps_df['sampleEnd'] = gaps_df['sampleEnd'].dt.date
            pandasDataframe_to_csv(gaps_df, output_dir, 'all_gaps.csv')
            errors_found = True

    if overlap_mask.any():
        overlaps_df = df_master[overlap_mask & df_master['LABNO'].isin(target_labnos)].copy()
        if not overlaps_df.empty:
            print(f"\nOverlaps found. Exporting to all_overlaps.csv")
            pandasDataframe_to_csv(overlaps_df, output_dir, 'all_overlaps.csv')
            errors_found = True

    if errors_found:
        print("Date validation failed (Gaps, Overlaps, Duplicates, or Invalid dates detected). Check logs/csvs and correct before proceeding.")

    print("\nPassed: All sample dates, gaps, and overlaps checked successfully.")
    return df_ntn_db
def get_best_precip_match(sample_row, site_precip_df):
    """
    Finds precipitation data for a sample using expanding in-memory search windows.
    Returns the aggregated notes/data or an empty dictionary.
    """
    if site_precip_df is None or site_precip_df.empty:
        return {}

    target_start = pd.to_datetime(sample_row.sampleStart).normalize()
    target_end = pd.to_datetime(sample_row.sampleEnd).normalize()
    
    deltas = [0, 1, 7, 15, 30, 60, 90]

    for d in deltas:
        search_start = target_start - pd.Timedelta(days=d)
        search_end = target_end + pd.Timedelta(days=d)

        # Filter the in-memory dataframe for this search window
        mask = (site_precip_df['startDate'] >= search_start) & (site_precip_df['endDate'] <= search_end)
        match_df = site_precip_df[mask]

        if match_df.empty:
            continue

        res_min = match_df['startDate'].min().normalize()
        res_max = match_df['endDate'].max().normalize()

        # Check coverage
        is_covered = (res_min <= target_start) and (res_max >= target_end)
        
        if is_covered or (d == deltas[-1]):
            # We found our match (or hit the max fallback). Aggregate it now.
            return {
                'LABNO': sample_row.LABNO,
                'recordStart': res_min,
                'recordEnd': res_max,
                'processid': combine_unique(match_df['processid']),
                'reviewNotes': combine_unique(match_df['reviewNotes']),
                'precipUsable': combine_unique(match_df['precipUsable'])
            }

    # If even the 90-day delta found nothing that fits
    return {}
def reviewNotes_ppt_to_ntn1(sampleID_start, sampleID_end):

    conn = connect_to_db_engine()
    if not conn:
        raise ConnectionError("Database connection failed.")

    print("Database connection successful. Starting reviewNotes_ppt_to_ntn1 function...")
    
    df_ntn_db, end_labno_min, end_labno_max = ntn_db_byLabnoID(conn, sampleID_start, sampleID_end)
    
    if df_ntn_db.isnull().values.any():
        print(df_ntn_db[df_ntn_db.isnull().any(axis=1)])
        raise ValueError("NTN1 data contains missing values. Please check and correct before proceeding.")

    print(f"\n---NTN1 Data Summary Found---")
    print(f"Total samples: {len(df_ntn_db)}")
    print(f"Date range: {end_labno_min} to {end_labno_max}")
    print(f"Sites: {df_ntn_db['SITE'].nunique()} unique IDs\n")

    # Format dates in bulk
    df_ntn_db['sampleStart'] = pd.to_datetime(df_ntn_db['sampleStart'], utc=True).dt.tz_localize(None)
    df_ntn_db['sampleEnd'] = pd.to_datetime(df_ntn_db['sampleEnd'], utc=True).dt.tz_localize(None)

    # Clean the SITE column in bulk (e.g., "12WI" -> "WI12")
    # This replaces the row-by-row regex you were doing inside the loop
    df_ntn_db['fmt_SITE'] = df_ntn_db['SITE'].str.replace(r'^(\d{2})([a-zA-Z]{2})$', r'\2\1', regex=True)

    matched_records = []
    
    # Pre-fetch and process by site to minimize DB calls
    for siteID, df_site_samples in tqdm(df_ntn_db.groupby('SITE'), desc='---- [PHASE 3]: Matching reviewNotes ----'):
        
        fmt_site = df_site_samples['fmt_SITE'].iloc[0]
        if not re.match(r'^[a-zA-Z]{2}\d{2}$', fmt_site):
            continue # Skip invalid site formats

        # Find the absolute min and max dates for this site, padded by the max 90-day retry delta
        global_search_start = df_site_samples['sampleStart'].min() - pd.Timedelta(days=90)
        global_search_end = df_site_samples['sampleEnd'].max() + pd.Timedelta(days=90)

        # 1 DB CALL PER SITE, NOT 1 PER SAMPLE!
        df_site_precip = pptuploadfiles_db(conn, global_search_start, global_search_end, fmt_site)
        
        if df_site_precip is not None and not df_site_precip.empty:
            df_site_precip['startDate'] = pd.to_datetime(df_site_precip['startDate'])
            df_site_precip['endDate'] = pd.to_datetime(df_site_precip['endDate'])
        else:
            df_site_precip = pd.DataFrame()

        # Run the in-memory matching for each sample at this site
        for row in df_site_samples.itertuples():
            match = get_best_precip_match(row, df_site_precip)
            if match:
                matched_records.append(match)
            else:
                # Append an empty shell if absolutely no data was found, preserving the LABNO
                matched_records.append({
                    'LABNO': row.LABNO, 'recordStart': pd.NaT, 'recordEnd': pd.NaT,
                    'processid': '', 'reviewNotes': '', 'precipUsable': ''
                })

    # Combine matched records into a DataFrame
    df_matched = pd.DataFrame(matched_records)
    
    # Export intermediate check
    output_dir = r'\\SLHNADPFILE\nadpTeam\NADP_TDEP_Modeling_Project\NTN_DATA_DOC_AND_SCRIPT\NTN_review_2026\testing_ouput_NTN2026'
    pandasDataframe_to_csv(df_matched, output_dir, f'check_{sampleID_start}_{sampleID_end}.csv')

    # Merge back to original data
    all_df = pd.merge(df_ntn_db, df_matched, on='LABNO', how='left')
    all_df = all_df.sort_values(by=['SITE', 'sampleStart'])

    # Vectorized Math (Much faster than row-by-row)
    all_df['Start_End_diff'] = (all_df['sampleEnd'].dt.normalize() - all_df['sampleStart'].dt.normalize()).dt.days
    all_df['totp'] = all_df['totp'].round(3)
    all_df['sampleDepth'] = np.where(all_df['sampVol'] > 0, all_df['sampVol'] * .0005799, -9.999).round(3)

    # Final Column Selection
    final_cols = [
        "LABNO", "SITE", "sampleStart", "sampleEnd", "Start_End_diff", "LABC",
        "sampVol", "sampleDepth", "ScreenStat", "totp", "SP", "sl", "QR", "notes", 
        "TroubleFlag", "recordStart", "recordEnd", "reviewNotes", "precipUsable"
    ]
    all_df = all_df[final_cols]
    
    pandasDataframe_to_csv(all_df, output_dir, f'reviewNotes_ppt_to_ntn1_{sampleID_start}_{sampleID_end}.csv')  
    
    print("Phase 3 complete.")
    return all_df

def compare_ppt_report_ntn1(sampleID_start, sampleID_end):
    conn = connect_to_db_engine()
    if not conn:
        raise ConnectionError("Database connection failed.")

    print("Database connection successful. Starting Phase 4: Electronic gauge summary...")
    
    df_ntn_db, end_labno_min, end_labno_max = ntn_db_byLabnoID(conn, sampleID_start, sampleID_end)
   
    # Vectorized datetime calculations
    df_ntn_db['RECDATE'] = pd.to_datetime(df_ntn_db['RECDATE']).dt.floor('min')
    df_ntn_db['SampleEnd_RECDATE'] = (
        pd.to_datetime(df_ntn_db['RECDATE']).dt.normalize() - 
        pd.to_datetime(df_ntn_db['sampleEnd'], utc=True).dt.tz_convert(None).dt.normalize()
    ).dt.days

    # Halt gracefully on missing data
    if df_ntn_db.isnull().values.any():
        missing_data = df_ntn_db[df_ntn_db.isnull().any(axis=1)]
        print(missing_data)
        raise ValueError("NTN1 data contains missing values. Please check and correct before proceeding.")

    sorted_sites = sorted(df_ntn_db['SITE'].unique())

    # 1. USE A LIST FOR MASTER STORAGE (100x faster than pd.concat)
    egauge_records = [] 

    for siteID, df_eachSite in tqdm(df_ntn_db.groupby('SITE'), desc='---- [PHASE 4]: calculating e-gauge summary ', ascii='-#'):
        if siteID not in sorted_sites:
            continue
            
        for row in df_eachSite.itertuples():
            
            # --- ARCHITECTURE WARNING ---
            # If egauge_db queries the network, this inner loop is an N+1 Query bottleneck.
            # ----------------------------
            temp_df = egauge_db(
                conn, siteID, 
                row.sampleStart.isoformat(sep=' ', timespec='seconds'), 
                row.sampleEnd.isoformat(sep=' ', timespec='seconds')
            )
            
            # Logic to determine the precip value
            if temp_df is None or temp_df.empty:
                actual_records = 0
                valid_records = 0
                total_precip_egauge = None
            else:
                actual_records = len(temp_df)
                valid_records = temp_df['reportPrecip'].notna().sum()
                total_precip_egauge = f'{temp_df["reportPrecip"].sum():.3f}' if valid_records > 0 else None

            # Calculate Expected Records 
            start_dt = pd.to_datetime(row.sampleStart, utc=True)
            end_dt = pd.to_datetime(row.sampleEnd, utc=True)
            expected_records = int((end_dt.ceil('15min') - start_dt.floor('15min')).total_seconds() // 900) + 1

            # Calculate Percentages Safely
            raw_pct_record = (actual_records / expected_records) * 100 if expected_records > 0 else 0.0
            capped_pct_record = min(raw_pct_record, 100.0)
            pct_good = (valid_records / actual_records) * 100 if actual_records > 0 else 0.0

            # 2. APPEND A DICTIONARY TO THE LIST
            egauge_records.append({
                'LABNO': row.LABNO,
                'SampleEnd_RECDATE': row.SampleEnd_RECDATE,
                'SiteID': siteID,
                'SampleStart': start_dt.tz_localize(None),
                'SampleEnd': end_dt.tz_localize(None),
                'PPT': total_precip_egauge,
                'expect_ppt_record': expected_records,
                'actual_ppt_record': actual_records,
                'percent_record': f"{capped_pct_record:.1f}", 
                'percent_good_of_actual': f"{pct_good:.1f}%",
                'REVCOMM': row.REVCOMM,
            })

    # 3. CONVERT LIST TO DATAFRAME EXACTLY ONCE
    df_egauge_db = pd.DataFrame(egauge_records)

    # 4. MERGE AND CLEANUP
    df_egauge_db = df_egauge_db.sort_values(by=['SiteID', 'SampleStart', 'SampleEnd_RECDATE'])     
    df_egauge_db = pd.merge(df_egauge_db, df_ntn_db[['LABNO', 'RECDATE']], on='LABNO', how='left')
    
    # Export File
    output_dir = r'\\SLHNADPFILE\nadpTeam\NADP_TDEP_Modeling_Project\NTN_DATA_DOC_AND_SCRIPT\NTN_review_2026\testing_ouput_NTN2026'
    pandasDataframe_to_csv(df_egauge_db, output_dir, f'compare_ppt_report_ntn1_{sampleID_start}_{sampleID_end}.csv')  
    
    return df_egauge_db
def combine_and_review(sampleID_start, sampleID_end):
    conn = connect_to_db_engine()
    if conn:
        combined_df = reviewNotes_ppt_to_ntn1(sampleID_start, sampleID_end) # phase 3 - passed test
        df_egauge_db = compare_ppt_report_ntn1(sampleID_start, sampleID_end) # phase 4 - passed test
        df_egauge_db= df_egauge_db[['RECDATE','SampleEnd_RECDATE','LABNO','PPT',
                                    'percent_record','percent_good_of_actual', 'REVCOMM'
                                    ]]
        all_df = pd.merge(combined_df, df_egauge_db, on='LABNO', how='left')
        all_df['within_start_end'] = ( ((pd.to_datetime(all_df['recordStart'], utc=True).dt.tz_localize(None).dt.normalize()) >=  
                                      (pd.to_datetime(all_df['sampleStart'], utc=True).dt.tz_localize(None).dt.normalize())) &
                                    ((pd.to_datetime(all_df['recordEnd'], utc=True).dt.tz_localize(None).dt.normalize()) <= 
                                     (pd.to_datetime(all_df['sampleEnd'], utc=True).dt.tz_localize(None).dt.normalize())))
        all_df = all_df[['REVCOMM',
                         'LABNO','SITE','sampleStart','sampleEnd','Start_End_diff','RECDATE','SampleEnd_RECDATE',
                         'ScreenStat',
                         'LABC','sampVol','sampleDepth','totp','PPT',
                         'SP','sl','QR','notes','TroubleFlag',
                         'percent_record','percent_good_of_actual',
                         'within_start_end',
                         'recordStart','recordEnd','reviewNotes','precipUsable',	
                         
                        ]]
        pandasDataframe_to_csv(all_df, r'\\SLHNADPFILE\nadpTeam\NADP_TDEP_Modeling_Project\NTN_DATA_DOC_AND_SCRIPT\NTN_review_2026\testing_ouput_NTN2026', f'Pre_report_ntn1_{sampleID_start}_{sampleID_end}.csv')  

        return all_df

       

    else:
        print("Database connection failed.")
        return None

def report_to_review(sampleID_start, sampleID_end):
    all_df = combine_and_review(sampleID_start, sampleID_end)

    pandasDataframe_to_csv(all_df, r'\\SLHNADPFILE\nadpTeam\NADP_TDEP_Modeling_Project\NTN_DATA_DOC_AND_SCRIPT\NTN_review_2026\testing_ouput_NTN2026', f'Review_{sampleID_start}_{sampleID_end}.csv')  
    
  
            







def get_mem():
    return psutil.Process(os.getpid()).memory_info().rss / 1024**2
def run_(sampleID_start, sampleID_end):                
    logging.info(f"running run_ memory start :{get_mem():.1f} MB")
    gap_overlap_sample_check(sampleID_start, sampleID_end) # pre-phase  - passed test
    review_stat_ntn1(sampleID_start, sampleID_end) # phase 0 - passed test
    chem_stattus_check(sampleID_start, sampleID_end) # phase 1- passed test
    reloadTOTP_ntn1(sampleID_start, sampleID_end) # phase 2 - passed test 

    combine_and_review(sampleID_start, sampleID_end) #phase 3,4 passed test; 
    report_to_review(sampleID_start, sampleID_end) #phase5.. developing
    
    
    logging.info(f"running run_ memory end :{get_mem():.1f} MB")
    return "completed task"


def main():
    
    # sampleID_start = 'T2508221' #sample1.first
    # sampleID_end = 'T2509230'  #sample1.last
   

    # sampleID_start ='T2510007' #sample2.first
    # sampleID_end ='T2510808'  #sample2.last

    sampleID_start = input("Please input the sampleID_start (e.g., T2508221): ")
    sampleID_end = input("Please input the sampleID_end (e.g., T2509230): ")

    

    if sampleID_start <= sampleID_end:
        status = run_(sampleID_start, sampleID_end)
    else:
        print('ID sample start Must be equal or samller than ID sample end!!')
    print(f"sampleID_start, sampleID_end: {sampleID_start, sampleID_end}")
    
    gc.collect()
    logging.info(f"after run_ module, cleanup memory :{get_mem():.1f} MB")
    print("memory cleared. Ready for the next task!!")
if __name__ == "__main__":
    print(f'available memory: {psutil.virtual_memory().available /1024**2}')
    logging.info(f"Intial memory :{get_mem():.1f} MB")
    main()
    gc.collect()
    logging.info(f"Final memory :{get_mem():.1f} MB")