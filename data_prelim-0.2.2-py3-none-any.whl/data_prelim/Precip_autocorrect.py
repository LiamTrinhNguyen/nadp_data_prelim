__author__ = 'Liam TrinhNguyen'
__email__ = 'LiamTrinhNguyen@gmail.com or TrinhNguyen@wisc.edu'
__version__ = 'preLim v0.2.2'

import os, sys, psutil, logging, numpy as np, pandas as pd, itertools
from pathlib import Path
from logging.handlers import RotatingFileHandler
from datetime import datetime
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import FilePath, DirectoryPath

# set pandas options for full display
pd.set_option('display.max_columns', None)
pd.set_option('display.max_colwidth', None)


class Autocorrect_Settings(BaseSettings):
    output_dir: DirectoryPath     
    model_config = SettingsConfigDict(env_file=".env", env_prefix="WSLH_", extra="ignore")


class PrecipAutocorrect:
    def __init__(self, sampleID_start_log, sampleID_end_log,settings: Autocorrect_Settings):
        self.settings = settings
        self.output_root = self.settings.output_dir.resolve()
        
        self._log_dir = self.output_root / "logs"
        self._data_dir = self.output_root / "processed_data"
        self.sampleID_start_log = sampleID_start_log
        self.sampleID_end_log = sampleID_end_log
        
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = self._setup_logger()
        self.logger.info(f"Autocorrect Settings Initialized.")
    
    def _setup_logger(self) -> logging.Logger:

        logger_name = f"WSLH_NTN.{self.__class__.__name__}"
        logger = logging.getLogger(logger_name)

        # Avoid adding handlers multiple times
        if logger.hasHandlers():
            return logger

        logger.propagate = False
        logger.setLevel(logging.INFO)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_path = Path(self._log_dir) / f"pipeline_{self.sampleID_start_log}_{self.sampleID_end_log}_{timestamp}.log"

        formatter = logging.Formatter(
            '%(asctime)s - [%(name)s] - %(levelname)s: %(message)s'
        )

        # === SINGLE FILE, NO SIZE LIMIT ===
        fh = logging.FileHandler(log_path, mode='a', encoding='utf-8', delay=False)
        fh.setFormatter(formatter)
        logger.addHandler(fh)

        # Console output
        ch = logging.StreamHandler()
        ch.setFormatter(formatter)
        logger.addHandler(ch)


        return logger

    # ========================== CORE FUNCTIONS ==========================
    def detect_false_precip(self, df: pd.DataFrame,
                            siteID,
                            time_col: str = 'LocalReportDateTime',
                            bucket_col: str = 'ActDepth',
                            precip_col: str = 'reportPCP',
                            temp_col: str = 'ActTemp',
                            threshold: float = 0.007) -> pd.DataFrame: # False Precip flag ‘f’ (load cell drops ≥ 0.007 inches while reporting rain)
        if 'siteID' in df.columns:
            site_id = str(df['siteID'].iloc[0])
        else:
            site_id = "UNKNOWN"
        df = df.copy()
        df[time_col] = pd.to_datetime(df[time_col])
        df = df.sort_values(time_col).reset_index(drop=True)
        df['delta_bucket'] = df[bucket_col].diff()
        df['delta_temp'] = df[temp_col].diff()
        false_mask = (df['delta_bucket'] <= -threshold) & (df[precip_col] > 0)
        df['false_precip_flag'] = False
        df.loc[false_mask, 'false_precip_flag'] = True
        n_false = false_mask.sum()

        self.logger.info(f"Site {siteID}: Detected {n_false:,} false precip records (SOP flag 'f')")

        # === Log details of the false records ===
        false_periods = []
        max_false_hours = 0.0
        if n_false > 0:
            df['false_group'] = (df['false_precip_flag'].astype(int).diff().ne(0)).cumsum()
            for _, group in df[df['false_precip_flag']].groupby('false_group'):
                hours = len(group) * 0.25   # 15 min = 0.25 hour
                if hours > max_false_hours:
                    max_false_hours = hours
                start = group[time_col].min().strftime('%Y-%m-%d %H:%M')
                end   = group[time_col].max().strftime('%Y-%m-%d %H:%M')
                if hours >= 0.5:
                    false_periods.append(f"{start} to {end} ({hours:.2f} hrs)")

        df['false_periods'] = " | ".join(false_periods) if false_periods else ""

        # ====================== CLEAN ONE-LINER LOGGING OF FALSE RECORDS ======================
        if n_false > 0:
            if false_periods:
                self.logger.info(f"Site {siteID}: False precip time periods: {'\n|'.join(false_periods)}")
            self.logger.info(f"Site {siteID}: Longest continuous false precip period: {max_false_hours:.2f} hours")
            
        return df


    def detect_noisy_load_cell(self, df: pd.DataFrame,
                               siteID,
                               time_col: str = 'LocalReportDateTime',
                               bucket_col: str = 'ActDepth',
                               window_hours: int = 6,
                               min_flips: int = 12) -> pd.DataFrame:
        """Detect noisy load cell (SOP flag 'n') and report specific time periods."""
        if 'siteID' in df.columns:
            site_id = str(df['siteID'].iloc[0])
        else:
            site_id = "UNKNOWN"

        df = df.copy()
        df[time_col] = pd.to_datetime(df[time_col])
        df = df.sort_values(time_col).reset_index(drop=True)
        
        df['delta'] = df[bucket_col].diff()
        df['sign_change'] = (df['delta'].shift(1) * df['delta'] < 0) & (df['delta'] != 0)
        
        df = df.set_index(time_col)
        rolling_flips = df['sign_change'].rolling(
            window=pd.Timedelta(hours=window_hours),
            min_periods=1
        ).sum()
        df['noisy_flag'] = rolling_flips >= min_flips
        df = df.reset_index()

        n_noisy = df['noisy_flag'].sum()
        self.logger.info(f"Site {siteID}: Detected {n_noisy:,} records affected by noisy load cell (SOP flag 'n')")

        # ====================== ENHANCED: Continuous noisy periods ======================
        noisy_periods = []
        max_noisy_hours = 0.0

        if n_noisy > 0:
            df['noisy_group'] = (df['noisy_flag'].astype(int).diff().ne(0)).cumsum()
            for _, group in df[df['noisy_flag']].groupby('noisy_group'):
                hours = len(group) * 0.25   # 15 min = 0.25 hour
                if hours > max_noisy_hours:
                    max_noisy_hours = hours
                start = group[time_col].min().strftime('%Y-%m-%d %H:%M')
                end   = group[time_col].max().strftime('%Y-%m-%d %H:%M')
                if hours >= 0.5:
                    noisy_periods.append(f"{start} to {end} ({hours:.2f} hrs)")

        df['noisy_periods'] = " | ".join(noisy_periods) if noisy_periods else ""

        # ====================== CLEAN ONE-LINER LOGGING OF NOISY RECORDS ======================
        if n_noisy > 0:
            # self.logger.info(
            #     f"Site {siteID} - Noisy records ({n_noisy}):\n"
            #     f"{df[df['noisy_flag']][[time_col, bucket_col, 'delta']].round(4).to_string(index=True)}"
            # )
            if noisy_periods:
                self.logger.info(f"Site {siteID}: Noisy time periods: {'\n|'.join(noisy_periods)}")
            self.logger.info(f"Site {siteID}: Longest continuous noisy period: {max_noisy_hours:.2f} hours")

        return df
    def detect_precip_no_exposure(self, df: pd.DataFrame,
                                  siteID,
                                  time_col: str = 'LocalReportDateTime') -> pd.DataFrame:
        """
        Detect cases where precipitation is recorded (precip > 0) but exposure = 0.
        Creates flag columns: flagno_{exp_col}_{precip_col}
        Calculates and logs percentage for each combination.
        """
        if 'siteID' in df.columns:
            site_id = str(df['siteID'].iloc[0])
        else:
            site_id = "UNKNOWN"

        df = df.copy()
        df[time_col] = pd.to_datetime(df[time_col])
        df = df.sort_values(time_col).reset_index(drop=True)

        # Find all exposure columns
        exposure_cols = [col for col in df.columns
                        if col.lower() in ['exp1', 'exp2', 'exp3']
                        or col.lower().startswith('exp')
                        or 'exposure' in col.lower()]

        if not exposure_cols:
            self.logger.info(f" Site {site_id}: No collector exposure columns found. Skipping precip-no-exposure check.")
            return df

        self.logger.info(f" Site {siteID}: Using exposure columns: {exposure_cols}")

        # Find all precipitation sources (same candidates as detect_dry_exposure)
        candidates = {
            'corrected_PCP': ['corrected_PCP'],
            'reportPrecip':  ['reportPrecip'],
            'altPrecip2':    ['altPrecip2', 'AltPrecip2'],
            'altPrecip':     ['altPrecip',  'AltPrecip'],
            'reportPCP':     ['reportPCP']
        }

        precip_sources = {}
        for key, names in candidates.items():
            for name in names:
                if name in df.columns:
                    precip_sources[key] = name
                    break

        self.logger.info(f" Site {siteID}: Checking precip-no-exposure for: {list(precip_sources.keys())}")

        # Create flag for every pair (exp_col, precip_col)
        for exp_col in exposure_cols:
            for source_name, precip_col in precip_sources.items():
                if precip_col not in df.columns:
                    continue

                flag_col = f"flagno_{exp_col}_{precip_col}"

                # Flag: precip > 0 but exposure == 0
                df[flag_col] = (df[precip_col] > 0) & (df[exp_col] == 0)

                # Calculate percentage
                count = df[flag_col].sum()
                percent = (count / len(df) * 100) if len(df) > 0 else 0.0

                # Logging
                self.logger.warning(
                    f" precip occurrence but no exposure - Site {siteID}: {flag_col} -> {count:,} records ({percent:.2f}%) "
                )

        return df
    def detect_precip_no_exposure(self, df: pd.DataFrame,
                                    siteID,
                                    time_col: str = 'LocalReportDateTime') -> pd.DataFrame:
            """
            Detect cases where precipitation is recorded (precip > 0) but exposure = 0.
            Creates flag columns: flagno_{exp_col}_{precip_col}
            Calculates and logs percentage for each combination.
            """
            if 'siteID' in df.columns:
                site_id = str(df['siteID'].iloc[0])
            else:
                site_id = "UNKNOWN"

            df = df.copy()
            df[time_col] = pd.to_datetime(df[time_col])
            df = df.sort_values(time_col).reset_index(drop=True)

            # Find all exposure columns
            exposure_cols = [col for col in df.columns
                            if col.lower() in ['exp1', 'exp2', 'exp3']
                            or col.lower().startswith('exp')
                            or 'exposure' in col.lower()]

            if not exposure_cols:
                self.logger.info(f" Site {site_id}: No collector exposure columns found. Skipping precip-no-exposure check.")
                return df

            self.logger.info(f" Site {siteID}: Using exposure columns: {exposure_cols}")

            # Find all precipitation sources (same candidates as detect_dry_exposure)
            candidates = {
                'corrected_PCP': ['corrected_PCP'],
                'reportPrecip':  ['reportPrecip'],
                'altPrecip2':    ['altPrecip2', 'AltPrecip2'],
                'altPrecip':     ['altPrecip',  'AltPrecip'],
                'reportPCP':     ['reportPCP']
            }

            precip_sources = {}
            for key, names in candidates.items():
                for name in names:
                    if name in df.columns:
                        precip_sources[key] = name
                        break

            self.logger.info(f" Site {siteID}: Checking precip-no-exposure for: {list(precip_sources.keys())}")

            # Create flag for every pair (exp_col, precip_col)
            for exp_col in exposure_cols:
                for source_name, precip_col in precip_sources.items():
                    if precip_col not in df.columns:
                        continue

                    flag_col = f"flagno_{exp_col}_{precip_col}"

                    # Flag: precip > 0 but exposure == 0
                    df[flag_col] = (df[precip_col] > 0) & (df[exp_col] == 0)

                    # Calculate percentage
                    count = df[flag_col].sum()
                    percent = (count / len(df) * 100) if len(df) > 0 else 0.0

                    # Logging
                    self.logger.warning(
                        f" precip occurrence but no exposure - Site {siteID}: {flag_col} -> {count:,} records ({percent:.2f}%) "
                    )

            return df

    def detect_collector_abnormal(self, df: pd.DataFrame,
                              siteID,
                              time_col: str = 'LocalReportDateTime') -> pd.DataFrame:
        """
        Comprehensive collector abnormality and data quality detection.
        Includes basic data validation + behavioral abnormalities.
        """
        if 'siteID' in df.columns:
            site_id = str(df['siteID'].iloc[0])
        else:
            site_id = "UNKNOWN"
            
        df = df.copy()
        df[time_col] = pd.to_datetime(df[time_col])
        df = df.sort_values(time_col).reset_index(drop=True)

        total_records = len(df)
        total_flag_instances = 0

        self.logger.info(f" Site {siteID}: Running comprehensive collector abnormality & data quality check")

        for i in range(1, 4):
            exp_col = f'exp{i}'
            cycle_col = f'coll{i}cycles'
            volt_col = f'coll{i}Volt' if f'coll{i}Volt' in df.columns else 'coll1Volt'
            precip_col = 'reportPrecip' if 'reportPrecip' in df.columns else 'reportPCP'
            
            if exp_col not in df.columns or cycle_col not in df.columns:
                continue

            # Safe numeric conversion
            exp = pd.to_numeric(df[exp_col], errors='coerce')
            cycle = pd.to_numeric(df[cycle_col], errors='coerce')
            precip = pd.to_numeric(df.get(precip_col, pd.Series([0.0]*len(df))), errors='coerce').round(4)
            act_temp = pd.to_numeric(df.get('ActTemp', pd.Series([0.0]*len(df))), errors='coerce').round(4)
            act_depth = pd.to_numeric(df.get('ActDepth', pd.Series([0.0]*len(df))), errors='coerce').round(4)
            scantime = pd.to_numeric(df.get('scantime', pd.Series([0.0]*len(df))), errors='coerce')
            coll_volt = pd.to_numeric(df.get(volt_col, pd.Series([0.0]*len(df))), errors='coerce').round(4)

            cycle_diff = cycle.diff().fillna(0)

            is_open = exp > 0.5
            was_open = exp.shift(1) > 0.5
            has_precip = precip >= 0.01

            # ==================== DATA QUALITY RED FLAGS (Stage 1) ====================

            # 1a. Negative values
            df[f'red_flag_negative_{exp_col}'] = exp < 0
            df[f'red_flag_negative_{cycle_col}'] = cycle < 0
            df[f'red_flag_negative_reportPCP'] = precip < 0
            df[f'red_flag_negative_ActDepth'] = act_depth < 0
            df[f'red_flag_negative_scantime'] = scantime < 0
            df[f'red_flag_negative_{volt_col}'] = coll_volt < 0
         

            # 1b. Known bad specific values
            df['red_flag_bad_ActTemp'] = act_temp == 256
            df['red_flag_bad_precip'] = precip == 50.11
            df['red_flag_bad_cycle'] = cycle == 78400

            # 1c. scantime must be 900
            # df['red_flag_scantime_not_900'] = scantime != 900

            # 1d. exp > 900
            df[f'red_flag_exp_too_high_{exp_col}'] = exp > 900

            # 1e. collVolt should be between 11-15 and not constant across all records
            # df[f'red_flag_volt_out_of_range_{volt_col}'] = (coll_volt < 11) | (coll_volt > 15)
            df[f'red_flag_volt_constant_{volt_col}'] = (coll_volt.nunique(dropna=True) == 1)

            # 1f.cycle > 50
            df[f'red_flag_cycle_too_high_{cycle_col}'] = cycle > 50

            # 1g. act_depth is constant across all records (indicating possible sensor failure)
            df['red_flag_act_depth_constant'] = (act_depth.nunique(dropna=True) == 1)

            # ==================== BEHAVIORAL ABNORMAL FLAGS ====================

            # df[f'flag_failed_open_{exp_col}_{cycle_col}'] = (
            #     (cycle_diff > 0) & (~is_open.fillna(False)) & has_precip
            # )
            # df[f'flag_phantom_cycle_{exp_col}_{cycle_col}'] = (
            #     (cycle_diff > 0) & (~is_open.fillna(False)) & (~has_precip)
            # )
            # df[f'flag_no_cycle_on_open_{exp_col}'] = (
            #     (exp.shift(1) <= 0.5) & is_open & (cycle_diff == 0) & has_precip
            # )

            # # Stayed open 6+ hours with low precip
            # df[f'flag_stayed_open_long_{exp_col}'] = (
            #     is_open & was_open & 
            #     (exp.shift(23) > 0.5) & 
            #     (precip.rolling(24, min_periods=20).max() < 0.2)
            # )

            # df[f'flag_negative_cycle_{cycle_col}'] = (cycle < 0)
            # df[f'flag_chattering_{exp_col}'] = (
            #     is_open & (cycle_diff > 0) & was_open & (exp != exp.shift(1))
            # )
            # df[f'flag_orphan_open_{exp_col}'] = (
            #     is_open & 
            #     (cycle == cycle.iloc[0]) & 
            #     (cycle == cycle.shift(1)) & 
            #     (cycle == cycle.shift(2)) & 
            #     (precip < 0.05) &
            #     ((precip.shift(1) > 0.05) | (precip.shift(2) > 0.05)) &
            #     ((precip.shift(-1) > 0.05) | (precip.shift(-2) > 0.05))
            # )

            # ==================== COUNT & LOG ALL FLAGS ====================
            flag_list = [col for col in df.columns if col.startswith(('flag_', 'red_flag_'))]

            for flag_col in flag_list:
                if flag_col in df.columns:
                    count = int(df[flag_col].sum())
                    if count > 0:
                        percent = (count / total_records * 100)
                        total_flag_instances += count
                        self.logger.warning(
                            f" Site {siteID}: {flag_col} -> {count:,} records ({percent:.2f}%)"
                        )

        # ====================== OVERALL SUMMARY ======================
        all_flag_cols = [col for col in df.columns if col.startswith(('flag_', 'red_flag_'))]
        
        if all_flag_cols:
            df['flag_any_abnormal'] = df[all_flag_cols].any(axis=1)
            affected_rows = int(df['flag_any_abnormal'].sum())
            affected_percent = (affected_rows / total_records * 100) if total_records > 0 else 0.0

            self.logger.warning(f"")
            self.logger.warning(f" === FINAL COLLECTOR ABNORMAL SUMMARY for {siteID} ===")
            self.logger.warning(f" Total records checked                     : {total_records:,}")
            self.logger.warning(f" Rows with at least ONE issue              : {affected_rows:,} ({affected_percent:.2f}%)")
            self.logger.warning(f" Total flag instances                      : {total_flag_instances:,}")
            self.logger.warning(f" =======================================================")

        return df
    def detect_dry_exposure(self, df: pd.DataFrame,
                        siteID,
                        time_col: str = 'LocalReportDateTime') -> pd.DataFrame:
        """
        SOP Undefined Rule: collector open for >6 hours total dry exposure.
        - Converts each exp column from seconds to hours
        - Calculates dry exposure for each exposure column against each precip source
        - Now includes ±2 row buffer around any precipitation to avoid edge-case contamination
        """
        if 'siteID' in df.columns:
            site_id = str(df['siteID'].iloc[0])
        else:
            site_id = "UNKNOWN"

        df = df.copy()
        df[time_col] = pd.to_datetime(df[time_col])
        df = df.sort_values(time_col).reset_index(drop=True)

        # Reset default columns
        df['dry_exposure_hours'] = 0.0
        df['undefined_dry_flag'] = False
        df['undefined_periods'] = ""
        df['max_continuous_dry_hours'] = 0.0

        # ==================== EXPOSURE COLUMNS ====================
        exposure_cols = [col for col in df.columns if col.lower() in ['exp1', 'exp2', 'exp3']]

        if not exposure_cols:
            self.logger.info(f" Site {site_id}: No collector exposure columns found.")
            return df

        self.logger.info(f" Site {siteID}: Using exposure columns: {exposure_cols}")

        # ==================== CONVERT SECONDS TO HOURS ====================
        exp_hour_cols = {}
        for exp_col in exposure_cols:
            hour_col = f"{exp_col}_hours"
            
            # ROBUST CONVERSION - This fixes the string/float issue
            df[hour_col] = pd.to_numeric(df[exp_col], errors='coerce').fillna(0) / 3600.0
            df[hour_col] = df[hour_col].astype('float64')   # Ensure it's numeric

            exp_hour_cols[exp_col] = hour_col
            
            self.logger.info(f" Site {siteID}: Created {hour_col} (converted from seconds)")
            
     

        # ==================== PRECIPITATION SOURCES ====================
        precip_targets = ['corrected_PCP', 'reportPrecip', 'reportPCP']
        precip_sources = {pcol: pcol for pcol in precip_targets if pcol in df.columns}

        if not precip_sources:
            self.logger.warning(f" Site {siteID}: No target precip columns found. Skipping.")
            return df

        self.logger.info(f" Site {siteID}: Computing dry exposure for: {list(precip_sources.keys())}")

        # ==================== UPDATED HELPER FUNCTION ====================
        def _compute_dry_for_source(precip_col: str, exp_hour_col: str, prefix: str):
            """Compute dry periods with a 6-hour buffer around any precipitation."""
            
            # Step 1: Create cleaned exposure column
            cleaned_exp_col = f'cleaned_exp_{prefix}_{precip_col.lower()}'
            df[cleaned_exp_col] = df[exp_hour_col].copy()
            
            precip_mask = df[precip_col] > 0
            
            # Force to zero where there is precipitation
            df.loc[precip_mask, cleaned_exp_col] = 0
            
            # === selective -HOUR BUFFER (±24 rows) ===
            buffer_mask = precip_mask.copy()
            buffer_hours = 1
            buffer_rows = int(buffer_hours * 60 / 15)   # 4 rows for 15-min data
            
            for i in range(1, buffer_rows + 1):
                buffer_mask |= precip_mask.shift(i, fill_value=False)
                buffer_mask |= precip_mask.shift(-i, fill_value=False)
            
            # Apply buffer: set exposure to 0 in buffer zones
            df.loc[buffer_mask, cleaned_exp_col] = 0
            
            # Step 2: Identify dry periods
            is_dry_open = df[cleaned_exp_col] > 0
            
            # Create group labels for continuous dry periods
            dry_group = (is_dry_open.astype(int).diff().ne(0)).cumsum()
            group_col = f'dry_group_{prefix}_{precip_col.lower()}'
            df[group_col] = dry_group.where(is_dry_open, np.nan)
            
            # Step 3: Total dry hours
            total_dry = df[cleaned_exp_col].sum()
            
            # Step 4: Max continuous dry period + list all dry periods
            max_dry_hours = 0.0
            dry_periods = []
            
            for _, group in df[is_dry_open].groupby(dry_group):
                hours = group[cleaned_exp_col].sum()
                if hours > max_dry_hours:
                    max_dry_hours = hours
                    
                start = group[time_col].min().strftime('%Y-%m-%d %H:%M')
                end = group[time_col].max().strftime('%Y-%m-%d %H:%M')
                dry_periods.append(f"{start} to {end} ({hours:.2f} hrs)")

            undefined_flag = total_dry > 6.0
            undefined_periods = " \n| ".join(dry_periods) if dry_periods else ""

            self.logger.info(f"dry_periods: {dry_periods}")

            return {
                'total_dry': total_dry,
                'max_dry_hours': max_dry_hours,
                'undefined_flag': undefined_flag,
                'undefined_periods': undefined_periods,
                'cleaned_exp_col': cleaned_exp_col,
                'group_col': group_col
            }
        # ==================== COMPUTE FOR ALL COMBINATIONS ====================
        for exp_col, hour_col in exp_hour_cols.items():
            for source_name, precip_col in precip_sources.items():
                if precip_col not in df.columns:
                    continue

                clean_exp = exp_col.lower().replace(' ', '').replace('_', '')
                prefix = f"{clean_exp}_{source_name.lower().replace('_', '')}"

                result = _compute_dry_for_source(precip_col, hour_col, prefix)

                # Store results
                df[f'dry_exposure_hours_{prefix}'] = result['total_dry']
                df[f'undefined_dry_flag_{prefix}'] = result['undefined_flag']
                df[f'undefined_periods_{prefix}'] = result['undefined_periods']
                df[f'max_continuous_dry_hours_{prefix}'] = result['max_dry_hours']

                self.logger.info(f" Site {siteID}: Total dry ({exp_col} vs {source_name}): {result['total_dry']:.2f} hrs")
                self.logger.info(f" Site {siteID}: Longest continuous dry: {result['max_dry_hours']:.2f} hrs")
                if result['undefined_flag']:
                    self.logger.warning(f" Site {siteID}: UNDEFINED CONDITION DETECTED -> {exp_col} vs {source_name} (>6 hrs dry)")

        # Backward compatibility - populate main columns from preferred source
        for prefix in ['corrected_pcp', 'reportprecip', 'reportpcp']:
            if f'dry_exposure_hours_exp1_{prefix}' in df.columns:   # Most common pattern
                df['dry_exposure_hours']       = df[f'dry_exposure_hours_exp1_{prefix}']
                df['undefined_dry_flag']       = df[f'undefined_dry_flag_exp1_{prefix}']
                df['undefined_periods']        = df[f'undefined_periods_exp1_{prefix}']
                df['max_continuous_dry_hours'] = df[f'max_continuous_dry_hours_exp1_{prefix}']
                break
            elif f'dry_exposure_hours_{prefix}' in df.columns:
                df['dry_exposure_hours']       = df[f'dry_exposure_hours_{prefix}']
                df['undefined_dry_flag']       = df[f'undefined_dry_flag_{prefix}']
                df['undefined_periods']        = df[f'undefined_periods_{prefix}']
                df['max_continuous_dry_hours'] = df[f'max_continuous_dry_hours_{prefix}']
                break

        return df
    
    def detect_full_open_exposure(self, df: pd.DataFrame,
                              siteID,
                              time_col: str = 'LocalReportDateTime') -> pd.DataFrame:
        """
        Check if the collector/sampler was open for the ENTIRE period.
        - Converts each exposure column from seconds to hours individually
        - Creates per-exposure full_open_flag + overall full_open_flag
        """
        if 'siteID' in df.columns:
            site_id = str(df['siteID'].iloc[0])
        else:
            site_id = "UNKNOWN"

        df = df.copy()
        df[time_col] = pd.to_datetime(df[time_col])
        df = df.sort_values(time_col).reset_index(drop=True)

        # ====================== Find exposure columns ======================
        exposure_cols = [col for col in df.columns
                        if col.lower() in ['exp1', 'exp2', 'exp3']
                        or col.lower().startswith('exp')
                        or 'exposure' in col.lower()]

        if not exposure_cols:
            self.logger.info(f" Site {site_id}: No collector exposure columns found.")
            df = self._ensure_column(df, 'full_open_flag', False)
            df = self._ensure_column(df, 'full_open_hours', 0.0)
            df = self._ensure_column(df, 'total_exposure_hours', 0.0)
            df = self._ensure_column(df, 'exposure_coverage_pct', 0.0)
            return df

        self.logger.info(f" Site {siteID}: Using exposure columns: {exposure_cols}")

        # ====================== Convert each exp column: seconds to hours ======================
        exp_hour_cols = {}
        for exp_col in exposure_cols:
            hour_col = f"{exp_col}_hours"
            df[hour_col] = df[exp_col].fillna(0) / 3600.0
            exp_hour_cols[exp_col] = hour_col
            self.logger.info(f" Site {siteID}: Created {hour_col} from {exp_col}")

        # ====================== Total Exposure (Overall) ======================
        total_exposure_hours = 0.0
        for hour_col in exp_hour_cols.values():
            total_exposure_hours += df[hour_col].sum()

        total_exposure_hours = float(total_exposure_hours)
        total_possible_hours = len(df) * 0.25

        exposure_pct = (total_exposure_hours / total_possible_hours * 100) if total_possible_hours > 0 else 0.0
        full_open_flag = exposure_pct >= 99.0

        # Store overall results
        df = self._ensure_column(df, 'full_open_flag', full_open_flag)
        df = self._ensure_column(df, 'full_open_hours', total_exposure_hours)
        df = self._ensure_column(df, 'total_exposure_hours', total_exposure_hours)
        df = self._ensure_column(df, 'exposure_coverage_pct', exposure_pct)

        # ====================== Per-Exposure Column Analysis ======================
        for exp_col, hour_col in exp_hour_cols.items():
            col_hours = float(df[hour_col].sum())
            col_pct = (col_hours / total_possible_hours * 100) if total_possible_hours > 0 else 0.0
            
            # Per-column full open flag
            col_full_open_flag = col_pct >= 99.0

            # Store per-column results
            clean_name = exp_col.lower().replace(' ', '_').replace('.', '')
            df[f'full_open_flag_{clean_name}'] = col_full_open_flag
            df[f'{exp_col}_total_hours'] = col_hours
            df[f'{exp_col}_coverage_pct'] = col_pct

            # Logging per column
            status = "FULL OPEN" if col_full_open_flag else "NOT FULL OPEN"
            self.logger.info(f" Site {siteID}: {exp_col} -> {col_hours:.2f} hours ({col_pct:.2f}%) -> {status}")

        # ====================== Overall Logging ======================
        # self.logger.info(f" Site {siteID}: Total exposure hours: {total_exposure_hours:.2f} / "
        #                 f"{total_possible_hours:.2f} hours ({exposure_pct:.2f}%)")

        if full_open_flag:
            self.logger.info(f" Site {siteID}: COLLECTOR WAS OPEN FOR THE ENTIRE PERIOD "
                            f"(Overall Full Open Detected - {exposure_pct:.2f}%)")
        else:
            self.logger.info(f" Site {siteID}: Collector was NOT open the entire period "
                            f"({exposure_pct:.2f}% coverage)")

        return df
    # ====================== HELPER METHOD ======================
    def _ensure_column(self, df: pd.DataFrame, col_name: str, default_value) -> pd.DataFrame:
        """Reuse column if it exists, otherwise create it with default value."""
        if col_name not in df.columns:
            df[col_name] = default_value
        else:
            df[col_name] = default_value  # update existing column
        return df

    def correct_precipitation(self, df: pd.DataFrame,
                            action: str = 'keep',
                            time_col: str = 'LocalReportDateTime',
                            precip_col: str = 'reportPCP',
                            alt_col: str = 'altPrecip',
                            alt2_col: str = 'altPrecip2',
                            final_col: str = 'corrected_PCP',
                            mask: pd.Series | None = None) -> pd.DataFrame:
        df = df.copy()
        df[time_col] = pd.to_datetime(df[time_col])
        df = df.sort_values(time_col).reset_index(drop=True)

        if mask is None:
            mask = pd.Series(True, index=df.index)
        else:
            mask = mask.reindex(df.index, fill_value=False)

        changed = mask.sum()
        working_precip = df[precip_col].copy()


        if action == 'zero':
            working_precip.loc[mask] = 0.0

        elif action == 'alt':
            if alt_col in df.columns:
                working_precip.loc[mask] = df.loc[mask, alt_col]
        elif action == 'alt2':
            if alt2_col in df.columns:
                working_precip.loc[mask] = df.loc[mask, alt2_col].fillna(0)
        elif action == 'none':
            working_precip.loc[mask] = np.nan

        df[final_col] = working_precip.fillna(0)

        self.logger.info(f" Applied '{action}' correction to {changed:,} records (SOP 4.2.11 / 4.3)")
        return df


    def print_correction_report(self, original_df: pd.DataFrame,
                                corrected_df: pd.DataFrame):
        if 'siteID' in original_df.columns:
            site_id = str(original_df['siteID'].iloc[0])
        else:
            site_id = "UNKNOWN"

        self.logger.info(f" NADP SOP 304 PRECIPITATION CORRECTION FINAL REPORT - {site_id}")

        total_records = len(corrected_df)
        orig_sum = original_df['reportPCP'].sum()
        final_sum = corrected_df['corrected_PCP'].sum()

        dry_hours = corrected_df.get('dry_exposure_hours', pd.Series([0.0])).iloc[0]
        undefined_flag = corrected_df.get('undefined_dry_flag', pd.Series([False])).iloc[0]
        undefined_periods = corrected_df.get('undefined_periods', pd.Series([""])).iloc[0]

        self.logger.info(f"(1) OVERVIEW")
        self.logger.info(f"   Total 15-minute records processed : {total_records:,}")
        self.logger.info(f"   Original Raw Precipitation        : {orig_sum:.3f} inches")
        self.logger.info(f"   Final Corrected Precipitation     : {final_sum:.3f} inches")
        self.logger.info(f"   Net change                        : {final_sum - orig_sum:+.3f} inches")
        self.logger.info(f"   Dry collector exposure (no precip): {dry_hours:.2f} hours")

        false_count = corrected_df.get('false_precip_flag', pd.Series([False]*len(corrected_df))).sum()
        noisy_count = corrected_df.get('noisy_flag', pd.Series([False]*len(corrected_df))).sum()
        self.logger.info(f" False Precip (flag 'f')        : {false_count:,} records")
        self.logger.info(f" Noisy Load Cell (flag 'n')     : {noisy_count:,} records")
        if undefined_flag:
            self.logger.info(" WARNING: UNDEFINED CONDITION DETECTED : >6 hours dry exposure -> entire file marked 'none'")
            if undefined_periods:
                self.logger.info(f" Time periods: {undefined_periods}")

        self.logger.info(f"(2) MACHINE SCREENING FLAGS DETECTED")
        self.logger.info(f"   False Precip (flag 'f')   : {false_count:,} records")
        self.logger.info(f"   Noisy Load Cell (flag 'n') : {noisy_count:,} records")

        self.logger.info(f"(3) CORRECTIONS APPLIED")
        zero_count = ((corrected_df['corrected_PCP'] == 0) & (original_df['reportPCP'] > 0)).sum()
        nan_count = corrected_df['corrected_PCP'].isna().sum()
        keep = ((corrected_df['corrected_PCP'] == original_df['reportPCP']) & (original_df['reportPCP'].notna())).sum()
        alt_count = 0
        if 'altPrecip' in corrected_df.columns and corrected_df['altPrecip'].notna().any():
            alt_count = ((corrected_df['reportPCP'] != corrected_df['altPrecip']) &
                         (corrected_df['reportPCP'] == original_df['reportPCP'])).sum()
        
        alt2_count = 0
        if 'altPrecip2' in corrected_df.columns and corrected_df['altPrecip2'].notna().any():
            alt2_count = ((corrected_df['reportPCP'] != corrected_df['altPrecip2']) &
                        (corrected_df['reportPCP'] == original_df['reportPCP'])).sum()
        

        self.logger.info(f"   * 'none'  -> marked missing/unusable : {nan_count:,} records")
        self.logger.info(f"   * 'zero'  -> set to zero precipitation : {zero_count:,} records")
        self.logger.info(f"   * 'altPrecip'  -> used altPrecip (OTT|ETI)     : {alt_count:,} records")
        self.logger.info(f"   * 'altPrecip2'  -> used altPrecip2 (ETI)    : {alt2_count:,} records")
        self.logger.info(f"   * keep    -> left as RawPrecip        : {keep:,} records")

        self.logger.info(f"(4) FINAL STATUS")
        self.logger.info(f"   Column 'corrected_PCP' contains the corrected values.")
        self.logger.info(f"   Columns 'reportPCP' and 'reportPrecip' are reference values only.")


    def run_autocorrect(self, df_in, siteID, labno, local_start, local_end, start_dt, end_dt,
                       expected_records, actual_records, valid_records, valid_records_reportPCP) -> pd.DataFrame:
        """
        New parameter: pct_record (float between 0 and 1) = percentage of actual records relative to expected records
        
        """

        pct_record = (actual_records / expected_records) if actual_records > 0 else 0.0
        pct_good = (valid_records / actual_records) if actual_records > 0 else 0.0
        pct_good_reportPCP = (valid_records_reportPCP / actual_records) if actual_records > 0 else 0.0
        start_dt_UTC = pd.to_datetime(df_in['LocalReportDateTime'].min(), utc=True)
        end_dt_UTC = pd.to_datetime(df_in['LocalReportDateTime'].max(), utc=True)
     
        self.logger.info("="*60)
        self.logger.info(f" Processing siteID: {siteID}, LABNO: {labno} | "
                        f"Expected: {expected_records} | Actual: {actual_records} | valid_records_reportPCP:{valid_records_reportPCP} |valid reportPrecip: {valid_records} ")
        self.logger.info(f" pct_record: {pct_record:.1%} | pct_good_reportPCP: {pct_good_reportPCP:.1%} |pct_good: {pct_good:.1%} ")
        self.logger.info(f"Start local: {local_start} | End local: {local_end}")
        self.logger.info(f"Start UTC: {start_dt} | End UTC: {end_dt}")
        self.logger.info(f"Start UTC match 15min from actual record from database: {start_dt_UTC} | End UTC match 15min from actual record in database: {end_dt_UTC}")
        if pct_record == 1.0:
            self.logger.info(" 100% of expected records present. Proceeding with autocorrection | equipment functionality.")
        if pct_record != 1.0:
            self.logger.info("The equipment may not be functioning correctly.")

        # === 1. Handle input type ===
        if isinstance(df_in, (str, os.PathLike)):
            self.logger.info(f" Loading data from file: {df_in}")
            df_original = pd.read_csv(df_in, parse_dates=['LocalReportDateTime'])
        elif isinstance(df_in, pd.DataFrame):
            self.logger.info(" Using provided DataFrame directly")
            df_original = df_in.copy()
        else:
            raise TypeError(f"df_in must be a file path or pandas DataFrame, got {type(df_in)}")

  
        if pct_record <= 0.85:
            self.logger.warning(f" WARNING {siteID}: pct_record ({pct_record:.1%}) <= 85% ; skipping correction.")
            cols = [
                "LocalReportDateTime", "siteID", "reportPCP", "reportPrecip", 
                "corrected_PCP", "coll1cycles", "exp1", "ActDepth", 
                "ActDepthRA", "altPrecip", "altPrecip2", "minVolt", 
                "ActTemp", "opdCounts", "CumReportPCP", "CumReportPrecip", 
                "Cumcoll1cycles", "Cumexp1", "delta_bucket", "false_precip_flag", 
                "delta", "sign_change", "noisy_flag", "total_exposure_cum", 
                "exp_increment_sec", "exp_increment_hours", "is_dry_open", 
                "dry_group", "dry_exposure_hours", "undefined_dry_flag", 
                "undefined_periods", "max_continuous_dry_hours"
            ]

            # Initialize the empty DataFrame
            df = pd.DataFrame(columns=cols)
            return df
        if pct_good <= 0.90:
            self.logger.warning(f" WARNING {siteID}: pct_good ({pct_good:.1%}) <= 90% ; skipping correction.")
            cols = [
                "LocalReportDateTime", "siteID", "reportPCP",  "reportPrecip", 
                "corrected_PCP", "coll1cycles", "exp1", "ActDepth", 
                "ActDepthRA", "altPrecip", "altPrecip2", "minVolt", 
                "ActTemp", "opdCounts", "CumReportPCP", "CumReportPrecip", 
                "Cumcoll1cycles", "Cumexp1", "delta_bucket", "false_precip_flag", 
                "delta", "sign_change", "noisy_flag", "total_exposure_cum", 
                "exp_increment_sec", "exp_increment_hours", "is_dry_open", 
                "dry_group", "dry_exposure_hours", "undefined_dry_flag", 
                "undefined_periods", "max_continuous_dry_hours"
            ]

            # Initialize the empty DataFrame
            df = pd.DataFrame(columns=cols)
            return df

        # Check consecutive nulls in reportPCP
        df_temp = df_original.copy()
        null_series = df_temp['reportPCP'].isna()
        max_consec_null = (null_series.astype(int)
                           .groupby((null_series != null_series.shift()).cumsum())
                           .sum().max())
       
        if max_consec_null > 4:
            self.logger.warning(f" WARNING {siteID}: Found {max_consec_null} consecutive nulls in reportPCP "
                              f"(max allowed = 4) ; skipping correction.")
            cols = [
                "LocalReportDateTime", "siteID", "reportPCP", "reportPrecip", 
                "corrected_PCP", "coll1cycles", "exp1", "ActDepth", 
                "ActDepthRA", "altPrecip", "altPrecip2", "minVolt", 
                "ActTemp", "opdCounts", "CumReportPCP", "CumReportPrecip", 
                "Cumcoll1cycles", "Cumexp1", "delta_bucket", "false_precip_flag", 
                "delta", "sign_change", "noisy_flag", "total_exposure_cum", 
                "exp_increment_sec", "exp_increment_hours", "is_dry_open", 
                "dry_group", "dry_exposure_hours", "undefined_dry_flag", 
                "undefined_periods", "max_continuous_dry_hours"
            ]

            # Initialize the empty DataFrame
            df = pd.DataFrame(columns=cols)
            return df

        self.logger.info(f" Passed {siteID}: pct_record = {pct_record:.1%}, max consecutive nulls = {max_consec_null} ; proceeding")

        df = df_original.copy()

        # === 4. Ensure reportPrecip exists (reference only) ===
        if 'reportPrecip' not in df.columns:
            df['reportPrecip'] = df['reportPCP'].fillna(0)
        else:
            df['reportPrecip'] = df_original['reportPrecip'].copy()

        # === 5. Fill missing timestamps if actual < expected ===
        # (your commented gap-filling code can stay here - not changed)

        # === 6. Check 15-minute interval consistency ===
        df = df.sort_values('LocalReportDateTime').reset_index(drop=True)
        time_diff = df['LocalReportDateTime'].diff().dt.total_seconds() / 60
        irregular_mask = (time_diff != 15) & time_diff.notna()
        irregular_count = irregular_mask.sum()
        if irregular_count > 0:
            irregular_indices = irregular_mask[irregular_mask].index
            irregular_df = pd.DataFrame({
                'row_index': irregular_indices,
                'prev_time': df.loc[irregular_indices-1, 'LocalReportDateTime'].values,
                'curr_time': df.loc[irregular_indices, 'LocalReportDateTime'].values,
                'diff_minutes': time_diff[irregular_indices].round(2),
                'diff_seconds': (time_diff[irregular_indices] * 60).round(1)
            })
            
            self.logger.warning(
                f"WARNING {siteID}: Found {irregular_count} irregular 15-min intervals"
            )
            self.logger.warning(f"\n{irregular_df.to_string(index=False)}")

        # === 7. Run detection for noise and false precip ===
        df = self.detect_false_precip(df, siteID)
        df = self.detect_noisy_load_cell(df, siteID)
         

    

        # === 8. Apply corrections with NOISE SEVERITY LOGIC ===
        false_count = df['false_precip_flag'].sum()
        noisy_count = df['noisy_flag'].sum()
        total_records = len(df)
        noisy_ratio = noisy_count / total_records if total_records > 0 else 0.0

        self.logger.info(f"Site {siteID}: Noisy ratio = {noisy_ratio:.1%} "
                         f"({noisy_count:,}/{total_records:,} records)")

        # Smart Alt column selection (AltPrecip2 preferred) # key case sensitivity check for altPrecip2 vs AltPrecip2
        use_alt2 = False

        for col_name in ['altPrecip2', 'AltPrecip2']:
            if col_name in df.columns:
                s = df[col_name]
                
                if s.notna().any() and (s != 0).any():
                    use_alt2 = True
                    break
                else:
                    self.logger.info(
                        f"Warning: {col_name} available but all zeros or NaN -> skipping targeted corrections"
                    )
                    use_alt2 = False
            break 

        if noisy_ratio >= 0.50:
            # SUPER NOISE (>= 50%)
            self.logger.info(f" WARNING {siteID}: SUPER NOISE DETECTED ({noisy_ratio:.2%}) -> marking entire file as 'none'")
            df = self.correct_precipitation(df, action='none')
        elif false_count > 0 or noisy_ratio > 0.20:
            # MILD NOISE or false precip present
            self.logger.info(f" Warning {siteID}: Mild noise / false precip detected -> targeted corrections")
            df = self.correct_precipitation(df, action='zero', mask=df['false_precip_flag'])
            if use_alt2:
                self.logger.info(f" ETI NOAH available -> using altPrecip2 for correction records")
                df = self.correct_precipitation(df, action='alt2', mask=df['noisy_flag'])
            elif 'altPrecip' in df.columns or 'AltPrecip' in df.columns:
                self.logger.info(f" Only altPrecip available -> using altPrecip for correction records")
                df = self.correct_precipitation(df, action='alt', mask=df['noisy_flag'])
        else:
            # CLEAN (<= 20%)
            self.logger.info(f" Passed {siteID}: Clean data ({noisy_ratio:.2%} noisy) -> using best Alt column")
            df = self.correct_precipitation(df, action='zero', mask=df['false_precip_flag'])
            if use_alt2:
                self.logger.info(f" ETI NOAH available -> using altPrecip2 for correction records")
                df = self.correct_precipitation(df, action='alt2')
            elif 'altPrecip' in df.columns or 'AltPrecip' in df.columns:
                self.logger.info(f" Only altPrecip available -> using altPrecip for correction records")
                df = self.correct_precipitation(df, action='alt')
            else:
                self.logger.info(f" No AltPrecip/AltPrecip2 found -> keeping raw data")

        # === . Run detection for dry exposure===
        df = self.detect_collector_abnormal(df, siteID)
        df = self.detect_precip_no_exposure(df, siteID)
        df = self.detect_dry_exposure(df, siteID)
        df = self.detect_full_open_exposure(df, siteID)  




        

        # === 9. Force exact column order ===
        desired_order = ['LocalReportDateTime', 'siteID', 'reportPCP',  'corrected_PCP','reportPrecip',]
        remaining_cols = [col for col in df.columns if col not in desired_order]
        df = df[desired_order + remaining_cols]

        # === 10. Final report ===
        self.print_correction_report(df_original, df)

        return df