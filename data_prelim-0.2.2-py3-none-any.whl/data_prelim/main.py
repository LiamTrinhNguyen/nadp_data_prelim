__author__ = 'Liam TrinhNguyen'
__email__ = 'LiamTrinhNguyen@gmail.com or TrinhNguyen@wisc.edu'
__version__ = 'preLim v0.2.4'   

import re
import pandas as pd
from pathlib import Path
from dotenv import load_dotenv

# Absolute imports from your installed package
from data_prelim import (
    SQLConnection,
    SQLConnectionSettings,
    NTNInfo,
    NTNInfoSettings,
    PipelineSettings,
    NTNReviewPipeline,
    Autocorrect_Settings,
    PrecipAutocorrect
)


def get_valid_sample_ids() -> tuple[str, str]:
    """Prompts for, sanitizes, and validates start and end sample IDs."""
    pattern = re.compile(r"^([A-Z]\d{7}|[A-Z]{2}\d{4}[A-Z]{2})$")
 
    while True:
        start_id = input("Enter the starting sample ID (e.g., T2510007 or TT0134SW): ").strip().upper()
        end_id = input("Enter the ending sample ID (e.g., T2510808 or TT0205SW): ").strip().upper()
      
        if not start_id or not end_id:
            print("Error: Inputs cannot be empty.\n")
            continue
         
        if not pattern.match(start_id) or not pattern.match(end_id):
            print("Error: Invalid format. Must be either:")
            print(" (!) One letter + 7 digits (e.g., T2510007)")
            print(" (!) Two letters + 4 digits + two letters (e.g., TT0134SW)\n")
            continue
         
        if start_id > end_id:
            print(f"Error: Start ID ({start_id}) cannot be greater than End ID ({end_id}).\n")
            continue
         
        return start_id, end_id


def get_sample_list() -> list[str]:
    """Prompt for comma-separated sample list and validate."""
    pattern = re.compile(r"^([A-Z]\d{7}|[A-Z]{2}\d{4}[A-Z]{2})$")
   
    while True:
        user_input = input("\nEnter sample IDs separated by commas (e.g., T2510007, TT0134SW, T2510808): ").strip()
        if not user_input:
            print("Error: Input cannot be empty.")
            continue
           
        samples = [s.strip().upper() for s in user_input.split(',') if s.strip()]
       
        invalid = [s for s in samples if not pattern.match(s)]
        if invalid:
            print(f"Error: Invalid Sample ID(s): {', '.join(invalid)}")
            print("All IDs must follow the correct format.\n")
            continue
           
        unique_sorted = sorted(list(set(samples)))
        print(f"(!) Processed {len(unique_sorted)} unique samples (sorted).")
        return unique_sorted


def main():
    """Main execution entry point for the NADP Prelim pipeline."""
    # 1. Load the environment
    load_dotenv()
   
    # === Choose processing mode ===
    while True:
        mode = input("\nProcess by:\n"
                     "  1. Sample Range (Start -> End)\n"
                     "  2. Specific Sample List\n"
                     "Enter 1 or 2: ").strip()
        if mode in ['1', '2']:
            break
        print("Please enter 1 or 2.")

    print(f"\nMode selected: {'Sample Range' if mode == '1' else 'Sample List'}")

    # 2. Get sample input + define output folder
    if mode == '1':
        sampleID_start, sampleID_end = get_valid_sample_ids()
        sample_list = None
        output_subfolder = None
        print(f"Starting pipeline run for range: {sampleID_start} to {sampleID_end}")
    else:
        sample_list = get_sample_list()
        sampleID_start = sampleID_end = None
        
        # === SINGLE OUTPUT FOLDER FOR LIST MODE ===
        default_name = f"{sample_list[0]}_to_{sample_list[-1]}"
        # folder_input = input(f"\nEnter output folder name (Press Enter for default: {default_name}): ").strip()
        folder_input=default_name
        output_subfolder = folder_input if folder_input else default_name
        
        print(f"(!) All outputs will be saved in **single folder**: {output_subfolder}")

    # 3. Initialize Settings
    sql_settings = SQLConnectionSettings()
    ntn_settings = NTNInfoSettings()
    autocorrect_settings = Autocorrect_Settings()

    # 4. Report Pipeline (final step)
    reportpipeline = NTNReviewPipeline(
        sampleID_start or sample_list[0], 
        sampleID_end or sample_list[-1], 
        PipelineSettings()
    )

    # 5. Execute Pipeline
    all_dfs = []

    if mode == '1':  # Range Mode
        db_client = SQLConnection(sampleID_start, sampleID_end, settings=sql_settings)
        autocorrect = PrecipAutocorrect(sampleID_start, sampleID_end, autocorrect_settings)
        
        pipeline = NTNInfo(
            sampleID_start, sampleID_end,
            settings=ntn_settings,
            db_client=db_client,
            autocorrect=autocorrect
        )
        
        pipeline.gap_overlap_sample_check(sampleID_start, sampleID_end)
        pipeline.review_stat_ntn1(sampleID_start, sampleID_end)
        pipeline.chem_stattus_check(sampleID_start, sampleID_end)
        pipeline.reloadTOTP_ntn1(sampleID_start, sampleID_end)
        data = pipeline.combine_and_review(sampleID_start, sampleID_end)
        all_dfs.append(data)

    else:  # List Mode - Single Output Folder
        for sample_id in sample_list:
            print(f"\n{'='*75}")
            print(f"Processing single sample: {sample_id}")
            print(f"{'='*75}")
            
            db_client = SQLConnection(sample_id, sample_id, settings=sql_settings)
            autocorrect = PrecipAutocorrect(sample_id, sample_id, autocorrect_settings)
            
            # Use same output_subfolder for every sample
            single_pipeline = NTNInfo(
                sample_id, sample_id,
                settings=ntn_settings,
                db_client=db_client,
                autocorrect=autocorrect,
                output_subfolder=output_subfolder   #  for single folder when using list mode
            )
            
            single_pipeline.gap_overlap_sample_check(sample_id, sample_id)
            single_pipeline.review_stat_ntn1(sample_id, sample_id)
            single_pipeline.chem_stattus_check(sample_id, sample_id)
            single_pipeline.reloadTOTP_ntn1(sample_id, sample_id)
            
            data = single_pipeline.combine_and_review(sample_id, sample_id)
            all_dfs.append(data)

    # 6. Combine all data
    if len(all_dfs) > 1:
        print(f"\nCombining {len(all_dfs)} sample datasets into one final report...")
        final_data = pd.concat(all_dfs, ignore_index=True)
    else:
        final_data = all_dfs[0]

    # 7. Generate Final Report
    print("\nGenerating final combined report...")
    report = reportpipeline.load_and_optimize(final_data)
    reportpipeline.process_review(report,
                                  sampleID_start or sample_list[0],
                                  sampleID_end or sample_list[-1])

    print("\n Pipeline execution completed successfully!")
    if mode == '2':
        print(f"   All outputs saved in: {output_subfolder}")
    else:
        print(f"   All outputs saved in: {sampleID_start}_{sampleID_end}")


if __name__ == "__main__":
    main()