
__author__ = 'Liam TrinhNguyen'
__email__ =  'LiamTrinhNguyen@gmail.com or TrinhNguyen@wisc.edu'
__version__ = 'preLim v0.2.2'



import os, sys, psutil, logging, numpy as np, pandas as pd, datetime as dt
from typing import Optional
from sqlalchemy import create_engine, engine
from pathlib import Path
from logging.handlers import RotatingFileHandler
from datetime import datetime
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import FilePath, DirectoryPath

class SQLConnectionSettings(BaseSettings):
    output_dir: DirectoryPath 
    drive: str 
    server: str 
    model_config = SettingsConfigDict(env_file=".env", env_prefix="WSLH_", extra="ignore")


class SQLConnection:
    def __init__(self, sampleID_start_log, sampleID_end_log, settings: SQLConnectionSettings):
        self.settings = settings
        self.driver = self.settings.drive
        self.server = self.settings.server
        self.output_root = self.settings.output_dir.resolve()
        
        self._log_dir = self.output_root / "logs"
        self._data_dir = self.output_root / "processed_data"
        self.sampleID_start_log = sampleID_start_log
        self.sampleID_end_log = sampleID_end_log
        
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = self._setup_logger()
        self.logger.info("**********************************")
        self.logger.info("SQL Connection Initialized.")

    def _setup_logger(self) -> logging.Logger:

        logger_name = f"WSLH_NTN.{self.__class__.__name__}"
        logger = logging.getLogger(logger_name)

        # Avoid adding handlers multiple times
        if logger.hasHandlers():
            return logger

        logger.propagate = False
        logger.setLevel(logging.INFO)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_path = Path(self._log_dir) / f"pipeline_{self.sampleID_start_log}_{self.sampleID_end_log}_{timestamp}.log"

        formatter = logging.Formatter(
            '%(asctime)s - [%(name)s] - %(levelname)s: %(message)s'
        )

        # === SINGLE FILE, NO SIZE LIMIT ===
        fh = logging.FileHandler(log_path, mode='a', encoding='utf-8', delay=False)
        fh.setFormatter(formatter)
        logger.addHandler(fh)

        # Console output
        ch = logging.StreamHandler()
        ch.setFormatter(formatter)
        logger.addHandler(ch)


        return logger
    
    def handle_datetimeoffset(self,dto_value):
        ''' Convert a SQL Server datetimeoffset value to a Python datetime object. '''
        tup = struct.unpack("<6hI2h", dto_value)  # e.g., (2017, 3, 16, 10, 35, 18, 0, -6, 0)   
        tweaked = [tup[i] // 1000 if i == 6 else tup[i] for i in range(len(tup))] 
        return dt.datetime.fromisoformat("{:04d}-{:02d}-{:02d} {:02d}:{:02d}:{:02d}.{:06d} {:+03d}{:02d}".format(*tweaked)).astimezone(dt.timezone.utc).replace(tzinfo=None) 

        
    def connect_to_db_engine(self):
        try:
            # USE the attributes initialized from your .env via Pydantic
            connection_string = f'DRIVER={{{self.driver}}};SERVER={self.server};Trusted_Connection=yes;'
            connection_url = engine.URL.create(
                "mssql+pyodbc",
                query={"odbc_connect": connection_string}
            )
            
            db_engine = create_engine(connection_url)
            return db_engine
        
        except Exception as e:
            self.logger.error(f"Error creating engine: {e}") # Upgraded to use your logger
            return None
        
    def get_info_from_db(self, conn, query):
        try:
            cursor = conn.cursor()
            conn.add_output_converter(-155, self.handle_datetimeoffset)
            cursor.execute(query)
            rows = cursor.fetchall()
            return rows
        except Exception as e:
            print("Error executing query: ", e)
            return []
        
    def ntn_db_byLabnoID(self, conn, start_labno='T2508221', end_labno='T2509230'):
        # all columns needed from NTN for next procedures

        c = [
            "REVCOMM",
            "SITE","LABNO","sampleStart", "sampleEnd","LABC","RECDATE",
            "sampVol",
            "ScreenStat",
            "totp", "SP",
            "sl","QR","notes",'TroubleFlag', 'FOBS','FLDCOMM'
            ]

        NTN_QUERY = f"""
        select {','.join(c)}
        from ntn.dbo.NTN1
        where LABNO between '{start_labno}' and '{end_labno}'
            order by SampleEnd ASC;
        """
        df = pd.read_sql(NTN_QUERY, conn)
        df['sampleStart']= pd.to_datetime(df['sampleStart'],utc=True)
        df['sampleEnd']= pd.to_datetime(df['sampleEnd'],utc=True)

        end_labno_min = df['sampleEnd'].min()
        end_labno_max = df['sampleEnd'].max()

      
        

        df_ntn_db = df.copy()
        return df_ntn_db, end_labno_min, end_labno_max
    
    def ntn_getOffset(self, conn, start_labno='T2508221'):
        """
        Extract timezone offset directly from sampleStart and sampleEnd columns.
        """
        columns = ["SITE", "LABNO", "sampleStart", "sampleEnd"]
        
        NTN_QUERY = f"""
            SELECT {','.join(columns)}
            FROM  ntn.dbo.NTN1
            WHERE LABNO = '{start_labno}'
        """

        df = pd.read_sql(
        NTN_QUERY, 
        conn,
        parse_dates=None,                    # Disable auto date parsing
        dtype={"sampleStart": "string", "sampleEnd": "string"}   # Force as string
    )

        if df.empty:
            raise ValueError(f"No record found for LABNO = '{start_labno}'")

        row = df.iloc[0]

        # Parse the datetime strings that already include offset
        start_dt = pd.to_datetime(row.sampleStart)   # No utc=True
        end_dt   = pd.to_datetime(row.sampleEnd)

        # Extract offset in +HH:MM format
        def get_offset(dt):
            if dt.tz is None:
                return '+00:00'  # fallback if no tz info
            # strftime('%z') returns +HHMM → convert to +HH:MM
            offset_raw = dt.strftime('%z')
            return f"{offset_raw[:3]}:{offset_raw[3:]}" if offset_raw else '+00:00'

        offset_samplestart = get_offset(start_dt)
        offset_sampleend   = get_offset(end_dt)

        return offset_samplestart, offset_sampleend

    def ntn_db_bydate(self, conn, siteID,day,addday):
        # all columns needed from NTN for next procedures

        c = ["SITE","LABNO","sampleStart", "sampleEnd","LABC"]

        NTN_QUERY = f"""
        declare @day Date = '{day}'
        select {','.join(c)}
        from ntn.dbo.NTN1
        where SampleEnd between DATEADD(day, -{addday}, @day) and DATEADD(day, {addday}, @day)
            and SITE = '{siteID}'
        order by SampleStart DESC
        """
        df = pd.read_sql(NTN_QUERY, conn)

        df = df.rename(columns={'SampleStart': 'sampleStart', 'SampleEnd': 'sampleEnd'})
        df_ntn_db = df.copy()
        return df_ntn_db
    
    def ntn_db_betweendate(self, conn, siteID,day_start, day_end):
        # all columns needed from NTN for next procedures

        c = ["SITE","LABNO","sampleStart", "sampleEnd","LABC"]

        NTN_QUERY = f"""
        select {','.join(c)}
        from ntn.dbo.NTN1
        where SampleEnd between '{day_start}' and '{day_end}'
            and SITE = '{siteID}'
        order by SampleStart DESC
        """
        df = pd.read_sql(NTN_QUERY, conn)

        df = df.rename(columns={'SampleStart': 'sampleStart', 'SampleEnd': 'sampleEnd'})
        df_ntn_db = df.copy()
        return df_ntn_db


    def pptuploadfiles_db(self, conn, rangestartDate, rangeendDate, siteID):
        c = ["SiteID","prevDate","startDate","endDate","reviewNotes",'precipUsable','processid']
        PPT_UPLOADFILES_QUERY = f"""
        select {','.join(c)}
        from nadpppt.dbo.pptuploadfiles
        where startDate between  '{rangestartDate}' and '{rangeendDate}'
        and siteID = '{siteID}'
        order by startDate ASC
        """

        df = pd.read_sql(PPT_UPLOADFILES_QUERY, conn)
        df['startDate']= pd.to_datetime(df['startDate'])
        df['endDate']= pd.to_datetime(df['endDate'])
        df_pptuploadfiles_db = df.copy()
        return df_pptuploadfiles_db



    def egauge_db(self, conn, siteID, rangestartDate, rangeendDate):
        
        EGAUGE_QUERY = f"""
        DECLARE @StartLocal VARCHAR(30) = '{rangestartDate}';
        DECLARE @EndLocal VARCHAR(30) = '{rangeendDate}';

        -- 1. Extract the offset dynamically for the grouping
        DECLARE @Offset VARCHAR(10) = RIGHT(@StartLocal, 6); 

        SELECT 
               -- Full Local DateTime
    
                CAST(SWITCHOFFSET(CAST([datetime] AS DATETIMEOFFSET), @Offset) AS DATETIME2) AS LocalReportDateTime,
                siteID,
                reportPCP,
                reportPrecip,
                coll1cycles,
                coll2cycles,
                coll3cycles,
                exp1,
                exp2,
                exp3,
                ActDepth,
                ActDepthRA,
                altPrecip,
                altPrecip2,
                minVolt,
                ActTemp,
                opdCounts,
                scantime,
                coll1Volt,
                coll2Volt,
                coll3Volt,


                -- === New accumulating columns (running totals) ===
                SUM(reportPCP)   OVER (ORDER BY [datetime] ROWS UNBOUNDED PRECEDING) AS CumReportPCP,
                SUM(reportPrecip)OVER (ORDER BY [datetime] ROWS UNBOUNDED PRECEDING) AS CumReportPrecip,
                SUM(coll1cycles)OVER (ORDER BY [datetime] ROWS UNBOUNDED PRECEDING) AS Cumcoll1cycles,
                SUM(exp1)OVER (ORDER BY [datetime] ROWS UNBOUNDED PRECEDING) AS Cumexp1
        FROM nadpPPT.dbo.pptJoint3
        WHERE siteID = '{siteID}'
        -- 2. Convert input strings to UTC for a high-performance index lookup
        AND datetime >= CAST(SWITCHOFFSET(CAST(@StartLocal AS DATETIMEOFFSET), '+00:00') AS DATETIME2)
        AND datetime <= CAST(SWITCHOFFSET(CAST(@EndLocal AS DATETIMEOFFSET), '+00:00') AS DATETIME2)
        """
        df = pd.read_sql(EGAUGE_QUERY, conn)
        df_egauge_db = df.copy()
        return df_egauge_db
    

    def chem_db(self, conn, sampleID_start, sampleID_end):
        c = ['LABNO', 'SITE',
        'sampleStart',
        'sampleEnd', 'ScreenStat',
        'labc', 'lph', 'lcond', 'so4', 'no3', 'cl', 'br', 'nh4', 'po4', 'ca', 'mg', 'na', 'k']
        CHEM_QUERY = f"""
        select {','.join(c)} 
        from ntn.dbo.ntn1
        where labno between '{sampleID_start}' and '{sampleID_end}' 
        order by labno asc
        """

        df = pd.read_sql(CHEM_QUERY, conn)
        df_chem_db = df.copy()
        return df_chem_db