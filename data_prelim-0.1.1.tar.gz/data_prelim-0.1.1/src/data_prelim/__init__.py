"""
NADP Prelim Data Pipeline
~~~~~~~~~~~~~~~~~~~~~~~~~
Laboratory data review pipeline for NADP/NTN.
"""


# 1. Lift classes from your modules to the package level
from .SQL_connection import SQLConnection, SQLConnectionSettings
from .NTN_info import NTNInfo, NTNInfoSettings
from .NTN_report import PipelineSettings, NTNReviewPipeline

# 2. Define __all__ to control what is exported
__all__ = [
    "SQLConnection",
    "SQLConnectionSettings",
    "NTNInfo",
    "NTNInfoSettings",
    "PipelineSettings",
    "NTNReviewPipeline"
]

# 3. Metadata for version tracking and auditing
__author__ = "Liam TrinhNguyen/ WSLH data scientist"
__version__ = "0.1.0"