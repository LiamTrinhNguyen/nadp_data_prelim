__author__ = 'Liam TrinhNguyen'
__email__ =  'LiamTrinhNguyen@gmail.com or TrinhNguyen@wisc.edu'
__version__ = 'preLim v0.2.0'

import struct, os, sys, psutil, logging, re
import numpy as np
import datetime as dt
from tqdm.auto import tqdm
import pandas as pd
from typing import Optional
from pathlib import Path
from logging.handlers import RotatingFileHandler
from datetime import datetime
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import FilePath, DirectoryPath

# MUST import your database class from your other file
from .SQL_connection import SQLConnection
from .Precip_autocorrect import PrecipAutocorrect, Autocorrect_Settings

# set pandas options for full display
pd.set_option('display.max_columns', None)
pd.set_option('display.max_colwidth', None)

class NTNInfoSettings(BaseSettings):
    output_dir: DirectoryPath 
    model_config = SettingsConfigDict(env_file=".env", env_prefix="WSLH_", extra="ignore")

class NTNInfo:
   
    def __init__(self, settings: NTNInfoSettings, db_client: SQLConnection, autocorrect: PrecipAutocorrect):
        self.settings = settings
        self.db_client = db_client 
        self.autocorrect = autocorrect

        self.output_root = self.settings.output_dir.resolve()
        
        self._log_dir = self.output_root / "logs"
        self._data_dir = self.output_root / "processed_data"
        
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = self._setup_logger()
        self.logger.info("NTN Info Pipeline Initialized.")

    def _setup_logger(self) -> logging.Logger:
        logger_name = f"WSLH_NTN.{self.__class__.__name__}"
        logger = logging.getLogger(logger_name)
        logger.propagate = False 

        if logger.hasHandlers(): 
            return logger
            
        logger.setLevel(logging.INFO)
        log_path = str(self._log_dir / f"pipeline_{datetime.now().strftime('%Y-%m-%d')}.log")
        
        formatter = logging.Formatter('%(asctime)s - [%(name)s] - %(levelname)s: %(message)s')
        
        fh = RotatingFileHandler(log_path, maxBytes=5*1024*1024, backupCount=3)
        fh.setFormatter(formatter)
        logger.addHandler(fh)
        
        ch = logging.StreamHandler()
        ch.setFormatter(formatter)
        logger.addHandler(ch)
        return logger

    def combine_unique(self, series):
        values = [str(v).strip() for v in series.dropna().unique() if str(v).strip() != '']
        return ', '.join(values) if values else 'M'

    def pandasDataframe_to_csv(self, pandasDataframe: pd.DataFrame, pathOfSaveFile: str, nameFileSaveAs: str) -> Optional[pd.DataFrame]:
        instance_to_save = pandasDataframe
        if not isinstance(instance_to_save, pd.DataFrame):
            self.logger.error("Error: The input is not a pandas DataFrame, cannot process further.")
            raise TypeError(f"Expected a pandas DataFrame, but got {type(pandasDataframe).__name__}.")
        
        if not os.path.isdir(pathOfSaveFile):
            os.makedirs(pathOfSaveFile)
            
        out_file_csv_path = os.path.join(pathOfSaveFile, nameFileSaveAs)
        instance_to_save.to_csv(out_file_csv_path, index=False)
        return instance_to_save

    def review_stat_ntn1(self, sampleID_start, sampleID_end):
        # Route DB calls through self.db_client
        conn = self.db_client.connect_to_db_engine()
        if not conn:
            raise ConnectionError("Database connection failed.")

        df_ntn_db, end_labno_min, end_labno_max = self.db_client.ntn_db_byLabnoID(conn, sampleID_start, sampleID_end)
        
        validation_errors = []
        self.logger.info(f"---- [PHASE 2]: Checking screen status ({sampleID_start} to {sampleID_end})")
        for siteID, df_eachSIte in tqdm(df_ntn_db.groupby('SITE'), desc=f'---- [PHASE 2]: checking screen status ({sampleID_start} to {sampleID_end})', ascii='-#'):
            if df_eachSIte['ScreenStat'].isnull().any():
                validation_errors.append(f"SiteID {siteID}: Missing ScreenStat values.")
            elif (df_eachSIte['ScreenStat'] == 'Entry').any():
                validation_errors.append(f"SiteID {siteID}: Failed due to 'Entry' status.")

        if validation_errors:
            error_report = "Validation failed. Please correct the following before proceeding:\n" + "\n".join(validation_errors)
            raise ValueError(error_report)

        self.logger.info("Passed: All Screen Status (ScreenStat) available to review.")
        return df_ntn_db, end_labno_min, end_labno_max

    def chem_stattus_check(self, sampleID_start, sampleID_end):
        conn = self.db_client.connect_to_db_engine()
        if not conn:
            raise ConnectionError("Database connection failed.")

        df_chem_db = self.db_client.chem_db(conn, sampleID_start, sampleID_end)
        chem_cols = ['lph', 'lcond', 'so4', 'no3', 'cl', 'br', 'nh4', 'po4', 'ca', 'mg', 'na', 'k']
        
        mask = df_chem_db[chem_cols].isnull().any(axis=1)
        df_missing_data = df_chem_db[mask]

        if not df_missing_data.empty:
            error_records = []
            for row in df_missing_data.itertuples():
                missing_cols = [col for col in chem_cols if pd.isna(getattr(row, col))]
                error_records.append({
                    'LABNO': row.LABNO,
                    'SiteID': row.SITE,
                    'SampleStart': pd.to_datetime(row.sampleStart).tz_localize(None),
                    'SampleEnd': pd.to_datetime(row.sampleEnd).tz_localize(None),
                    'Missing_chem': ", ".join(missing_cols)
                })
                
            df_missing_chem = pd.DataFrame(error_records)
            print(f"\n{df_missing_chem.to_string()}\n")
            raise ValueError("Chemistry analysis incomplete. Please correct missing values.")

        self.logger.info("Passed: All chemistry status checks passed!")
        return df_chem_db

    def reloadTOTP_ntn1(self, sampleID_start, sampleID_end):
        conn = self.db_client.connect_to_db_engine()
        if not conn:
            raise ConnectionError("Database connection failed.")

        df_ntn_db, end_labno_min, end_labno_max = self.db_client.ntn_db_byLabnoID(conn, sampleID_start, sampleID_end)
        missing_totp_mask = df_ntn_db['totp'].isnull()
        all_reloadTOTP_ntn1 = df_ntn_db[missing_totp_mask]
        output_dir = str(self._data_dir / f"{sampleID_start}_{sampleID_end}")

        if not all_reloadTOTP_ntn1.empty:
            error_report_df = all_reloadTOTP_ntn1[['SITE', 'LABNO', 'sampleStart', 'sampleEnd', 'totp']]
            self.pandasDataframe_to_csv(error_report_df, output_dir, 'missing_totp_records.csv')
            print(f"\n{error_report_df.to_string()}\n")
            raise ValueError("Missing TOTP values found.")

        self.logger.info("Passed: All total precip (TOTP) available.")
        return df_ntn_db, end_labno_min, end_labno_max

    def gap_overlap_sample_check(self, sampleID_start, sampleID_end):
            conn = self.db_client.connect_to_db_engine()
            if not conn:
                raise ConnectionError("Database connection failed.")

            
            df_ntn_db, end_min, end_max = self.db_client.ntn_db_byLabnoID(conn, sampleID_start, sampleID_end)


            df_ntn_db = df_ntn_db[['SITE', 'LABNO', 'sampleStart', 'sampleEnd', 'LABC']].sort_values(by=['SITE', 'sampleStart']).reset_index(drop=True)
            
            df_ntn_db = df_ntn_db[df_ntn_db['LABC'] != 'DK'].copy()
            
            if df_ntn_db.empty:
                self.logger.warning("No valid samples to check after 'DK' filter.")
                return df_ntn_db

            df_ntn_db['sampleStart'] = pd.to_datetime(df_ntn_db['sampleStart'], utc=True)
            df_ntn_db['sampleEnd'] = pd.to_datetime(df_ntn_db['sampleEnd'], utc=True)
            
            top_year_start = df_ntn_db['sampleStart'].dt.year.mode()[0]
            top_year_end = df_ntn_db['sampleEnd'].dt.year.mode()[0]
            
            all_incorrect_records = []
            all_date_duplicates = []
            all_gap_records = []
            all_overlap_records = []
            
            self.logger.info(f"---- [PHASE 1]:Fetching extra data for gap/overlap checks ({sampleID_start} to {sampleID_end})")
            for siteID, df_each in tqdm(df_ntn_db.groupby('SITE'), desc='---- [PHASE 1]:Fetching extra data for gap/overlap checks', ascii='-#'):
                if siteID in df_ntn_db['SITE'].unique():
                    len_df_each = len(df_each)
                    day_before = df_each['sampleStart'].min()
                    day_after = df_each['sampleEnd'].max()
                    delta_days = [30, 60, 90]

                    # print(df_each)
                    
                    master_df_short = pd.DataFrame()

                    for d in delta_days:
                        df_extra_before = self.db_client.ntn_db_bydate(conn, siteID, day_before, d)
                        df_extra_after = self.db_client.ntn_db_bydate(conn, siteID, day_after, d)
                        df_record_between =self.db_client.ntn_db_betweendate(conn, siteID, day_before, day_after)

                        master_df_temp = pd.concat([df_each, df_record_between, df_extra_before, df_extra_after], ignore_index=True)
                        master_df_temp = master_df_temp.drop_duplicates(subset=['LABNO']).sort_values(by=['sampleStart'], ascending=True).reset_index(drop=True)
                        # print(master_df_temp)
                        try:
                            pos_start = np.where(master_df_temp['sampleStart'] == day_before)[0][0]
                            pos_end = np.where(master_df_temp['sampleEnd'] == day_after)[0][0]

                            has_padding_before = pos_start > 0
                            has_padding_after = pos_end < (len(master_df_temp) - 1)

                            safe_start = max(0, pos_start - 2)
                            master_df_short = master_df_temp.iloc[safe_start : pos_end + 3].copy()

                            if len(master_df_short) >= len_df_each + 2 and has_padding_before and has_padding_after:
                                break 
                                
                            elif d == delta_days[-1]:
                                self.logger.warning(
                                    f"Site {siteID}: Missing bounding records after {d} days. "
                                    f"Padding Before: {has_padding_before}, Padding After: {has_padding_after}"
                                )
                                break

                        except IndexError:
                            continue
                    # print(master_df_short)
                    # input(f"Site {siteID}: Retrieved {len(master_df_short)} records for gap/overlap checks. Press Enter to continue...")

                    
                    if not master_df_short.empty:
                        master_df = master_df_short[master_df_short['LABC'] != 'DK'].copy()
                        master_df['sampleStart'] = pd.to_datetime(master_df['sampleStart'], utc=True)
                        master_df['sampleEnd'] = pd.to_datetime(master_df['sampleEnd'], utc=True)
                        master_df = master_df.sort_values(by=['sampleStart'], ascending=False).reset_index(drop=True)
                        
                        master_df['gap_BeforeTo_mins'] = (master_df['sampleStart'] - master_df['sampleEnd'].shift(-1)).dt.total_seconds() / 60
                        master_df['gap_ToNext_mins'] = (master_df['sampleStart'].shift(1) - master_df['sampleEnd']).dt.total_seconds() / 60
                        master_df['gap_BeforeTo_hours'] = master_df['gap_BeforeTo_mins'] / 60
                        master_df['gap_ToNext_hours'] = master_df['gap_ToNext_mins'] / 60
                        master_df['gap_BeforeTo_days'] = master_df['gap_BeforeTo_hours'] / 24
                        master_df['gap_ToNext_days'] = master_df['gap_ToNext_hours'] / 24

                        # print(master_df)
                        target_labnos = df_each['LABNO'].unique()
                        gap_mask = (master_df['gap_ToNext_mins'] > 60) | (master_df['gap_BeforeTo_mins'] > 60)
                        overlap_mask = (master_df['gap_ToNext_mins'] < 0) | (master_df['gap_BeforeTo_mins'] < 0)

                        invalid_dates = master_df['sampleStart'] > master_df['sampleEnd']
                        incorrect_df = master_df[invalid_dates & master_df['LABNO'].isin(target_labnos)][['SITE', 'LABNO', 'sampleStart', 'sampleEnd']]
                        if not incorrect_df.empty:
                            all_incorrect_records.append(incorrect_df)

                        date_duplicates_font = master_df[(master_df['sampleStart'] == master_df['sampleStart'].shift(1))  & 
                                                    (master_df['sampleEnd'] == master_df['sampleEnd'].shift(1))]
                        date_duplicates_front_df = date_duplicates_font[date_duplicates_font['LABNO'].isin(target_labnos)][['SITE', 'LABNO', 'sampleStart', 'sampleEnd']]
                        if not date_duplicates_front_df.empty:
                            all_date_duplicates.append(date_duplicates_front_df)
                        
                        date_duplicates_back = master_df[
                                                    (master_df['sampleStart'] == master_df['sampleStart'].shift(-1))  & 
                                                    (master_df['sampleEnd'] == master_df['sampleEnd'].shift(-1))]
                        date_duplicates_back_df = date_duplicates_back[date_duplicates_back['LABNO'].isin(target_labnos)][['SITE', 'LABNO', 'sampleStart', 'sampleEnd']]        
                        
                        if not date_duplicates_back_df.empty:
                            all_date_duplicates.append(date_duplicates_back_df)

                        gap_df = master_df[gap_mask & master_df['LABNO'].isin(target_labnos)].copy()
                        if not gap_df.empty:
                            all_gap_records.append(gap_df)

                        overlap_df = master_df[overlap_mask & master_df['LABNO'].isin(target_labnos)].copy()
                        if not overlap_df.empty:
                            all_overlap_records.append(overlap_df)

            output_dir = str(self._data_dir / f"{sampleID_start}_{sampleID_end}")
            out_of_year_mask = (df_ntn_db['sampleStart'].dt.year != top_year_start) | (df_ntn_db['sampleEnd'].dt.year != top_year_end)
            
            if out_of_year_mask.any():
                out_of_year = df_ntn_db[out_of_year_mask][['SITE', 'LABNO', 'sampleStart', 'sampleEnd']]
                self.pandasDataframe_to_csv(out_of_year, output_dir, f'{sampleID_start}_{sampleID_end}_out_of_year_records.csv')
                self.logger.warning("WARNING: Records found outside the expected mode year. ")
                

            # CORRECTED LIST CHECKS: Removed .empty for standard Python list evaluation
            if all_incorrect_records:
                incorrect_all_df = pd.concat(all_incorrect_records, ignore_index=True)
                self.pandasDataframe_to_csv(incorrect_all_df, output_dir, 'invalid_dates.csv')
                self.logger.warning("WARNING: Invalid date records found. Check logs/csvs.")

            if all_date_duplicates:
                date_duplicates_all_df = pd.concat(all_date_duplicates, ignore_index=True)
                self.pandasDataframe_to_csv(date_duplicates_all_df, output_dir, 'duplicated_samples.csv')
                self.logger.warning("WARNING: Duplicate date records found. Check logs/csvs.")

            if all_gap_records:
                gaps_all_df = pd.concat(all_gap_records, ignore_index=True)
                self.pandasDataframe_to_csv(gaps_all_df, output_dir, 'all_gaps.csv')
                self.logger.warning("WARNING: Gap records found. Check logs/csvs.")

            if all_overlap_records:
                overlaps_all_df = pd.concat(all_overlap_records, ignore_index=True)
                self.pandasDataframe_to_csv(overlaps_all_df, output_dir, 'all_overlaps.csv')
                self.logger.warning("WARNING: Overlap records found. Check logs/csvs.")  

            self.logger.info("Passed: All sample dates, gaps, and overlaps checked.")
            return df_ntn_db


   
            

    def get_best_precip_match(self, sample_row, site_precip_df): # Added self
        if site_precip_df is None or site_precip_df.empty:
            return {}

        target_start = pd.to_datetime(sample_row.sampleStart).normalize()
        target_end = pd.to_datetime(sample_row.sampleEnd).normalize()
        deltas = [0, 1, 7, 15, 30, 60, 90]

        for d in deltas:
            search_start = target_start - pd.Timedelta(days=d)
            search_end = target_end + pd.Timedelta(days=d)

            mask = (site_precip_df['startDate'] >= search_start) & (site_precip_df['endDate'] <= search_end)
            match_df = site_precip_df[mask]

            if match_df.empty: continue

            res_min = match_df['startDate'].min().normalize()
            res_max = match_df['endDate'].max().normalize()
            is_covered = (res_min <= target_start) and (res_max >= target_end)
            
            if is_covered or (d == deltas[-1]):
                return {
                    'LABNO': sample_row.LABNO,
                    'recordStart': res_min,
                    'recordEnd': res_max,
                    'processid': self.combine_unique(match_df['processid']),
                    'reviewNotes': self.combine_unique(match_df['reviewNotes']),
                    'precipUsable': self.combine_unique(match_df['precipUsable'])
                }
        return {}

    def reviewNotes_ppt_to_ntn1(self, sampleID_start, sampleID_end): 
        conn = self.db_client.connect_to_db_engine()
        if not conn:
            raise ConnectionError("Database connection failed.")
      
        df_ntn_db, end_labno_min, end_labno_max = self.db_client.ntn_db_byLabnoID(conn, sampleID_start, sampleID_end)
        
        if df_ntn_db.isnull().values.any():
            raise ValueError("NTN1 data contains missing values.")

        df_ntn_db['sampleStart'] = pd.to_datetime(df_ntn_db['sampleStart'], utc=True).dt.tz_localize(None)
        df_ntn_db['sampleEnd'] = pd.to_datetime(df_ntn_db['sampleEnd'], utc=True).dt.tz_localize(None)
        df_ntn_db['fmt_SITE'] = df_ntn_db['SITE'].str.replace(r'^(\d{2})([a-zA-Z]{2})$', r'\2\1', regex=True)

        matched_records = []
        self.logger.info(f"---- [PHASE 3]:Matching reviewNotes ({sampleID_start} to {sampleID_end})")

        for siteID, df_site_samples in tqdm(df_ntn_db.groupby('SITE'), desc='---- [PHASE 3]: Matching reviewNotes ----', ascii='-#' ):
            fmt_site = df_site_samples['fmt_SITE'].iloc[0]
            if not re.match(r'^[a-zA-Z]{2}\d{2}$', fmt_site): continue 

            global_search_start = df_site_samples['sampleStart'].min() - pd.Timedelta(days=90)
            global_search_end = df_site_samples['sampleEnd'].max() + pd.Timedelta(days=90)

            df_site_precip = self.db_client.pptuploadfiles_db(conn, global_search_start, global_search_end, fmt_site)
            
            if df_site_precip is not None and not df_site_precip.empty:
                df_site_precip['startDate'] = pd.to_datetime(df_site_precip['startDate'])
                df_site_precip['endDate'] = pd.to_datetime(df_site_precip['endDate'])
            else:
                df_site_precip = pd.DataFrame()

            for row in df_site_samples.itertuples():
                match = self.get_best_precip_match(row, df_site_precip)
                if match:
                    matched_records.append(match)
                else:
                    matched_records.append({
                        'LABNO': row.LABNO, 'recordStart': pd.NaT, 'recordEnd': pd.NaT,
                        'processid': '', 'reviewNotes': '', 'precipUsable': ''
                    })

        df_matched = pd.DataFrame(matched_records)
        output_dir = str(self._data_dir / f"{sampleID_start}_{sampleID_end}")
        self.pandasDataframe_to_csv(df_matched, output_dir, f'check_{sampleID_start}_{sampleID_end}.csv')

        all_df = pd.merge(df_ntn_db, df_matched, on='LABNO', how='left').sort_values(by=['SITE', 'sampleStart'])
        all_df['Start_End_diff'] = (all_df['sampleEnd'].dt.normalize() - all_df['sampleStart'].dt.normalize()).dt.days
        all_df['totp'] = all_df['totp'].round(3)
        all_df['sampleDepth'] = np.where(all_df['sampVol'] > 0, all_df['sampVol'] * .0005799, -9.999).round(3)

        final_cols = ["LABNO", "SITE", "sampleStart", "sampleEnd", "Start_End_diff", "LABC", "sampVol", "sampleDepth", "ScreenStat", "totp", "SP", "sl", "QR", "notes", "TroubleFlag", "recordStart", "recordEnd", "reviewNotes", "precipUsable"]
        all_df = all_df[final_cols]
        
        self.pandasDataframe_to_csv(all_df, output_dir, f'reviewNotes_ppt_to_ntn1_{sampleID_start}_{sampleID_end}.csv')  
        return all_df

    def compare_ppt_report_ntn1(self, sampleID_start, sampleID_end): 
        conn = self.db_client.connect_to_db_engine()
        output_dir = str(self._data_dir / f"{sampleID_start}_{sampleID_end}")
        if not conn:
            raise ConnectionError("Database connection failed.")

        df_ntn_db, end_labno_min, end_labno_max = self.db_client.ntn_db_byLabnoID(conn, sampleID_start, sampleID_end)
    
        df_ntn_db['RECDATE'] = pd.to_datetime(df_ntn_db['RECDATE']).dt.floor('min')
        df_ntn_db['SampleEnd_RECDATE'] = (
            pd.to_datetime(df_ntn_db['RECDATE']).dt.normalize() - 
            pd.to_datetime(df_ntn_db['sampleEnd'], utc=True).dt.tz_convert(None).dt.normalize()
        ).dt.days

        self.pandasDataframe_to_csv(df_ntn_db, output_dir, f'debug_ntn1_data_{sampleID_start}_{sampleID_end}.csv')



        if df_ntn_db.isnull().values.any():
            raise ValueError("NTN1 data contains missing values.")

        sorted_sites = sorted(df_ntn_db['SITE'].unique())
        egauge_records = [] 
        self.logger.info(f"---- [PHASE 4]: calculating e-gauge summary  ({sampleID_start} to {sampleID_end})")
        for siteID, df_eachSite in tqdm(df_ntn_db.groupby('SITE'), desc='---- [PHASE 4]: calculating e-gauge summary ', ascii='-#'):
            if siteID not in sorted_sites: continue
                
            for row in df_eachSite.itertuples():
                
                if siteID == '20NY':
                    temp_df = self.db_client.egauge_db(
                        conn, 'NY20',
                        row.sampleStart.isoformat(sep=' ', timespec='seconds'),
                        row.sampleEnd.isoformat(sep=' ', timespec='seconds')
                    ) # get the localtime tranfer into UTC
                else:
                    temp_df = self.db_client.egauge_db(
                        conn, siteID,
                        row.sampleStart.isoformat(sep=' ', timespec='seconds'),
                        row.sampleEnd.isoformat(sep=' ', timespec='seconds')
                    ) # get the localtime tranfer into UTC
                
                # Convert columns to float64 and round to 5 decimal places
                cols = ['reportPCP','reportPrecip','coll1cycles', 'exp1', 'ActDepth', 'ActDepthRA', 'altPrecip', 'altPrecip2', 'minVolt', 'ActTemp', 'opdCounts']
                temp_df[cols] = temp_df[cols].astype('float64').round(5)
                
        
                # print(auto_correctprecip)
                # input('testing auto correct precip. Press Enter to continue...')
                
                offset_samplestart, offset_sampleend = self.db_client.ntn_getOffset(conn, row.LABNO)

                start_dt = pd.to_datetime(row.sampleStart, utc=True)
                end_dt = pd.to_datetime(row.sampleEnd, utc=True)

                local_start = start_dt.tz_convert(offset_samplestart)
                local_end = end_dt.tz_convert(offset_sampleend)


                if temp_df is None or temp_df.empty:
                    actual_records = 0
                    valid_records = 0
                    expected_index = 0
                    total_precip_egauge = None
                    total_reportPCP = None

                else:
                    valid_recordsPCP = temp_df['reportPCP'].notna().sum()
                    total_reportPCP = f'{temp_df['reportPCP'].sum():.3f}' if valid_recordsPCP > 0 else None
                
                    actual_records = len(temp_df) # Exclude the last record which is often incomplete
                    valid_records = temp_df['reportPrecip'].notna().sum()
                    valid_records_reportPCP = temp_df['reportPCP'].notna().sum()
                    total_precip_egauge = f'{temp_df["reportPrecip"].sum():.3f}' if valid_records > 0 else None
                    expected_index = pd.date_range(
                        start=start_dt,
                        end=end_dt,
                        freq='15min'
                    )
                    expected_records = len(expected_index)

                
                

                raw_pct_record = (actual_records / expected_records) * 100 if actual_records > 0 else 0.0
                capped_pct_record = min(raw_pct_record, 100.0)
                pct_good = (valid_records / actual_records) * 100 if actual_records > 0 else 0.0

                auto_correctprecip = self.autocorrect.run_autocorrect(temp_df, siteID, row.LABNO, 
                                                                      local_start, local_end,
                                                                      start_dt, end_dt,
                                                                      
                                                                      expected_records, actual_records,
                                                                      valid_records, valid_records_reportPCP)
                sum_corrected_PCP = auto_correctprecip['corrected_PCP'].sum() if auto_correctprecip is not None and not auto_correctprecip.empty else None
                if sum_corrected_PCP is not None:
                    false_count = auto_correctprecip['false_precip_flag'].sum()
                    noisy_count = auto_correctprecip['noisy_flag'].sum()
                    total_records = len(auto_correctprecip)

                    # ====================== get dry exposure and full open status ======================         
                    rawdry_corrected = float(auto_correctprecip.get('dry_exposure_hours_correctedpcp', pd.Series([0.0])).iloc[0])  
                    dry_corrected =  f"{rawdry_corrected:.2f}"
                    rawdry_reportprecip = float(auto_correctprecip.get('dry_exposure_hours_reportprecip', pd.Series([0.0])).iloc[0])  
                    dry_reportprecip = f"{rawdry_reportprecip:.2f}"       
                    full_open = bool(auto_correctprecip.get('full_open_flag', pd.Series([False])).iloc[0])
                    # self.logger.info("=" * 50)         
                    # self.logger.info(f"Site {siteID}: === FINAL DRY EXPOSURE & OPEN STATUS SUMMARY ===")         
                    # self.logger.info(f"   Dry Exposure (corrected_PCP) : {dry_corrected:.2f} hours")         
                    # self.logger.info(f"   Dry Exposure (reportPrecip)  : {dry_reportprecip:.2f} hours")         
                    # self.logger.info(f"   Collector Full Open          : {'YES' if full_open else 'NO'}")         
                    # self.logger.info(f"   Total Dry Exposure Difference: {abs(dry_corrected - dry_reportprecip):.2f} hours")         
                    # self.logger.info("=" * 50)
                    # self.logger.info(f"Site {siteID} Summary -> Dry(corrected): {dry_corrected:.2f}h | " 
                    #                  f"Dry(reportPrecip): {dry_reportprecip:.2f}h | Full Open: {'YES' if full_open else 'NO'}")
 
                    
                    if total_records > 0:
                        noisy_ratio = int(round((noisy_count / total_records) * 100))
                    else:
                        noisy_ratio = None
                else: 
                    noisy_ratio = None
                    dry_corrected = None
                    dry_reportprecip = None
                    full_open = None

                output_dir_auto_correctprecip = str(self._data_dir / f"{sampleID_start}_{sampleID_end}" / f"auto_correctprecip")
                self.pandasDataframe_to_csv(auto_correctprecip, output_dir_auto_correctprecip, f'auto_analysis_{row.LABNO}.csv')
                

                egauge_records.append({
                    'LABNO': row.LABNO,
                    'SampleEnd_RECDATE': row.SampleEnd_RECDATE,
                    'SiteID': siteID,
                    'SampleStart': start_dt.tz_localize(None),
                    'SampleEnd': end_dt.tz_localize(None),
                    'reportPCP': total_reportPCP,
                    'PPT': total_precip_egauge,
                    'corrected_PCP': f"{sum_corrected_PCP:.5f}" if sum_corrected_PCP is not None else None,
                    'expect_ppt_record': expected_records,
                    'actual_ppt_record': actual_records,
                    'raw_pct_record': f"{raw_pct_record:.1f}",
                    'percent_record': f"{capped_pct_record:.1f}",
                    'percent_good_of_actual': f"{pct_good:.1f}",
                    'noisy_ratio_raw_pct_record': noisy_ratio,
                    'dryExp_correctedPCP': dry_corrected,
                    'dryExpo_reportprecip': dry_reportprecip,
                    'full_open_flag': full_open,
                    'REVCOMM': row.REVCOMM
                })
        df_egauge_db = pd.DataFrame(egauge_records).sort_values(by=['SiteID', 'SampleStart', 'SampleEnd_RECDATE'])     
        df_egauge_db = pd.merge(df_egauge_db, df_ntn_db[['LABNO', 'RECDATE']], on='LABNO', how='left')
        
        output_dir = str(self._data_dir / f"{sampleID_start}_{sampleID_end}")
        self.pandasDataframe_to_csv(df_egauge_db, output_dir, f'compare_ppt_report_ntn1_{sampleID_start}_{sampleID_end}.csv')  
        return df_egauge_db

    def combine_and_review(self, sampleID_start, sampleID_end): 
        conn = self.db_client.connect_to_db_engine()
        if not conn:
            self.logger.error("Database connection failed.")
            return None

        combined_df = self.reviewNotes_ppt_to_ntn1(sampleID_start, sampleID_end) 
        df_egauge_db = self.compare_ppt_report_ntn1(sampleID_start, sampleID_end) 
        
        df_egauge_db= df_egauge_db[['RECDATE','SampleEnd_RECDATE','LABNO','reportPCP','PPT', 'corrected_PCP','percent_record','percent_good_of_actual', 'noisy_ratio_raw_pct_record','dryExp_correctedPCP','dryExpo_reportprecip','full_open_flag','REVCOMM']]
        all_df = pd.merge(combined_df, df_egauge_db, on='LABNO', how='left')
        
        all_df['within_start_end'] = ( ((pd.to_datetime(all_df['recordStart'], utc=True).dt.tz_localize(None).dt.normalize()) >=  
                                    (pd.to_datetime(all_df['sampleStart'], utc=True).dt.tz_localize(None).dt.normalize())) &
                                    ((pd.to_datetime(all_df['recordEnd'], utc=True).dt.tz_localize(None).dt.normalize()) <= 
                                    (pd.to_datetime(all_df['sampleEnd'], utc=True).dt.tz_localize(None).dt.normalize())))
        
        final_cols = ['REVCOMM','LABNO','SITE','sampleStart','sampleEnd','Start_End_diff','RECDATE','SampleEnd_RECDATE',
                        'ScreenStat','LABC','sampVol','sampleDepth','totp','PPT','reportPCP','corrected_PCP','SP','sl','QR','notes','TroubleFlag',
                        'percent_record','percent_good_of_actual','noisy_ratio_raw_pct_record','dryExp_correctedPCP','dryExpo_reportprecip','full_open_flag','within_start_end','recordStart','recordEnd',
                        'reviewNotes','precipUsable']
        all_df = all_df[final_cols]
        output_dir = str(self._data_dir / f"{sampleID_start}_{sampleID_end}")
        self.pandasDataframe_to_csv(all_df, output_dir, f'Pre_report_ntn1_{sampleID_start}_{sampleID_end}.csv')  
        return all_df