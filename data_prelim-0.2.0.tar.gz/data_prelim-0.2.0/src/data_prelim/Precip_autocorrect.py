__author__ = 'Liam TrinhNguyen'
__email__ = 'LiamTrinhNguyen@gmail.com or TrinhNguyen@wisc.edu'
__version__ = 'preLim v0.2.0'

import os, sys, psutil, logging, numpy as np, pandas as pd
from pathlib import Path
from logging.handlers import RotatingFileHandler
from datetime import datetime
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import FilePath, DirectoryPath

# set pandas options for full display
pd.set_option('display.max_columns', None)
pd.set_option('display.max_colwidth', None)


class Autocorrect_Settings(BaseSettings):
    output_dir: DirectoryPath     
    model_config = SettingsConfigDict(env_file=".env", env_prefix="WSLH_", extra="ignore")


class PrecipAutocorrect:
    def __init__(self, settings: Autocorrect_Settings):
        self.settings = settings
        self.output_root = self.settings.output_dir.resolve()
        
        self._log_dir = self.output_root / "logs"
        self._data_dir = self.output_root / "processed_data"
        
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = self._setup_logger()
        self.logger.info(f"Autocorrect Settings Initialized.")
    
    def _setup_logger(self) -> logging.Logger:
        logger_name = f"WSLH_NTN.{self.__class__.__name__}"
        logger = logging.getLogger(logger_name)
        logger.propagate = False 

        if logger.hasHandlers(): 
            return logger
            
        logger.setLevel(logging.INFO)
        log_path = str(self._log_dir / f"pipeline_{datetime.now().strftime('%Y-%m-%d')}.log")
        
        formatter = logging.Formatter('%(asctime)s - [%(name)s] - %(levelname)s: %(message)s')
        
        fh = RotatingFileHandler(log_path, maxBytes=5*1024*1024, backupCount=3)
        fh.setFormatter(formatter)
        logger.addHandler(fh)
        
        ch = logging.StreamHandler()
        ch.setFormatter(formatter)
        logger.addHandler(ch)
        return logger

    # ========================== CORE FUNCTIONS ==========================
    def detect_false_precip(self, df: pd.DataFrame,
                            siteID,
                            time_col: str = 'LocalReportDateTime',
                            bucket_col: str = 'ActDepth',
                            precip_col: str = 'reportPCP',
                            threshold: float = 0.007) -> pd.DataFrame: # False Precip flag ‘f’ (load cell drops ≥ 0.007 inches while reporting rain)
        if 'siteID' in df.columns:
            site_id = str(df['siteID'].iloc[0])
        else:
            site_id = "UNKNOWN"
        df = df.copy()
        df[time_col] = pd.to_datetime(df[time_col])
        df = df.sort_values(time_col).reset_index(drop=True)
        df['delta_bucket'] = df[bucket_col].diff()
        false_mask = (df['delta_bucket'] <= -threshold) & (df[precip_col] > 0)
        df['false_precip_flag'] = False
        df.loc[false_mask, 'false_precip_flag'] = True
        n_false = false_mask.sum()

        self.logger.info(f"Site {siteID}: Detected {n_false:,} false precip records (SOP flag 'f')")

        # === Log details of the false records ===
        false_periods = []
        max_false_hours = 0.0
        if n_false > 0:
            df['false_group'] = (df['false_precip_flag'].astype(int).diff().ne(0)).cumsum()
            for _, group in df[df['false_precip_flag']].groupby('false_group'):
                hours = len(group) * 0.25   # 15 min = 0.25 hour
                if hours > max_false_hours:
                    max_false_hours = hours
                start = group[time_col].min().strftime('%Y-%m-%d %H:%M')
                end   = group[time_col].max().strftime('%Y-%m-%d %H:%M')
                if hours >= 0.5:
                    false_periods.append(f"{start} to {end} ({hours:.2f} hrs)")

        df['false_periods'] = " | ".join(false_periods) if false_periods else ""

        # ====================== CLEAN ONE-LINER LOGGING OF FALSE RECORDS ======================
        if n_false > 0:
            if false_periods:
                self.logger.info(f"Site {siteID}: False precip time periods: {'\n|'.join(false_periods)}")
            self.logger.info(f"Site {siteID}: Longest continuous false precip period: {max_false_hours:.2f} hours")
            
        return df


    def detect_noisy_load_cell(self, df: pd.DataFrame,
                               siteID,
                               time_col: str = 'LocalReportDateTime',
                               bucket_col: str = 'ActDepth',
                               window_hours: int = 6,
                               min_flips: int = 12) -> pd.DataFrame:
        """Detect noisy load cell (SOP flag 'n') and report specific time periods."""
        if 'siteID' in df.columns:
            site_id = str(df['siteID'].iloc[0])
        else:
            site_id = "UNKNOWN"

        df = df.copy()
        df[time_col] = pd.to_datetime(df[time_col])
        df = df.sort_values(time_col).reset_index(drop=True)
        
        df['delta'] = df[bucket_col].diff()
        df['sign_change'] = (df['delta'].shift(1) * df['delta'] < 0) & (df['delta'] != 0)
        
        df = df.set_index(time_col)
        rolling_flips = df['sign_change'].rolling(
            window=pd.Timedelta(hours=window_hours),
            min_periods=1
        ).sum()
        df['noisy_flag'] = rolling_flips >= min_flips
        df = df.reset_index()

        n_noisy = df['noisy_flag'].sum()
        self.logger.info(f"Site {siteID}: Detected {n_noisy:,} records affected by noisy load cell (SOP flag 'n')")

        # ====================== ENHANCED: Continuous noisy periods ======================
        noisy_periods = []
        max_noisy_hours = 0.0

        if n_noisy > 0:
            df['noisy_group'] = (df['noisy_flag'].astype(int).diff().ne(0)).cumsum()
            for _, group in df[df['noisy_flag']].groupby('noisy_group'):
                hours = len(group) * 0.25   # 15 min = 0.25 hour
                if hours > max_noisy_hours:
                    max_noisy_hours = hours
                start = group[time_col].min().strftime('%Y-%m-%d %H:%M')
                end   = group[time_col].max().strftime('%Y-%m-%d %H:%M')
                if hours >= 0.5:
                    noisy_periods.append(f"{start} to {end} ({hours:.2f} hrs)")

        df['noisy_periods'] = " | ".join(noisy_periods) if noisy_periods else ""

        # ====================== CLEAN ONE-LINER LOGGING OF NOISY RECORDS ======================
        if n_noisy > 0:
            # self.logger.info(
            #     f"Site {siteID} - Noisy records ({n_noisy}):\n"
            #     f"{df[df['noisy_flag']][[time_col, bucket_col, 'delta']].round(4).to_string(index=True)}"
            # )
            if noisy_periods:
                self.logger.info(f"Site {siteID}: Noisy time periods: {'\n|'.join(noisy_periods)}")
            self.logger.info(f"Site {siteID}: Longest continuous noisy period: {max_noisy_hours:.2f} hours")

        return df


    def detect_dry_exposure(self, df: pd.DataFrame,
                            siteID,
                            time_col: str = 'LocalReportDateTime') -> pd.DataFrame:
        """SOP Undefined Rule: collector open for >6 continuous hours during non-precipitation events.
        Computes dry exposure based on corrected_PCP, altPrecip, and altPrecip2."""
        
        if 'siteID' in df.columns:
            site_id = str(df['siteID'].iloc[0])
        else:
            site_id = "UNKNOWN"

        df = df.copy()
        df[time_col] = pd.to_datetime(df[time_col])
        df = df.sort_values(time_col).reset_index(drop=True)

        # Find exposure columns
        exposure_cols = [col for col in df.columns 
                        if col.lower() in ['exp1', 'exp2', 'exp3'] 
                        or col.lower().startswith('exp') 
                        or 'exposure' in col.lower()]

        if not exposure_cols:
            self.logger.info(f" Site {site_id}: No collector exposure columns found.")
            df['dry_exposure_hours'] = 0.0
            df['undefined_dry_flag'] = False
            df['undefined_periods'] = ""
            df['max_continuous_dry_hours'] = 0.0
            return df

        self.logger.info(f" Site {siteID}: Using exposure columns: {exposure_cols}")

        # ====================== Find precipitation columns (case insensitive) ======================
        precip_sources = {}

        candidates = {
            'corrected_PCP': ['corrected_PCP'],
            'reportPrecip': ['reportPrecip'],
            'altPrecip2': ['altPrecip2', 'AltPrecip2', 'altprecip2', 'Altprecip2'],
            'altPrecip': ['altPrecip', 'AltPrecip', 'altprecip', 'Altprecip'],
            'reportPCP': ['reportPCP']
        }

        for key, names in candidates.items():
            for name in names:
                if name in df.columns:
                    precip_sources[key] = name
                    break

        self.logger.info(f" Site {siteID}: Computing dry exposure for: {list(precip_sources.keys())}")

        # ====================== Calculate total exposure once ======================
        df['total_exposure_cum'] = 0.0
        for col in exposure_cols:
            if col in df.columns:
                df['total_exposure_cum'] += df[col].fillna(0)

        df['exp_increment_sec'] = df['total_exposure_cum'].diff().fillna(df['total_exposure_cum'])
        df['exp_increment_hours'] = df['exp_increment_sec'] / 3600.0

        # ====================== Compute dry exposure for EACH source ======================
        for source_name, col_name in precip_sources.items():
            if col_name not in df.columns:
                continue

            prefix = source_name.lower().replace('_', '')

            df[f'is_dry_open_{prefix}'] = (df['exp_increment_hours'] > 0) & (df[col_name] == 0)
            df[f'dry_group_{prefix}'] = (df[f'is_dry_open_{prefix}'].astype(int).diff().ne(0)).cumsum()

            dry_periods = []
            max_dry_hours = 0.0
            undefined_flag = False

            for _, group in df[df[f'is_dry_open_{prefix}']].groupby(f'dry_group_{prefix}'):
                hours = len(group) * 0.25

                if hours > max_dry_hours:
                    max_dry_hours = hours

                start = group[time_col].min().strftime('%Y-%m-%d %H:%M')
                end = group[time_col].max().strftime('%Y-%m-%d %H:%M')
                
                if hours >= 0.5:
                    dry_periods.append(f"{start} to {end} ({hours:.1f} hrs)")

                if hours > 6.0:
                    undefined_flag = True

            total_dry = df['exp_increment_hours'][df[f'is_dry_open_{prefix}']].sum()

            # Store results
            df[f'dry_exposure_hours_{prefix}'] = total_dry
            df[f'undefined_dry_flag_{prefix}'] = undefined_flag
            df[f'undefined_periods_{prefix}'] = " | ".join(dry_periods) if dry_periods else ""
            df[f'max_continuous_dry_hours_{prefix}'] = max_dry_hours

            # === LOGGING FOR EVERY SOURCE ===
            self.logger.info(
                f" Site {siteID}: Total dry collector exposure ({source_name}): {total_dry:.2f} hours"
            )
            self.logger.info(
                f" Site {siteID}: Longest continuous dry ({source_name}): {max_dry_hours:.2f} hours"
            )
            
            if undefined_flag:
                self.logger.info(
                    f" Site {siteID}: UNDEFINED CONDITION DETECTED on {source_name} "
                    f"(continuous >6 hrs dry exposure)"
                )

        # Backward compatibility - main columns point to corrected_PCP (highest priority)
        if 'dry_exposure_hours_corrected_pcp' in df.columns:
            df['dry_exposure_hours'] = df['dry_exposure_hours_corrected_pcp']
            df['undefined_dry_flag'] = df['undefined_dry_flag_corrected_pcp']
            df['undefined_periods'] = df['undefined_periods_corrected_pcp']
            df['max_continuous_dry_hours'] = df['max_continuous_dry_hours_corrected_pcp']

        return df
    
    def detect_full_open_exposure(self, df: pd.DataFrame,
                                  siteID,
                                  time_col: str = 'LocalReportDateTime') -> pd.DataFrame:
        """
        Check if the collector/sampler was open for the ENTIRE period 
        using exposure columns (exp1, exp2, ...).
        Safe column handling: reuse if column exists, otherwise create.
        """
        if 'siteID' in df.columns:
            site_id = str(df['siteID'].iloc[0])
        else:
            site_id = "UNKNOWN"

        df = df.copy()
        df[time_col] = pd.to_datetime(df[time_col])
        df = df.sort_values(time_col).reset_index(drop=True)

        # ====================== Find exposure columns ======================
        exposure_cols = [col for col in df.columns 
                        if col.lower() in ['exp1', 'exp2', 'exp3'] 
                        or col.lower().startswith('exp') 
                        or 'exposure' in col.lower()]

        if not exposure_cols:
            self.logger.info(f" Site {site_id}: No collector exposure columns found.")
            
            # Safe column creation / reuse
            df = self._ensure_column(df, 'full_open_flag', False)
            df = self._ensure_column(df, 'full_open_hours', 0.0)
            df = self._ensure_column(df, 'total_exposure_hours', 0.0)
            df = self._ensure_column(df, 'exposure_coverage_pct', 0.0)
            return df

        self.logger.info(f" Site {siteID}: Using exposure columns: {exposure_cols}")

        # ====================== Calculate total exposure ======================
        df = self._ensure_column(df, 'total_exposure_cum', 0.0)
        
        for col in exposure_cols:
            if col in df.columns:
                df['total_exposure_cum'] += df[col].fillna(0)

        df = self._ensure_column(df, 'exp_increment_sec', 0.0)
        df['exp_increment_sec'] = df['total_exposure_cum'].diff().fillna(df['total_exposure_cum'])

        df = self._ensure_column(df, 'exp_increment_hours', 0.0)
        df['exp_increment_hours'] = df['exp_increment_sec'] / 3600.0

        # Total possible hours
        total_hours = len(df) * 0.25

        # ====================== Compute full open metrics ======================
        total_exposure_hours = df['exp_increment_hours'].sum()
        exposure_pct = (total_exposure_hours / total_hours * 100) if total_hours > 0 else 0.0

        full_open_flag = exposure_pct >= 99.0

        # ====================== Safe Column Assignment ======================
        df = self._ensure_column(df, 'full_open_flag', full_open_flag)
        df = self._ensure_column(df, 'full_open_hours', total_exposure_hours)
        df = self._ensure_column(df, 'total_exposure_hours', total_exposure_hours)
        df = self._ensure_column(df, 'exposure_coverage_pct', exposure_pct)

        # ====================== Logging ======================
        self.logger.info(f" Site {siteID}: Total exposure hours: {total_exposure_hours:.2f} / "
                        f"{total_hours:.2f} hours ({exposure_pct:.2f}%)")

        if full_open_flag:
            self.logger.info(f" Site {siteID}: COLLECTOR WAS OPEN FOR THE ENTIRE PERIOD "
                           f"(Full Open Detected)")
        else:
            self.logger.info(f" Site {siteID}: Collector was NOT open the entire period "
                           f"({exposure_pct:.2f}% coverage)")

        return df


    # ====================== HELPER METHOD ======================
    def _ensure_column(self, df: pd.DataFrame, col_name: str, default_value) -> pd.DataFrame:
        """Reuse column if it exists, otherwise create it with default value."""
        if col_name not in df.columns:
            df[col_name] = default_value
        else:
            df[col_name] = default_value  # update existing column
        return df

    def correct_precipitation(self, df: pd.DataFrame,
                            action: str = 'keep',
                            time_col: str = 'LocalReportDateTime',
                            precip_col: str = 'reportPCP',
                            alt_col: str = 'altPrecip',
                            alt2_col: str = 'altPrecip2',
                            final_col: str = 'corrected_PCP',
                            mask: pd.Series | None = None) -> pd.DataFrame:
        df = df.copy()
        df[time_col] = pd.to_datetime(df[time_col])
        df = df.sort_values(time_col).reset_index(drop=True)

        if mask is None:
            mask = pd.Series(True, index=df.index)
        else:
            mask = mask.reindex(df.index, fill_value=False)

        changed = mask.sum()
        working_precip = df[precip_col].copy()


        if action == 'zero':
            working_precip.loc[mask] = 0.0

        elif action == 'alt':
            if alt_col in df.columns:
                working_precip.loc[mask] = df.loc[mask, alt_col]
        elif action == 'alt2':
            if alt2_col in df.columns:
                working_precip.loc[mask] = df.loc[mask, alt2_col].fillna(0)
        elif action == 'none':
            working_precip.loc[mask] = np.nan

        df[final_col] = working_precip.fillna(0)

        self.logger.info(f" Applied '{action}' correction to {changed:,} records (SOP 4.2.11 / 4.3)")
        return df


    def print_correction_report(self, original_df: pd.DataFrame,
                                corrected_df: pd.DataFrame):
        if 'siteID' in original_df.columns:
            site_id = str(original_df['siteID'].iloc[0])
        else:
            site_id = "UNKNOWN"

        self.logger.info(f" NADP SOP 304 PRECIPITATION CORRECTION FINAL REPORT - {site_id}")

        total_records = len(corrected_df)
        orig_sum = original_df['reportPCP'].sum()
        final_sum = corrected_df['corrected_PCP'].sum()

        dry_hours = corrected_df.get('dry_exposure_hours', pd.Series([0.0])).iloc[0]
        undefined_flag = corrected_df.get('undefined_dry_flag', pd.Series([False])).iloc[0]
        undefined_periods = corrected_df.get('undefined_periods', pd.Series([""])).iloc[0]

        self.logger.info(f"(1) OVERVIEW")
        self.logger.info(f"   Total 15-minute records processed : {total_records:,}")
        self.logger.info(f"   Original Raw Precipitation        : {orig_sum:.3f} inches")
        self.logger.info(f"   Final Corrected Precipitation     : {final_sum:.3f} inches")
        self.logger.info(f"   Net change                        : {final_sum - orig_sum:+.3f} inches")
        self.logger.info(f"   Dry collector exposure (no precip): {dry_hours:.2f} hours")

        false_count = corrected_df.get('false_precip_flag', pd.Series([False]*len(corrected_df))).sum()
        noisy_count = corrected_df.get('noisy_flag', pd.Series([False]*len(corrected_df))).sum()
        self.logger.info(f" False Precip (flag 'f')        : {false_count:,} records")
        self.logger.info(f" Noisy Load Cell (flag 'n')     : {noisy_count:,} records")
        if undefined_flag:
            self.logger.info(" WARNING: UNDEFINED CONDITION DETECTED : >6 hours dry exposure -> entire file marked 'none'")
            if undefined_periods:
                self.logger.info(f" Time periods: {undefined_periods}")

        self.logger.info(f"(2) MACHINE SCREENING FLAGS DETECTED")
        self.logger.info(f"   False Precip (flag 'f')   : {false_count:,} records")
        self.logger.info(f"   Noisy Load Cell (flag 'n') : {noisy_count:,} records")

        self.logger.info(f"(3) CORRECTIONS APPLIED")
        zero_count = ((corrected_df['corrected_PCP'] == 0) & (original_df['reportPCP'] > 0)).sum()
        nan_count = corrected_df['corrected_PCP'].isna().sum()
        keep = ((corrected_df['corrected_PCP'] == original_df['reportPCP']) & (original_df['reportPCP'].notna())).sum()
        alt_count = 0
        if 'altPrecip' in corrected_df.columns and corrected_df['altPrecip'].notna().any():
            alt_count = ((corrected_df['reportPCP'] != corrected_df['altPrecip']) &
                         (corrected_df['reportPCP'] == original_df['reportPCP'])).sum()
        
        alt2_count = 0
        if 'altPrecip2' in corrected_df.columns and corrected_df['altPrecip2'].notna().any():
            alt2_count = ((corrected_df['reportPCP'] != corrected_df['altPrecip2']) &
                        (corrected_df['reportPCP'] == original_df['reportPCP'])).sum()
        

        self.logger.info(f"   * 'none'  -> marked missing/unusable : {nan_count:,} records")
        self.logger.info(f"   * 'zero'  -> set to zero precipitation : {zero_count:,} records")
        self.logger.info(f"   * 'altPrecip'  -> used altPrecip (OTT|ETI)     : {alt_count:,} records")
        self.logger.info(f"   * 'altPrecip2'  -> used altPrecip2 (ETI)    : {alt2_count:,} records")
        self.logger.info(f"   * keep    -> left as RawPrecip        : {keep:,} records")

        self.logger.info(f"(4) FINAL STATUS")
        self.logger.info(f"   Column 'corrected_PCP' contains the corrected values.")
        self.logger.info(f"   Columns 'reportPCP' and 'reportPrecip' are reference values only.")


    def run_autocorrect(self, df_in, siteID, labno, local_start, local_end, start_dt, end_dt,
                       expected_records, actual_records, valid_records, valid_records_reportPCP) -> pd.DataFrame:
        """
        New parameter: pct_record (float between 0 and 1) = percentage of actual records relative to expected records
        
        """

        pct_record = (actual_records / expected_records) if actual_records > 0 else 0.0
        pct_good = (valid_records / actual_records) if actual_records > 0 else 0.0
        pct_good_reportPCP = (valid_records_reportPCP / actual_records) if actual_records > 0 else 0.0
        start_dt_UTC = pd.to_datetime(df_in['LocalReportDateTime'].min(), utc=True)
        end_dt_UTC = pd.to_datetime(df_in['LocalReportDateTime'].max(), utc=True)
     
        self.logger.info("="*60)
        self.logger.info(f" Processing siteID: {siteID}, LABNO: {labno} | "
                        f"Expected: {expected_records} | Actual: {actual_records} | valid_records_reportPCP:{valid_records_reportPCP} |valid reportPrecip: {valid_records} ")
        self.logger.info(f" pct_record: {pct_record:.1%} | pct_good_reportPCP: {pct_good_reportPCP:.1%} |pct_good: {pct_good:.1%} ")
        self.logger.info(f"Start local: {local_start} | End local: {local_end}")
        self.logger.info(f"Start local: {local_start} | End local: {local_end}")
        self.logger.info(f"Start UTC: {start_dt} | End UTC: {end_dt}")
        self.logger.info(f"Start UTC match 15min from actual record from database: {start_dt_UTC} | End UTC match 15min from actual record in database: {end_dt_UTC}")
        if pct_record == 1.0:
            self.logger.info(" 100% of expected records present. Proceeding with autocorrection | equipment functionality.")
        if pct_record != 1.0:
            self.logger.info("The equipment may not be functioning correctly.")

        # === 1. Handle input type ===
        if isinstance(df_in, (str, os.PathLike)):
            self.logger.info(f" Loading data from file: {df_in}")
            df_original = pd.read_csv(df_in, parse_dates=['LocalReportDateTime'])
        elif isinstance(df_in, pd.DataFrame):
            self.logger.info(" Using provided DataFrame directly")
            df_original = df_in.copy()
        else:
            raise TypeError(f"df_in must be a file path or pandas DataFrame, got {type(df_in)}")

  
        if pct_record <= 0.85:
            self.logger.warning(f" WARNING {siteID}: pct_record ({pct_record:.1%}) <= 85% ; skipping correction.")
            cols = [
                "LocalReportDateTime", "siteID", "reportPCP", "reportPrecip", 
                "corrected_PCP", "coll1cycles", "exp1", "ActDepth", 
                "ActDepthRA", "altPrecip", "altPrecip2", "minVolt", 
                "ActTemp", "opdCounts", "CumReportPCP", "CumReportPrecip", 
                "Cumcoll1cycles", "Cumexp1", "delta_bucket", "false_precip_flag", 
                "delta", "sign_change", "noisy_flag", "total_exposure_cum", 
                "exp_increment_sec", "exp_increment_hours", "is_dry_open", 
                "dry_group", "dry_exposure_hours", "undefined_dry_flag", 
                "undefined_periods", "max_continuous_dry_hours"
            ]

            # Initialize the empty DataFrame
            df = pd.DataFrame(columns=cols)
            return df
        if pct_good <= 0.90:
            self.logger.warning(f" WARNING {siteID}: pct_good ({pct_good:.1%}) <= 90% ; skipping correction.")
            cols = [
                "LocalReportDateTime", "siteID", "reportPCP",  "reportPrecip", 
                "corrected_PCP", "coll1cycles", "exp1", "ActDepth", 
                "ActDepthRA", "altPrecip", "altPrecip2", "minVolt", 
                "ActTemp", "opdCounts", "CumReportPCP", "CumReportPrecip", 
                "Cumcoll1cycles", "Cumexp1", "delta_bucket", "false_precip_flag", 
                "delta", "sign_change", "noisy_flag", "total_exposure_cum", 
                "exp_increment_sec", "exp_increment_hours", "is_dry_open", 
                "dry_group", "dry_exposure_hours", "undefined_dry_flag", 
                "undefined_periods", "max_continuous_dry_hours"
            ]

            # Initialize the empty DataFrame
            df = pd.DataFrame(columns=cols)
            return df

        # Check consecutive nulls in reportPCP
        df_temp = df_original.copy()
        null_series = df_temp['reportPCP'].isna()
        max_consec_null = (null_series.astype(int)
                           .groupby((null_series != null_series.shift()).cumsum())
                           .sum().max())
       
        if max_consec_null > 4:
            self.logger.warning(f" WARNING {siteID}: Found {max_consec_null} consecutive nulls in reportPCP "
                              f"(max allowed = 4) ; skipping correction.")
            cols = [
                "LocalReportDateTime", "siteID", "reportPCP", "reportPrecip", 
                "corrected_PCP", "coll1cycles", "exp1", "ActDepth", 
                "ActDepthRA", "altPrecip", "altPrecip2", "minVolt", 
                "ActTemp", "opdCounts", "CumReportPCP", "CumReportPrecip", 
                "Cumcoll1cycles", "Cumexp1", "delta_bucket", "false_precip_flag", 
                "delta", "sign_change", "noisy_flag", "total_exposure_cum", 
                "exp_increment_sec", "exp_increment_hours", "is_dry_open", 
                "dry_group", "dry_exposure_hours", "undefined_dry_flag", 
                "undefined_periods", "max_continuous_dry_hours"
            ]

            # Initialize the empty DataFrame
            df = pd.DataFrame(columns=cols)
            return df

        self.logger.info(f" Passed {siteID}: pct_record = {pct_record:.1%}, max consecutive nulls = {max_consec_null} ; proceeding")

        df = df_original.copy()

        # === 4. Ensure reportPrecip exists (reference only) ===
        if 'reportPrecip' not in df.columns:
            df['reportPrecip'] = df['reportPCP'].fillna(0)
        else:
            df['reportPrecip'] = df_original['reportPrecip'].copy()

        # === 5. Fill missing timestamps if actual < expected ===
        # (your commented gap-filling code can stay here - not changed)

        # === 6. Check 15-minute interval consistency ===
        df = df.sort_values('LocalReportDateTime').reset_index(drop=True)
        time_diff = df['LocalReportDateTime'].diff().dt.total_seconds() / 60
        irregular_mask = (time_diff != 15) & time_diff.notna()
        irregular_count = irregular_mask.sum()
        if irregular_count > 0:
            irregular_indices = irregular_mask[irregular_mask].index
            irregular_df = pd.DataFrame({
                'row_index': irregular_indices,
                'prev_time': df.loc[irregular_indices-1, 'LocalReportDateTime'].values,
                'curr_time': df.loc[irregular_indices, 'LocalReportDateTime'].values,
                'diff_minutes': time_diff[irregular_indices].round(2),
                'diff_seconds': (time_diff[irregular_indices] * 60).round(1)
            })
            
            self.logger.warning(
                f"WARNING {siteID}: Found {irregular_count} irregular 15-min intervals"
            )
            self.logger.warning(f"\n{irregular_df.to_string(index=False)}")

        # === 7. Run detection for noise and false precip ===
        df = self.detect_false_precip(df, siteID)
        df = self.detect_noisy_load_cell(df, siteID)
         

    

        # === 8. Apply corrections with NOISE SEVERITY LOGIC ===
        false_count = df['false_precip_flag'].sum()
        noisy_count = df['noisy_flag'].sum()
        total_records = len(df)
        noisy_ratio = noisy_count / total_records if total_records > 0 else 0.0

        self.logger.info(f"Site {siteID}: Noisy ratio = {noisy_ratio:.1%} "
                         f"({noisy_count:,}/{total_records:,} records)")

        # Smart Alt column selection (AltPrecip2 preferred) # key case sensitivity check for altPrecip2 vs AltPrecip2
        use_alt2 = False
        if 'altPrecip2' in df.columns and df['altPrecip2'].notna().any() and (df['altPrecip2'] != 0).any():
            use_alt2 = True
        elif 'AltPrecip2' in df.columns and df['AltPrecip2'].notna().any() and (df['AltPrecip2'] != 0).any():
            use_alt2 = True

        if noisy_ratio >= 0.50:
            # SUPER NOISE (>= 50%)
            self.logger.info(f" WARNING {siteID}: SUPER NOISE DETECTED ({noisy_ratio:.2%}) -> marking entire file as 'none'")
            df = self.correct_precipitation(df, action='none')
        elif false_count > 0 or noisy_ratio > 0.20:
            # MILD NOISE or false precip present
            self.logger.info(f" Warning {siteID}: Mild noise / false precip detected -> targeted corrections")
            df = self.correct_precipitation(df, action='zero', mask=df['false_precip_flag'])
            if use_alt2:
                self.logger.info(f" ETI NOAH available -> using altPrecip2 for correction records")
                df = self.correct_precipitation(df, action='alt2', mask=df['noisy_flag'])
            elif 'altPrecip' in df.columns or 'AltPrecip' in df.columns:
                self.logger.info(f" Only altPrecip available -> using altPrecip for correction records")
                df = self.correct_precipitation(df, action='alt', mask=df['noisy_flag'])
        else:
            # CLEAN (<= 20%)
            self.logger.info(f" Passed {siteID}: Clean data ({noisy_ratio:.2%} noisy) -> using best Alt column")
            df = self.correct_precipitation(df, action='zero', mask=df['false_precip_flag'])
            if use_alt2:
                self.logger.info(f" ETI NOAH available -> using altPrecip2 for correction records")
                df = self.correct_precipitation(df, action='alt2')
            elif 'altPrecip' in df.columns or 'AltPrecip' in df.columns:
                self.logger.info(f" Only altPrecip available -> using altPrecip for correction records")
                df = self.correct_precipitation(df, action='alt')
            else:
                self.logger.info(f" No AltPrecip/AltPrecip2 found -> keeping raw data")

        # === . Run detection for dry exposure===
        df = self.detect_dry_exposure(df, siteID)
        df = self.detect_full_open_exposure(df, siteID)  




        

        # === 9. Force exact column order ===
        desired_order = ['LocalReportDateTime', 'siteID', 'reportPCP', 'reportPrecip', 'corrected_PCP']
        remaining_cols = [col for col in df.columns if col not in desired_order]
        df = df[desired_order + remaining_cols]

        # === 10. Final report ===
        self.print_correction_report(df_original, df)

        return df