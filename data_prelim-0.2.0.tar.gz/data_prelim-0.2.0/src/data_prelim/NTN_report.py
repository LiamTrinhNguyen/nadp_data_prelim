__author__ = 'Liam TrinhNguyen'
__email__ =  'LiamTrinhNguyen@gmail.com or TrinhNguyen@wisc.edu'
__version__ = 'preLim v0.2.0'

import os, sys, psutil, logging, numpy as np, pandas as pd
from pathlib import Path
from logging.handlers import RotatingFileHandler
from datetime import datetime
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import FilePath, DirectoryPath

from .NTN_info import NTNInfoSettings, NTNInfo

class PipelineSettings(BaseSettings):
    output_dir: DirectoryPath 
    threshold: float = 0.05
    threshold_extreme: float = 0.30
    model_config = SettingsConfigDict(env_file=".env", env_prefix="WSLH_", extra="ignore")

class NTNReviewPipeline:
    def __init__(self, settings: PipelineSettings):
        self.settings = settings
        self.output_root = self.settings.output_dir.resolve()
        
        self._log_dir = self.output_root / "logs"
        self._data_dir = self.output_root / "processed_data"
        
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = self._setup_logger()
        self.logger.info(f"Pipeline Report Initialized.")

    def __perform_vectorized_math(self, pre_mask: pd.DataFrame):
        """
        Flagging rows where totp != ppt 
        and where the variance between [PPT, totp] and sampleDepth > 5%.
        """
 
        ppt = pre_mask['PPT'].values.astype('float64').round(5)  
        totp = pre_mask['totp'].values.astype('float64').round(5)
        sample_depth = pre_mask['sampleDepth'].values.astype('float64').round(5)
        not_equal_mask = (np.abs(totp - ppt) / np.where(ppt == 0, np.inf, ppt)) >= self.settings.threshold
        safe_depth = np.where(sample_depth == 0, np.inf, sample_depth)
        
        diff_ppt = np.abs(ppt - sample_depth) / safe_depth
        diff_totp = np.abs(totp - sample_depth) / safe_depth
        variance_mask = (diff_ppt > self.settings.threshold) | (diff_totp > self.settings.threshold)
        
        variance_mask_1 = (diff_ppt > self.settings.threshold_extreme) | (diff_totp > self.settings.threshold_extreme)


        return  (variance_mask & (ppt != totp) & (ppt < sample_depth) & (sample_depth >= 0.09) & (ppt >= 0.09)) | (variance_mask_1 & (ppt == totp) & (ppt < sample_depth) & (sample_depth >= 0.09) & (ppt >= 0.09))
    
    def __perform_vectorized_math_goodSample(self, pre_mask: pd.DataFrame):
        """
        Rows where totp == ppt 
        and where the variance between [PPT, totp] and sampleDepth <= 5%.
        """
 
        ppt = pre_mask['PPT'].values.astype('float64').round(5)  
        totp = pre_mask['totp'].values.astype('float64').round(5)
        sample_depth = pre_mask['sampleDepth'].values.astype('float64').round(5)
        equal_mask = (totp == ppt)
        safe_depth = np.where(sample_depth == 0, np.inf, sample_depth)
        
        diff_ppt = np.abs(ppt - sample_depth) / safe_depth
        diff_totp = np.abs(totp - sample_depth) / safe_depth
        variance_mask = (diff_ppt <= self.settings.threshold) & (diff_totp <= self.settings.threshold)
        
        return  variance_mask & equal_mask

    def _setup_logger(self) -> logging.Logger:
        logger_name = f"WSLH_NTN.{self.__class__.__name__}"
        logger = logging.getLogger(logger_name)
        logger.propagate = False 

        if logger.hasHandlers(): 
            return logger
            
        logger.setLevel(logging.INFO)
        log_path = str(self._log_dir / f"pipeline_{datetime.now().strftime('%Y-%m-%d')}.log")
        
        formatter = logging.Formatter('%(asctime)s - [%(name)s] - %(levelname)s: %(message)s')
        
        fh = RotatingFileHandler(log_path, maxBytes=5*1024*1024, backupCount=3)
        fh.setFormatter(formatter)
        logger.addHandler(fh)
        
        ch = logging.StreamHandler()
        ch.setFormatter(formatter)
        logger.addHandler(ch)
        return logger
        

    @staticmethod
    def _prepare_for_excel(df: pd.DataFrame) -> pd.DataFrame:
        temp_df = df.copy()
        dt_cols = temp_df.select_dtypes(include=['datetime64[ns, UTC]', 'datetimetz']).columns
        for col in dt_cols:
            temp_df[col] = temp_df[col].dt.tz_localize(None)
        return temp_df

    def _get_reference_df(self) -> pd.DataFrame:
        not_a = ["Correction","Update E-guage","Unusable eguage/ Missing Flagged", "E-guage data good", "E-guage data not complete/ Missing Flagged", "E-guage data not complete/ Still usable","Incorrect data of precipReviewed samples"]
        no_ppt = ["Reload E-guage/ Unusable/ Missing Flag","Correction","Update E-guage","Reload e-Guage co-located site","Reload/ E-guage data good", "Cannot reload eguage/ Missing Flagged", "E-guage data not complete/ Missing Flagged", "E-guage data complete/ usable","Incorrect data of precipReviewed samples"]
        TroubleFlag = ["Correction","Update E-guage","Reload/ E-guage data good", "Cannot reload eguage/ Missing Flagged", "E-guage data not complete/ Missing Flagged", "E-guage data complete/ usable","Incorrect data of precipReviewed samples"]
        REC_Late = ["REC late","Reload/ E-guage data good","Update Code","Correction","Update E-guage","Sample was extended due to Federal Government Shutdown", "Long sampling period", "Very long sampling period - COVID","Incorrect data of precipReviewed samples"]
        DFDK = ["Invalid DF/DK","DF/DK sample","Update Code","Correction","Update E-guage","Update SP with Q code","Incorrect data of precipReviewed samples"]
        Possible_Reload = ["Correction","Update E-guage","Reload/ E-guage data good", "Cannot reload eguage/ Missing Flagged", "E-guage data not complete/ Missing Flagged", "E-guage data not complete/ Still usable", "Reload E-guage/ Unusable/ Missing Flag", "Incorrect data of precipReviewed samples"] 
        W_Zero_PPT_TOTP = ["Invalid W/WD/WI sample","Invalid DF/DK","Correction","Update E-guage","E-guage data good", "E-guage data not complete/ Missing Flagged","Cannot use eguage data/ Missing Flagged", "Reload/ E-guage data good", "Incorrect data of precipReviewed samples"]
        D_NonZero_PPT_TOTP = ["Invalid D sample","Invalid DF/DK","Correction","Update E-guage","E-guage data good", "Cannot use eguage data/ Missing Flagged","Reload/ E-guage data good","Incorrect data of precipReviewed samples"]
        PPT_TOTP_sampleDepth_inconsistent = ["Correction","Update E-guage","E-guage data good", "Cannot use eguage data/ Missing Flagged","Incorrect data of precipReviewed samples","Incorrect data of precipReviewed samples"]
        Bad_Record_precent = ["Correction","Update E-guage","Unusable eguage/ Missing Flagged", "E-guage data good", "E-guage data not complete/ Missing Flagged","Incorrect data of precipReviewed samples"]
        excess_totp = ["Correction","Update E-guage","E-guage data good", "Cannot use eguage data/ Missing Flagged","Incorrect data of precipReviewed samples"]
        dry_exp = ["Undefined sample","Correction","Update E-guage","E-guage data good", "Cannot use eguage data/ Missing Flagged","Incorrect data of precipReviewed samples"]
        full_open = ["Bulk sample","Correction","Update E-guage","E-guage data good", "Cannot use eguage data/ Missing Flagged","Incorrect data of precipReviewed samples"]
        
        # Map column names to their respective lists
        data_dict = {
            'tab_MissingPPT': no_ppt,
            'tab_Possible_Reload': Possible_Reload,
            'tab_W_Zero_PPT_TOTP': W_Zero_PPT_TOTP,
            'tab_D_NonZero_PPT_TOTP': D_NonZero_PPT_TOTP,
            'tab_TroubleFlag': TroubleFlag,
            'tab_PPT_TOTP_sampleDepth_inconsistent': PPT_TOTP_sampleDepth_inconsistent,
            'tab_Not_a_has_ppt': not_a,
            'tab_REC_Late': REC_Late,
            'tab_DFDK': DFDK,
            'tab_Bad_Record_precent': Bad_Record_precent,
            'tab_excess_totp': excess_totp,
            'tab_dryExp': dry_exp,
            'tab_full_open': full_open
        }
        
        # Convert lists to Series; pandas automatically aligns and pads with NaN
        df = pd.DataFrame({k: pd.Series(v) for k, v in data_dict.items()})
        
        # Optional: Replace NaN with None if your downstream logic strictly expects Python None types
        df = df.where(pd.notnull(df), None)
        
        return df

    @property
    def current_mem_usage(self) -> str:
        return f"{psutil.Process(os.getpid()).memory_info().rss / 1024**2:.1f}MB"

    def load_and_optimize(self, df: pd.DataFrame) -> pd.DataFrame:
        
        floats = df.select_dtypes(include=['float64']).columns
        df[floats] = df[floats].astype('float32')
        return df

    def sync_human_labels(self, excel_path: Path):
        """
        Ingests human edits from Excel and updates the Parquet Feature Store.
        Essential for ML Ground Truth.
        """
        self.logger.info(f"Syncing Human Labels from: {excel_path.name}")
        parquet_path = self._data_dir / "review_master.parquet"
        
        if not parquet_path.exists():
            self.logger.error("Sync failed: review_master.parquet does not exist.")
            return

        # Load human reviewed data (Not_a_has_ppt is the primary edit target)
        reviewed_df = pd.read_excel(excel_path, sheet_name="Not_a_has_ppt")
        master_df = pd.read_parquet(parquet_path)

        # Merge update using SITE and sampleStart as the composite key
        master_df.set_index(['SITE', 'sampleStart'], inplace=True)
        reviewed_df.set_index(['SITE', 'sampleStart'], inplace=True)
        
        # Update only the Action column
        master_df.update(reviewed_df[['Action']])
        
        master_df.reset_index().to_parquet(parquet_path, index=False)
        self.logger.info("Parquet Master updated with human labels.")

    def process_review(self, df: pd.DataFrame, sampleID_start, sampleID_end):
        try:
            
            self.logger.info(f"---- [PHASE 5]: finalizing report to review  ({sampleID_start} to {sampleID_end})")

            #convert data types and create new columns for review logic:
            min_labno = df['LABNO'].min()
            max_labno = df['LABNO'].max()
            df['sampleStart'] = pd.to_datetime(df['sampleStart'], utc=True)
            df['sampleEnd'] = pd.to_datetime(df['sampleEnd'], utc=True)
            df['RECDATE'] = pd.to_datetime(df['RECDATE'], utc=True)
            df['totp'] = df['totp'].astype('float64').round(5)
            df['PPT'] = df['PPT'].astype('float64').round(5)
            df['sampVol'] = df['sampVol'].astype('float64').round(5)
            df['sampleDepth'] = df['sampleDepth'].astype('float64').round(5)
            df['Start_End_diff'] = df['Start_End_diff'].astype('float64').round(5)
            df['SampleEnd_RECDATE'] = df['SampleEnd_RECDATE'].astype('float64').round(5)
            df['percent_record'] = df['percent_record'].astype('float64').round(5)
            df['noisy_ratio_raw_pct_record'] = df['noisy_ratio_raw_pct_record'].astype('float64').round(5)
            df['dryExp_correctedPCP'] = df['dryExp_correctedPCP'].astype('float64').round(5)
            df['dryExpo_reportprecip'] = df['dryExpo_reportprecip'].astype('float64').round(5)

            # missing PPT data:
            null_PPT = df[df['PPT'].isna()].copy()
            null_PPT['review_category'] = 'Missing_PPT_Data'
            null_PPT.insert(0, 'Action', '')
            null_PPT.loc[null_PPT['SITE'].str.match(r'^(\d{2})([a-zA-Z]{2})$'), 'Action'] = 'Reload e-Guage co-located site'

            

            # possible reloads: samples with ppt data where ppt = 0 and totp > 0, or ppt > 0 and totp > 0 
            # but ppt and totp are inconsistent with sampleDepth (variance > 5%) but 
            # ppt and sampleDepth are consistent (variance <= 5%) - indicating potential reload 
            # with accurate ppt but incorrect sampleDepth or sampVol leading to inconsistency. Also ensuring 
            # that sampVol and sampleDepth are not providing valid data (either missing or zero) to avoid false flags.
            df_possible_reload = df[
                ((~df['PPT'].isna()) & 
                (~(df['sampVol'].isna() | (df['sampVol'] > 0))) &
                (~(df['sampleDepth'].isna() | (df['sampleDepth'] > 0))) & 
                (df['PPT'] == 0.0) &
                (~df['totp'].isna()) & (df['totp'] > 0)) |

                ((~df['PPT'].isna()) & (df['PPT'] > 0.0) &
                (~(df['sampVol'].isna() & (df['sampVol'] > 0))) &
                (~(df['sampleDepth'].isna() & (df['sampleDepth'] > 0))) & 
                (~df['totp'].isna()) & (df['totp'] > 0) &
                (np.abs(df['totp'] - df['PPT']) / df['PPT'] >= self.settings.threshold_extreme) &
                (np.abs(df['PPT'] - df['sampleDepth']) / df['sampleDepth'] >= self.settings.threshold)|
                
                (~df['PPT'].isna()) &
                (~df['sampVol'].isna()) & (df['sampVol'] >= 0) &
                (~df['totp'].isna()) & (df['totp'] < 0) &
                (df['percent_record'] > 85))

                # #TODO:testing new condition
                # ((~df['PPT'].isna()) & (df['PPT'] > 0.0) &
                # (~(df['sampVol'].isna() & (df['sampVol'] > 0))) &
                # (~(df['sampleDepth'].isna() & (df['sampleDepth'] > 0))) & 
                # (~df['totp'].isna()) & (df['totp'] > 0) &
                # (np.abs(df['totp'] - df['PPT']) / df['PPT'] >= self.settings.threshold) &
                # (np.abs(df['totp'] - df['sampleDepth']) / df['sampleDepth'] >= self.settings.threshold))
                
            ].copy()
            df_possible_reload['review_category'] = 'Possible_Reload'
            df_possible_reload.insert(0, 'Action', '')

            # sample with ppt data for review with ppt = totp = sampleDepth and percent_record > 97% as good sample:
            pre_mask1 = df[df['PPT'].notna()].copy()
            good_sample = self.__perform_vectorized_math_goodSample(pre_mask1)
            df_good_sample = pre_mask1[good_sample & (pre_mask1['percent_record'] > 97)].copy()
            df_good_sample['review_category'] = 'Good_Sample'

            # sample with ppt data for review with ppt = totp = sampleDepth and percent_record > 97% as good sample:
            df['percent_record'] = pd.to_numeric(df['percent_record'], errors='coerce')
            df['noisy_ratio_raw_pct_record'] = (
                                                df['noisy_ratio_raw_pct_record']
                                                .fillna(np.nan)                    # ensure real NaNs
                                                .astype(str)                       # convert to string
                                                .str.replace('%', '', regex=True)  # remove percentage sign
                                                .str.replace(r'[^\d.-]', '', regex=True)  # remove any non-numeric characters
                                                .str.strip()
                                                .replace('', np.nan)               # empty strings -> NaN
                                                .pipe(pd.to_numeric, errors='coerce')
                                            )
            ppt_not_none = df['PPT'].notna()
            low_coverage = df['percent_record'] <= 85
            high_noise = df['noisy_ratio_raw_pct_record'] >= 50
            Bad_Record_precent = df[
                ppt_not_none & (low_coverage | high_noise)
            ].copy()
            Bad_Record_precent['review_category'] = 'Bad_Record_precent'
            Bad_Record_precent.insert(0, 'Action', '')


            # --- df_W_Zero_ppt_totp ---
            df_w = df[(~df['PPT'].isna()) & (df['LABC'].isin(['W', 'WI', 'WD']))].copy() 
            df_W_Zero_ppt_totp = df_w[df_w['totp'] == 0.0].copy()
            df_W_Zero_ppt_totp['review_category'] = 'W_Zero_PPT_TOTP'
            df_W_Zero_ppt_totp.insert(0, 'Action', '')

            # --- df_D_nonZero_ppt_totp ---
            df_d = df[(~df['PPT'].isna()) & (df['LABC'].isin(['D', 'DF', 'DK']))].copy()
            df_D_nonZero_ppt_totp = df_d[ 
                                        (df_d['PPT'] > 0.0) | (df_d['totp'] > 0.0) 
                                        ].copy()
            df_D_nonZero_ppt_totp['review_category'] = 'D_NonZero_PPT_TOTP'
            df_D_nonZero_ppt_totp.insert(0, 'Action', '')
            

            #`--- df_trouble_flag ---`
            excluded_indices_df_trouble_flag = (
                                df_possible_reload.index.tolist() + 
                                df_W_Zero_ppt_totp.index.tolist() + 
                                df_D_nonZero_ppt_totp.index.tolist() + 
                                Bad_Record_precent.index.tolist()
                                )
            df_trouble_flag = df[(df['TroubleFlag'] == True) & (~df.index.isin(excluded_indices_df_trouble_flag))].copy()
            df_trouble_flag['review_category'] = 'Trouble_Flagged'
            df_trouble_flag.insert(0, 'Action', '')
            df_trouble_flag.loc[(df_trouble_flag['SP'] != 'X') | (df_trouble_flag['TroubleFlag'] != False), 'Action'] = ''

            #`--- df_PPT_TOTP_sampleDepth_inconsistent ---`
            excluded_indices_PPT_TOTP_sampleDepth_inconsistent = (
                null_PPT.index.tolist() +
                df_possible_reload.index.tolist() + 
                Bad_Record_precent.index.tolist() +
                df_W_Zero_ppt_totp.index.tolist() + 
                df_D_nonZero_ppt_totp.index.tolist() + 
                df_trouble_flag.index.tolist()+
                df_good_sample.index.tolist()
            )
            mask = self.__perform_vectorized_math(pre_mask1)
            PPT_TOTP_sampleDepth_inconsistent = pre_mask1[mask & 
                                                          

                                                          (~pre_mask1.index.isin(excluded_indices_PPT_TOTP_sampleDepth_inconsistent))].copy()
            PPT_TOTP_sampleDepth_inconsistent['review_category'] = 'PPT_TOTP_sampleDepth_inconsistent'
            PPT_TOTP_sampleDepth_inconsistent.insert(0, 'Action', '')


            # Not a:
            excluded_indices = (
                                null_PPT.index.tolist() +
                                df_possible_reload.index.tolist() + 
                                Bad_Record_precent.index.tolist() +
                                df_W_Zero_ppt_totp.index.tolist() + 
                                df_D_nonZero_ppt_totp.index.tolist() + 
                                df_trouble_flag.index.tolist()+
                                df_good_sample.index.tolist()+
                                PPT_TOTP_sampleDepth_inconsistent.index.tolist()
                                )
            pre_mask2= pre_mask1[(pre_mask1['PPT'] != pre_mask1['totp']) &
                                (pre_mask1['PPT']>=0) & (pre_mask1['totp']>=0) &
                                ((np.abs(pre_mask1['PPT'] - pre_mask1['sampleDepth']) / np.where(pre_mask1['PPT'] == 0, np.inf, pre_mask1['PPT']) > self.settings.threshold) |
                                (np.abs(pre_mask1['totp'] - pre_mask1['sampleDepth']) / np.where(pre_mask1['totp'] == 0, np.inf, pre_mask1['totp']) > self.settings.threshold))
                                ].copy()
            df_not_a_has_ppt = pre_mask2[(pre_mask2['precipUsable'] != 'A') & 
                                         (~pre_mask2.index.isin(excluded_indices)) ].copy()
                                         
            df_not_a_has_ppt['review_category'] = 'Manual_Review_Required'
            df_not_a_has_ppt.insert(0, 'Action', '')


            # Excess totp: totp > 6 micrometers which is highly unlikely and may indicate data issues or outliers that require review.
            df_excess_totp = df[(~df['totp'].isna()) & (df['totp'] > 6)].copy()
            df_excess_totp['review_category'] = 'Excess_totp'
            df_excess_totp.insert(0, 'Action', '')


            # DFDK samples: LABC of D, DF, or DK with ppt data that may have specific known issues or require targeted review based on historical patterns or domain knowledge.
            df_DFDK = df[(df['LABC'] == 'DF') | (df['LABC'] == 'DK')].copy()            
            df_DFDK['review_category'] = 'DFDK_sample'
            df_DFDK.insert(0, 'Action', '')
            df_DFDK.loc[df_DFDK['SP'] != 'Q', 'Action'] = 'Update SP with Q code'

            # Start_End_diff greater than 8 days: Samples where the difference between sampleEnd and sampleStart is greater than 8 days, which may indicate potential issues with the sampling process, data entry errors, or unusual circumstances that warrant further investigation.
            df_StartEnd_Flag = df[df['PPT'].notna() & (df['Start_End_diff'] >= 8)].copy()
            df_StartEnd_Flag = df_StartEnd_Flag.sort_values('Start_End_diff', ascending=False)
            df_StartEnd_Flag['review_category'] = 'Start_End_diff_Greater_8'
            df_StartEnd_Flag.insert(0, 'Action', '')
            df_StartEnd_Flag.loc[(df_StartEnd_Flag['QR'] != 'C') | (~df_StartEnd_Flag['notes'].str.contains('[e]', regex=True, na=False)), 'Action'] = 'incorrect QR/ No e in notes'
            
            
            # ENDREC_Late: Samples where the SampleEnd_RECDATE is 16 or more days after the sampleEnd date, which may indicate delays in processing, data entry errors, or other issues that require review. This flag is applied only to samples with ppt data and excludes certain LABC codes (D, DF, DK) that may have different review criteria or known issues.
            df_ENDREC_FLAG = df[df['PPT'].notna() & (df['SampleEnd_RECDATE'] >= 16) & (~df['LABC'].isin(['D', 'DF', 'DK']))].copy()
            df_ENDREC_FLAG = df_ENDREC_FLAG.sort_values('SampleEnd_RECDATE', ascending=False)
            df_ENDREC_FLAG.insert(0, 'Action', '')
            df_ENDREC_FLAG.loc[(df_ENDREC_FLAG['SampleEnd_RECDATE'] <= 60) & (~df_ENDREC_FLAG['notes'].str.contains('[h]', regex=True, na=False)), 'Action'] = ' No h in notes'
               # combine notes of other condition:
            conditions_ENDREC = [
                df_ENDREC_FLAG['notes'].str.contains('[bceflnpuv]', regex=True, na=False), 
                df_ENDREC_FLAG['notes'].str.contains('[adhimqz]', regex=True, na=False)    
            ]
            expected_qrs = ['C', 'B']
            df_ENDREC_FLAG['Expected_QR'] = np.select(conditions_ENDREC, expected_qrs, default=None)
            is_incorrect = (df_ENDREC_FLAG['Expected_QR'].notna()) & (df_ENDREC_FLAG['QR'] != df_ENDREC_FLAG['Expected_QR'])
            df_ENDREC_FLAG.loc[is_incorrect, 'Action'] += 'Incorrect QR'
            df_ENDREC_FLAG = df_ENDREC_FLAG.drop(columns=['Expected_QR'])
       

            # Hold ScreenStat: Samples that have a ScreenStat of "Hold" but do not meet any of the other specific review criteria, indicating that they may require manual review to determine the appropriate action or categorization. This category serves as a catch-all for samples that are flagged for holding but do not fall into the more defined categories based on the other flags and criteria.
            excluded_indices_hold = (
                                null_PPT.index.tolist() +
                                df_possible_reload.index.tolist() + 
                                Bad_Record_precent.index.tolist() +
                                df_W_Zero_ppt_totp.index.tolist() + 
                                df_D_nonZero_ppt_totp.index.tolist() + 
                                df_trouble_flag.index.tolist()+
                                PPT_TOTP_sampleDepth_inconsistent.index.tolist()+
                                df_StartEnd_Flag.index.tolist()+
                                df_ENDREC_FLAG.index.tolist()+
                                df_DFDK.index.tolist()+
                                df_excess_totp.index.tolist()+
                                df_not_a_has_ppt.index.tolist()
                                )
            df_hold = df[~df.index.isin(excluded_indices_hold) & (df['ScreenStat'] == 'Hold')].copy()
            df_hold['review_category'] = 'Hold_ScreenStat'
            df_hold.insert(0, 'Action', '')


            df_accepted = df[~df.index.isin(
                null_PPT.index.tolist() +
                df_possible_reload.index.tolist() +
                Bad_Record_precent.index.tolist() +
                df_W_Zero_ppt_totp.index.tolist() +
                df_D_nonZero_ppt_totp.index.tolist() +
                df_trouble_flag.index.tolist() + 
                PPT_TOTP_sampleDepth_inconsistent.index.tolist() +
                df_not_a_has_ppt.index.tolist() +
                df_StartEnd_Flag.index.tolist() +
                df_ENDREC_FLAG.index.tolist() +
                df_DFDK.index.tolist() +
                df_excess_totp.index.tolist() +
                df_hold.index.tolist()+
                df_good_sample.index.tolist()
            )].copy()
            df_accepted['review_category'] = 'Accepted'
            df_accepted.insert(0, 'Action', '')

            # --- df_dry_exp ---
            df_dryExp_mask = df[(~df['dryExp_correctedPCP'].isna()) | ~df['dryExpo_reportprecip'].isna()].copy() 
            df_dryExp = df_dryExp_mask[(df_dryExp_mask['dryExp_correctedPCP'] > 6.0) | (df_dryExp_mask['dryExpo_reportprecip'] > 6.0)].copy()
            df_dryExp['review_category'] = 'dry_exp_U'
            df_dryExp.insert(0, 'Action', '')

            # --- df_dfull_open ---
            df_full_open = df[(df['full_open_flag'] == True)].copy() 
            df_full_open['review_category'] = 'full_open_B'
            df_full_open.insert(0, 'Action', '')

            


            # combine notes of other condition:
            conditions_ACCEPTED = [
                df_accepted['notes'].str.contains('[bceflnpuv]', regex=True, na=False), 
                df_accepted['notes'].str.contains('[adhimqz]', regex=True, na=False)    
            ]
            expected_qrs = ['C', 'B']
            df_accepted['Expected_QR'] = np.select(conditions_ACCEPTED, expected_qrs, default=None)
            is_incorrect = (df_accepted['Expected_QR'].notna()) & (df_accepted['QR'] != df_accepted['Expected_QR'])
            df_accepted.loc[is_incorrect, 'Action'] += 'Incorrect QR'
            df_accepted = df_accepted.drop(columns=['Expected_QR'])

            # 1. PERSISTENCE: Save Parquet (Draft)
            output_dir = self._data_dir / f"{sampleID_start}_{sampleID_end}"
            output_dir.mkdir(parents=True, exist_ok=True)

            master_df = pd.concat([null_PPT, df_not_a_has_ppt, df_trouble_flag, df_DFDK, df_StartEnd_Flag, df_ENDREC_FLAG], axis=0, ignore_index=True)
            parquet_out = output_dir / "review_master.parquet"
            master_df.to_parquet(parquet_out, index=False, engine='pyarrow')

            # 3. PERSISTENCE: Save Excel (Interactive Human View)
            self.logger.info(f"---- [REPORT NAME]: Review_{min_labno}_{max_labno}.xlsx in output directory: {output_dir}")

            excel_out = output_dir / f"Review_{min_labno}_{max_labno}.xlsx"
            ref_df = self._get_reference_df()
            
            # Using xlsxwriter to support data validation
            with pd.ExcelWriter(excel_out, engine='xlsxwriter') as writer:
                # Write Reference Sheet
                ref_df.to_excel(writer, sheet_name="Reference_Notes", index=False)
                
                # Write Data Sheets
                self._prepare_for_excel(df).to_excel(writer, sheet_name="Original_Data", index=False)
                self._prepare_for_excel(df_good_sample).to_excel(writer, sheet_name="good_sample", index=False)
                self._prepare_for_excel(df_accepted).to_excel(writer, sheet_name="Accepted", index=False)

                self._prepare_for_excel(null_PPT).to_excel(writer, sheet_name="Missing_ppt", index=False)
                self._prepare_for_excel(df_possible_reload).to_excel(writer, sheet_name="Possible_Reload", index=False)
                self._prepare_for_excel(Bad_Record_precent).to_excel(writer, sheet_name="Bad_Record_precent", index=False)
                self._prepare_for_excel(df_W_Zero_ppt_totp).to_excel(writer, sheet_name="W_Zero_PPT_TOTP", index=False)
                self._prepare_for_excel(df_D_nonZero_ppt_totp).to_excel(writer, sheet_name="D_NonZero_PPT_TOTP", index=False)
                self._prepare_for_excel(df_trouble_flag).to_excel(writer, sheet_name="Trouble_Flagged", index=False)
                self._prepare_for_excel(PPT_TOTP_sampleDepth_inconsistent).to_excel(writer, sheet_name="PPT_TOTP_Depth_inconsistent", index=False)
                self._prepare_for_excel(df_not_a_has_ppt).to_excel(writer, sheet_name="Not_a_has_ppt", index=False)

                self._prepare_for_excel(df_excess_totp).to_excel(writer, sheet_name="Excess_totp", index=False)
                self._prepare_for_excel(df_StartEnd_Flag).to_excel(writer, sheet_name="Start_End_diff_Greater_8", index=False)
                self._prepare_for_excel(df_ENDREC_FLAG).to_excel(writer, sheet_name="ENDREC_Late", index=False)
                self._prepare_for_excel(df_DFDK).to_excel(writer, sheet_name="DFDK_samples", index=False)
                self._prepare_for_excel(df_hold).to_excel(writer, sheet_name="Hold_ScreenStat", index=False)
                self._prepare_for_excel(df_dryExp).to_excel(writer, sheet_name="dry_exp_U", index=False)
                self._prepare_for_excel(df_full_open).to_excel(writer, sheet_name="full_open_B", index=False)

                # --- WORKBOOK & FORMAT SETUP ---
                workbook = writer.book
                fmt_center = workbook.add_format({'align': 'center', 'valign': 'vcenter'})

                for sheet_name, worksheet in writer.sheets.items():
                    # 1. Freeze the first row
                    worksheet.freeze_panes(1, 0)
                    
                    # 2. Center all columns
                    worksheet.set_column('A:Z', None, fmt_center)
                    
                    # 3. Auto-fit column widths
                    try:
                        worksheet.autofit()
                    except:
                        # Fallback if your XlsxWriter version doesn't support autofit()
                        worksheet.set_column('A:Z', 20)

                
                # Define the colors
                fmt_orange = workbook.add_format({'bg_color': '#FFC000', 'font_color': '#000000'}) # Orange for empty
                fmt_green = workbook.add_format({'bg_color': '#C6EFCE', 'font_color': '#006100'})  # Green for selected
                fmt_darkgreen = workbook.add_format({'bg_color': '#006100', 'font_color': '#FFFFFF', 'bold': True})  # Dark green for selected

                options_not_a = ["Incorrect data of precipReviewed samples","Correction","Update E-guage","Unusable eguage/ Missing Flagged", "E-guage data good", "E-guage data not complete/ Missing Flagged", "E-guage data not complete/ Still usable"]
                options_no_ppt = ["Reload E-guage/ Unusable/ Missing Flag","Correction"," Reload e-Guage co-located site","Update E-guage","Reload/ E-guage data good", "Cannot reload eguage/ Missing Flagged", "E-guage data not complete/ Missing Flagged", "E-guage data complete/ usable"]
                options_trouble = ["Incorrect data of precipReviewed samples","Correction","Update E-guage","Reload/ E-guage data good", "Cannot reload eguage/ Missing Flagged", "E-guage data not complete/ Missing Flagged", "E-guage data complete/ usable"]
                options_Late = ["REC late","Reload/ E-guage data good","Incorrect data of precipReviewed samples","Correction","Update E-guage","Sample was extended due to Federal Government Shutdown", "Long sampling period", "Very long sampling period - COVID"]
                options_DFDK = ["Invalid DF/DK","DF/DK sample","Correction","Update E-guage","Update SP with Q code"]
                options_reload = ["Incorrect data of precipReviewed samples","Correction","Update E-guage","Reload/ E-guage data good", "Cannot reload eguage/ Missing Flagged", "E-guage data not complete/ Missing Flagged", "E-guage data not complete/ Still usable", "Reload E-guage/ Unusable/ Missing Flag "] 
                options_df_W_Zero_ppt_totp = ["Invalid W/WD/WI sample","Invalid DF/DK","Incorrect data of precipReviewed samples","Correction","Update E-guage","E-guage data good", "E-guage data not complete/ Missing Flagged","Cannot use eguage data/ Missing Flagged", "Reload/ E-guage data good"]
                options_df_D_nonZero_ppt_totp = ["Invalid D sample","Invalid DF/DK","Invalid D sample","Incorrect data of precipReviewed samples","Correction","Update E-guage","E-guage data good", "Cannot use eguage data/ Missing Flagged","Reload/ E-guage data good",""]
                options_PPT_TOTP_sampleDepth_inconsistent = ["Incorrect data of precipReviewed samples","Correction","Update E-guage","E-guage data good", "Cannot use eguage data/ Missing Flagged", ""]
                options_Bad_Record_precent= ["Incorrect data of precipReviewed samples","Correction","Update E-guage","Unusable eguage/ Missing Flagged", "E-guage data good", "E-guage data not complete/ Missing Flagged"]
                options_excess_totp = ["Incorrect data of precipReviewed samples","Correction","Update E-guage","E-guage data good", "Cannot use eguage data/ Missing Flagged"]
                options_dry_exp = ["Undefined sample","Correction","Update E-guage","E-guage data good", "Cannot use eguage data/ Missing Flagged"]
                options_full_open = ["Bulk sample","Correction","Update E-guage","E-guage data good", "Cannot use eguage data/ Missing Flagged"]
                # --- APPLY DROPDOWNS & CONDITIONAL COLORING ---
                #reference dataframe
               # 1. Flatten all columns and clean the data
                # We remove spaces and dashes here to match the 'Bulletproof' logic
                unique_ref_list = (
                                        ref_df.stack()
                                        .astype(str)
                                        .str.replace(" ", "", regex=False)   # Remove spaces
                                        .str.replace("-", "", regex=False)   # Remove dashes
                                        .str.replace("/", "", regex=False)   # Remove slashes
                                        .str.strip()
                                        .replace(['nan', 'None', 'NAN'], pd.NA)
                                        .dropna()
                                        .unique()
                                    )

                # 2. Write to the Reference sheet
                final_ref_df = pd.DataFrame(unique_ref_list, columns=['Master_Reference'])
                final_ref_df.to_excel(writer, sheet_name="Reference_Notes", index=False)

                # 3. Define the Excel range for the formula
                ref_rows = len(final_ref_df)
                ref_range = f'Reference_Notes!$A$2:$A${ref_rows + 1}'

                bulletproof_criteria = (
                                        f'=AND($J2="Reviewed", '
                                        f'SUMPRODUCT(--ISNUMBER(SEARCH("|" & {ref_range} & "|", '
                                        f'SUBSTITUTE(SUBSTITUTE(SUBSTITUTE("|" & SUBSTITUTE(SUBSTITUTE(SUBSTITUTE($B2, ";", "|"), ",", "|"), ".", "|") & "|", " ", ""), "-", ""), "/", "")))) > 0)'
                                        )



                # 1. Not_a_has_ppt
                ws_not_a = writer.sheets['Not_a_has_ppt']
                last_row_ws_not_a, last_col_ws_not_a = len(df_not_a_has_ppt), len(df_not_a_has_ppt.columns) - 1
                ws_not_a.data_validation(1, 0, last_row_ws_not_a, 0, {'validate': 'list', 'source': options_not_a})
                ws_not_a.conditional_format(1, 0, last_row_ws_not_a, last_col_ws_not_a, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_not_a.conditional_format(1, 0, last_row_ws_not_a, last_col_ws_not_a, {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green})
                ws_not_a.conditional_format(1, 0, last_row_ws_not_a, last_col_ws_not_a, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                

                # 2. Missing_ppt
                ws_miss = writer.sheets['Missing_ppt']
                last_row_ws_miss, last_col_ws_miss = len(null_PPT), len(null_PPT.columns) - 1
                ws_miss.data_validation(1, 0, last_row_ws_miss, 0, {'validate': 'list', 'source': options_no_ppt})
    
      


                #dark green rule where reviewed  +  other comment in B column:
                ws_miss.conditional_format(1, 0, last_row_ws_miss, last_col_ws_miss, {
                    'type': 'formula',
                    'criteria': bulletproof_criteria,   
                    'format': fmt_darkgreen
                })

                # The Green Rule
                ws_miss.conditional_format(1, 0, last_row_ws_miss, last_col_ws_miss, {
                    'type': 'formula',
                    'criteria': f'AND($A2<>"", $A2<>"Reload E-guage co-located site")',
                    'format': fmt_green
                })

                # The Orange Rule (Keep this below the green one or set 'stop_if_true')
                ws_miss.conditional_format(1, 0, last_row_ws_miss, last_col_ws_miss, {
                    'type': 'formula', 
                    'criteria': '=$A2=""', 
                    'format': fmt_orange
                })
                

                # 3. Possible_Reload
                ws_reload = writer.sheets['Possible_Reload']
                last_row_ws_reload, last_col_ws_reload = len(df_possible_reload), len(df_possible_reload.columns) - 1
                ws_reload.data_validation(1, 0, last_row_ws_reload, 0, {'validate': 'list', 'source': options_reload})
                #dark green rule where reviewed  +  other comment in B column:
                ws_reload.conditional_format(1, 0, last_row_ws_reload, last_col_ws_reload, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_reload.conditional_format(1, 0, last_row_ws_reload, last_col_ws_reload, {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green})
                ws_reload.conditional_format(1, 0, last_row_ws_reload, last_col_ws_reload, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                

                # 4. Bad_Record_precent
                ws_bad = writer.sheets['Bad_Record_precent']
                last_row_ws_bad, last_col_ws_bad = len(Bad_Record_precent), len(Bad_Record_precent.columns) - 1
                ws_bad.data_validation(1, 0, last_row_ws_bad, 0, {'validate': 'list', 'source': options_Bad_Record_precent})
                ws_bad.conditional_format(1, 0, last_row_ws_bad, last_col_ws_bad, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_bad.conditional_format(1, 0, last_row_ws_bad, last_col_ws_bad, {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green})
                ws_bad.conditional_format(1, 0, last_row_ws_bad, last_col_ws_bad, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                

                # 5. W_Zero_PPT_TOTP
                ws_wz = writer.sheets['W_Zero_PPT_TOTP']
                last_row_ws_wz, last_col_ws_wz = len(df_W_Zero_ppt_totp), len(df_W_Zero_ppt_totp.columns) - 1
                ws_wz.data_validation(1, 0, last_row_ws_wz, 0, {'validate': 'list', 'source': options_df_W_Zero_ppt_totp})
                ws_wz.conditional_format(1, 0, last_row_ws_wz, last_col_ws_wz, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})

                ws_wz.conditional_format(1, 0, last_row_ws_wz, last_col_ws_wz, {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green})
                ws_wz.conditional_format(1, 0, last_row_ws_wz, last_col_ws_wz, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                

                # 6. D_NonZero_PPT_TOTP
                ws_dnz = writer.sheets['D_NonZero_PPT_TOTP']
                last_row_ws_dnz, last_col_ws_dnz = len(df_D_nonZero_ppt_totp), len(df_D_nonZero_ppt_totp.columns) - 1
                ws_dnz.data_validation(1, 0, last_row_ws_dnz, 0, {'validate': 'list', 'source': options_df_D_nonZero_ppt_totp})
                ws_dnz.conditional_format(1, 0, last_row_ws_dnz, last_col_ws_dnz, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_dnz.conditional_format(1, 0, last_row_ws_dnz, last_col_ws_dnz, {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green})
                ws_dnz.conditional_format(1, 0, last_row_ws_dnz, last_col_ws_dnz, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                

                # 7. Trouble_Flagged
                ws_trb = writer.sheets['Trouble_Flagged']
                last_row_ws_trb, last_col_ws_trb = len(df_trouble_flag), len(df_trouble_flag.columns) - 1
                ws_trb.data_validation(1, 0, last_row_ws_trb, 0, {'validate': 'list', 'source': options_trouble})
                ws_trb.conditional_format(1, 0, last_row_ws_trb, last_col_ws_trb, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_trb.conditional_format(1, 0, last_row_ws_trb, last_col_ws_trb, {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green})
                ws_trb.conditional_format(1, 0, last_row_ws_trb, last_col_ws_trb, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                

                # 8. ENDREC_Late
                ws_late = writer.sheets['ENDREC_Late']
                last_row_ws_late, last_col_ws_late = len(df_ENDREC_FLAG), len(df_ENDREC_FLAG.columns) - 1
                ws_late.data_validation(1, 0, last_row_ws_late, 0, {'validate': 'list', 'source': options_Late})
                ws_late.conditional_format(1, 0, last_row_ws_late, last_col_ws_late, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_late.conditional_format(1, 0, last_row_ws_late, last_col_ws_late, {'type': 'formula', 'criteria': '=AND($A2<>"", $A2<>" No h in notes")', 'format': fmt_green})
                ws_late.conditional_format(1, 0, last_row_ws_late, last_col_ws_late, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                ws_late.conditional_format(1, 0, last_row_ws_late, last_col_ws_late, {'type': 'formula', 'criteria': '=$A2=" No h in notes"', 'format': fmt_orange})
                

                # 9. Start_End_diff_Greater_8
                ws_se = writer.sheets['Start_End_diff_Greater_8']
                last_row_ws_se, last_col_ws_se = len(df_StartEnd_Flag), len(df_StartEnd_Flag.columns) - 1
                ws_se.data_validation(1, 0, last_row_ws_se, 0, {'validate': 'list', 'source': options_Late})
                ws_se.conditional_format(1, 0, last_row_ws_se, last_col_ws_se, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_se.conditional_format(1, 0, last_row_ws_se, last_col_ws_se, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                ws_se.conditional_format(1, 0, last_row_ws_se, last_col_ws_se, {'type': 'formula', 'criteria': '=$A2="incorrect QR/ No e in notes"', 'format': fmt_orange})

                # 10. DFDK_samples
                ws_dfdk = writer.sheets['DFDK_samples']
                last_row_ws_dfdk, last_col_ws_dfdk = len(df_DFDK), len(df_DFDK.columns) - 1
                ws_dfdk.data_validation(1, 0, last_row_ws_dfdk, 0, {'validate': 'list', 'source': options_DFDK})
                ws_dfdk.conditional_format(1, 0, last_row_ws_dfdk, last_col_ws_dfdk, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_dfdk.conditional_format(1, 0, last_row_ws_dfdk, last_col_ws_dfdk, {'type': 'formula', 'criteria': '=AND($A2<>"", $A2<>"Update SP with Q code")', 'format': fmt_green})
                ws_dfdk.conditional_format(1, 0, last_row_ws_dfdk, last_col_ws_dfdk, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                ws_dfdk.conditional_format(1, 0, last_row_ws_dfdk, last_col_ws_dfdk, {'type': 'formula', 'criteria': '=$A2="Update SP with Q code"', 'format': fmt_orange})
                

                # 11. PPT_TOTP_Depth_inconsistent
                ws_inc = writer.sheets['PPT_TOTP_Depth_inconsistent']
                last_row_ws_inc, last_col_ws_inc = len(PPT_TOTP_sampleDepth_inconsistent), len(PPT_TOTP_sampleDepth_inconsistent.columns) - 1
                ws_inc.data_validation(1, 0, last_row_ws_inc, 0, {'validate': 'list', 'source': options_PPT_TOTP_sampleDepth_inconsistent})
                ws_inc.conditional_format(1, 0, last_row_ws_inc, last_col_ws_inc, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_inc.conditional_format(1, 0, last_row_ws_inc, last_col_ws_inc, {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green})
                ws_inc.conditional_format(1, 0, last_row_ws_inc, last_col_ws_inc, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                

                # 12. Excess_totp
                ws_exc = writer.sheets['Excess_totp']
                last_row_ws_exc, last_col_ws_exc = len(df_excess_totp), len(df_excess_totp.columns) - 1
                ws_exc.data_validation(1, 0, last_row_ws_exc, 0, {'validate': 'list', 'source': options_excess_totp})
                ws_exc.conditional_format(1, 0, last_row_ws_exc, last_col_ws_exc, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_exc.conditional_format(1, 0, last_row_ws_exc, last_col_ws_exc, {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green})
                ws_exc.conditional_format(1, 0, last_row_ws_exc, last_col_ws_exc, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})

                # 13. dry_exp_U
                ws_dry = writer.sheets['dry_exp_U']
                last_row_ws_dry, last_col_ws_dry = len(df_dryExp), len(df_dryExp.columns) - 1
                ws_dry.data_validation(1, 0, last_row_ws_dry, 0, {'validate': 'list', 'source': options_dry_exp})
                ws_dry.conditional_format(1, 0, last_row_ws_dry, last_col_ws_dry, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_dry.conditional_format(1, 0, last_row_ws_dry, last_col_ws_dry, {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green})
                ws_dry.conditional_format(1, 0, last_row_ws_dry, last_col_ws_dry, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})

                # 14. full_open_B
                ws_full = writer.sheets['full_open_B']
                last_row_ws_full, last_col_ws_full = len(df_full_open), len(df_full_open.columns) - 1
                ws_full.data_validation(1, 0, last_row_ws_full, 0, {'validate': 'list', 'source': options_full_open})
                ws_full.conditional_format(1, 0, last_row_ws_full, last_col_ws_full, {'type': 'formula','criteria': bulletproof_criteria,'format': fmt_darkgreen})
                ws_full.conditional_format(1, 0, last_row_ws_full, last_col_ws_full, {'type': 'formula', 'criteria': '=$A2<>""', 'format': fmt_green})
                ws_full.conditional_format(1, 0, last_row_ws_full, last_col_ws_full, {'type': 'formula', 'criteria': '=$A2=""', 'format': fmt_orange})
                
            self.logger.info(f"Report Generated with Dropdowns. Final RAM: {self.current_mem_usage}")
            
        except Exception as e:
            self.logger.error(f"Error during processing: {e}")
            raise

def run():
    try:
        pipeline = NTNReviewPipeline(PipelineSettings())
        
        # --- STAGE 1: Process and Export ---
        data = pipeline.load_and_optimize()
        pipeline.process_review(data)
        
        # --- STAGE 2: Sync (Manual Trigger) ---
        # After the lab tech saves the Excel file, uncomment the line below to update Parquet:
        # pipeline.sync_human_labels(pipeline._data_dir / "Review_Report.xlsx")
        
    except Exception as e:
        print(f"CRITICAL ERROR: {e}")
        sys.exit(1)
